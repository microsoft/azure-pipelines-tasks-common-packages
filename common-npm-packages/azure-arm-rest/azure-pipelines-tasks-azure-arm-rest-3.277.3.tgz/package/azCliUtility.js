"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateAzModuleVersion = exports.initOIDCToken2 = exports.getFederatedToken = exports.loginAzureRM = exports.setAzureCloudBasedOnServiceEndpoint = void 0;
const fs = require("fs");
const path = require("path");
const azure_devops_node_api_1 = require("azure-devops-node-api");
const tl = __importStar(require("azure-pipelines-task-lib/task"));
const webClient = __importStar(require("./webClient"));
// Maximum number of retries for creating OIDC token
const MAX_CREATE_OIDC_TOKEN_RETRIES = 3;
// Maximum backoff timeout for creating OIDC token in milliseconds
const MAX_CREATE_OIDC_TOKEN_BACKOFF_TIMEOUT = 15000;
tl.setResourcePath(path.join(__dirname, 'module.json'), true);
function setAzureCloudBasedOnServiceEndpoint(connectedService) {
    var environment = tl.getEndpointDataParameter(connectedService, 'environment', true);
    if (!!environment) {
        console.log(tl.loc('SettingAzureCloud', environment));
        throwIfError(tl.execSync("az", "cloud set -n " + environment));
    }
}
exports.setAzureCloudBasedOnServiceEndpoint = setAzureCloudBasedOnServiceEndpoint;
function loginAzureRM(connectedService) {
    return __awaiter(this, void 0, void 0, function* () {
        var authScheme = tl.getEndpointAuthorizationScheme(connectedService, true);
        if (authScheme.toLowerCase() == "workloadidentityfederation") {
            var servicePrincipalId = tl.getEndpointAuthorizationParameter(connectedService, "serviceprincipalid", false);
            var tenantId = tl.getEndpointAuthorizationParameter(connectedService, "tenantid", false);
            const federatedToken = yield getFederatedToken(connectedService);
            tl.setSecret(federatedToken);
            const args = `login --service-principal -u "${servicePrincipalId}" --tenant "${tenantId}" --allow-no-subscriptions --federated-token "${federatedToken}"`;
            //login using OpenID Connect federation
            throwIfError(tl.execSync("az", args), tl.loc("LoginFailed"));
        }
        else if (authScheme.toLowerCase() == "serviceprincipal") {
            let authType = tl.getEndpointAuthorizationParameter(connectedService, 'authenticationType', true);
            var servicePrincipalId = tl.getEndpointAuthorizationParameter(connectedService, "serviceprincipalid", false);
            var tenantId = tl.getEndpointAuthorizationParameter(connectedService, "tenantid", false);
            let cliPassword = null;
            let isCertificateParameterSupported = false;
            let authParam = "--password";
            const azVersionResult = tl.execSync("az", "--version");
            throwIfError(azVersionResult);
            isCertificateParameterSupported = isAzVersionGreaterOrEqual(azVersionResult.stdout, "2.66.0");
            if (authType == "spnCertificate") {
                tl.debug('certificate based endpoint');
                if (isCertificateParameterSupported) {
                    authParam = "--certificate";
                }
                let certificateContent = tl.getEndpointAuthorizationParameter(connectedService, "servicePrincipalCertificate", false);
                cliPassword = path.join(tl.getVariable('Agent.TempDirectory') || tl.getVariable('system.DefaultWorkingDirectory'), 'spnCert.pem');
                fs.writeFileSync(cliPassword, certificateContent);
            }
            else {
                tl.debug('key based endpoint');
                cliPassword = tl.getEndpointAuthorizationParameter(connectedService, "serviceprincipalkey", false);
            }
            let escapedCliPassword = cliPassword.replace(/"/g, '\\"');
            tl.setSecret(escapedCliPassword.replace(/\\/g, '\"'));
            //login using svn
            throwIfError(tl.execSync("az", `login --service-principal -u "${servicePrincipalId}" ${authParam}="${escapedCliPassword}" --tenant "${tenantId}" --allow-no-subscriptions`), tl.loc("LoginFailed"));
        }
        else if (authScheme.toLowerCase() == "managedserviceidentity") {
            //login using msi
            throwIfError(tl.execSync("az", "login --identity"), tl.loc("MSILoginFailed"));
        }
        else {
            throw tl.loc('AuthSchemeNotSupported', authScheme);
        }
        var subscriptionID = tl.getEndpointDataParameter(connectedService, "SubscriptionID", true);
        if (!!subscriptionID) {
            //set the subscription imported to the current subscription
            throwIfError(tl.execSync("az", "account set --subscription \"" + subscriptionID + "\""), tl.loc("ErrorInSettingUpSubscription"));
        }
    });
}
exports.loginAzureRM = loginAzureRM;
function throwIfError(resultOfToolExecution, errormsg) {
    if (resultOfToolExecution.code != 0) {
        tl.error("Error Code: [" + resultOfToolExecution.code + "]");
        if (errormsg) {
            tl.error("Error: " + errormsg);
        }
        throw resultOfToolExecution;
    }
}
function getSystemAccessToken() {
    tl.debug('Getting credentials for account feeds');
    let auth = tl.getEndpointAuthorization('SYSTEMVSSCONNECTION', false);
    if (auth && auth.scheme === 'OAuth') {
        tl.debug('Got auth token, setting it as secret so it does not print in console log');
        tl.setSecret(auth.parameters['AccessToken']);
        return auth.parameters['AccessToken'];
    }
    tl.warning(tl.loc('FeedTokenUnavailable'));
    return '';
}
function getFederatedToken(connectedServiceName) {
    return __awaiter(this, void 0, void 0, function* () {
        const projectId = tl.getVariable("System.TeamProjectId");
        const hub = tl.getVariable("System.HostType");
        const planId = tl.getVariable('System.PlanId');
        const jobId = tl.getVariable('System.JobId');
        let uri = tl.getVariable("System.CollectionUri");
        if (!uri) {
            uri = tl.getVariable("System.TeamFoundationServerUri");
        }
        const token = getSystemAccessToken();
        const authHandler = (0, azure_devops_node_api_1.getHandlerFromToken)(token);
        const connection = new azure_devops_node_api_1.WebApi(uri, authHandler);
        const oidc_token = yield initOIDCToken(connection, projectId, hub, planId, jobId, connectedServiceName);
        tl.setSecret(oidc_token);
        return oidc_token;
    });
}
exports.getFederatedToken = getFederatedToken;
function initOIDCToken(connection, projectId, hub, planId, jobId, serviceConnectionId, retryCount = 0, timeToWait = 2000) {
    if (tl.getPipelineFeature("UseOIDCToken2InAzureArmRest")) {
        return initOIDCToken2(connection, projectId, hub, planId, jobId, serviceConnectionId, retryCount, timeToWait);
    }
    return new Promise((resolve, reject) => {
        connection.getTaskApi().then((taskApi) => {
            taskApi.createOidcToken({}, projectId, hub, planId, jobId, serviceConnectionId).then((response) => {
                if (response != null) {
                    tl.debug('Got OIDC token');
                    resolve(response.oidcToken);
                }
                else if (response.oidcToken == null) {
                    if (retryCount < 3) {
                        let waitedTime = timeToWait;
                        retryCount += 1;
                        setTimeout(() => {
                            resolve(initOIDCToken(connection, projectId, hub, planId, jobId, serviceConnectionId, retryCount, waitedTime));
                        }, waitedTime);
                    }
                    else {
                        reject(tl.loc('CouldNotFetchAccessTokenforAAD'));
                    }
                }
            }, (error) => {
                reject(tl.loc('CouldNotFetchAccessTokenforAAD') + " " + error);
            });
        });
    });
}
function initOIDCToken2(connection, projectId, hub, planId, jobId, serviceConnectionId, retryCount = 0, timeToWait = 2000) {
    return __awaiter(this, void 0, void 0, function* () {
        const taskApi = yield connection.getTaskApi();
        try {
            const token = yield taskApi.createOidcToken({}, projectId, hub, planId, jobId, serviceConnectionId);
            // If the token is null or undefined, it means the OIDC token could not be fetched
            if (!(token === null || token === void 0 ? void 0 : token.oidcToken)) {
                throw new Error(tl.loc('CouldNotFetchAccessTokenforAAD'));
            }
            tl.debug('Got OIDC token');
            return token.oidcToken;
        }
        catch (error) {
            // Handle AggregateError if available, since the package uses Node10 types.
            // Otherwise handle generic error
            if (error.name === 'AggregateError' && error['errors'] !== undefined) {
                for (const err of error.errors) {
                    tl.error(`Error while trying to get OIDC token: ${err}`);
                }
            }
            else {
                tl.error(`Error while trying to get OIDC token: ${error}`);
            }
            if (retryCount >= MAX_CREATE_OIDC_TOKEN_RETRIES) {
                throw Error(tl.loc('CouldNotFetchAccessTokenForAADRetryLimitExceeded'));
            }
            retryCount += 1;
            tl.debug(`Retrying OIDC token fetch. Retries left: ${MAX_CREATE_OIDC_TOKEN_RETRIES - retryCount}`);
            // Wait for a backoff time before retrying
            yield new Promise(resolve => setTimeout(resolve, Math.min(timeToWait * retryCount, MAX_CREATE_OIDC_TOKEN_BACKOFF_TIMEOUT)));
            return initOIDCToken2(connection, projectId, hub, planId, jobId, serviceConnectionId, retryCount, timeToWait);
        }
    });
}
exports.initOIDCToken2 = initOIDCToken2;
function isAzVersionGreaterOrEqual(azVersionResultOutput, versionToCompare) {
    try {
        const versionMatch = azVersionResultOutput.match(/azure-cli\s+(\d+\.\d+\.\d+)/);
        if (!versionMatch || versionMatch.length < 2) {
            tl.error(`Can't parse az version from: ${azVersionResultOutput}`);
            return false;
        }
        const currentVersion = versionMatch[1];
        tl.debug(`Current Azure CLI version: ${currentVersion}`);
        // Parse both versions into major, minor, patch components
        const [currentMajor, currentMinor, currentPatch] = currentVersion.split('.').map(Number);
        const [compareMajor, compareMinor, comparePatch] = versionToCompare.split('.').map(Number);
        // Compare versions
        if (currentMajor > compareMajor)
            return true;
        if (currentMajor < compareMajor)
            return false;
        if (currentMinor > compareMinor)
            return true;
        if (currentMinor < compareMinor)
            return false;
        return currentPatch >= comparePatch;
    }
    catch (error) {
        tl.error(`Error checking Azure CLI version: ${error.message}`);
        return false;
    }
}
function getLatestAzureModuleReleaseVersion(moduleName) {
    var _a, _b, _c;
    return __awaiter(this, void 0, void 0, function* () {
        try {
            let request = new webClient.WebRequest();
            request.uri = `https://api.github.com/repos/Azure/${moduleName}/releases`;
            request.method = 'GET';
            request.headers = request.headers || {};
            const response = yield webClient.sendRequest(request, Object.assign(new webClient.WebRequestOptions(), {
                retryCount: 1,
                requestTimeout: 3000,
                suppressErrorIssue: true
            }));
            const lastestCliRelease = moduleName === "azure-powershell" ? (_b = (_a = response === null || response === void 0 ? void 0 : response.body) === null || _a === void 0 ? void 0 : _a.filter(x => { var _a; return (_a = x === null || x === void 0 ? void 0 : x.tag_name) === null || _a === void 0 ? void 0 : _a.match(/^v\d+\.\d+\.0/); })) === null || _b === void 0 ? void 0 : _b[0] : (_c = response === null || response === void 0 ? void 0 : response.body) === null || _c === void 0 ? void 0 : _c[0];
            return lastestCliRelease === null || lastestCliRelease === void 0 ? void 0 : lastestCliRelease.tag_name;
        }
        catch (err) {
            tl.debug(`Error checking Azure version: ${err.message}. Hence skipping the check for latest version of ${moduleName}.`);
        }
    });
}
function validateAzModuleVersion(moduleName, currentVersion, displayName, versionTolerance, checkOnlyMajorVersion = false) {
    return __awaiter(this, void 0, void 0, function* () {
        const DisplayWarningForOlderAzVersion = tl.getPipelineFeature("ShowWarningOnOlderAzureModules");
        try {
            if (DisplayWarningForOlderAzVersion) {
                const latestRelease = yield getLatestAzureModuleReleaseVersion(moduleName);
                if (latestRelease) {
                    const [latestsemver, latestMajor, latestMinor] = latestRelease.match(/(\d+).(\d+).(\d+)/);
                    const [currentsemver, currentMajor, currentMinor] = currentVersion.match(/(\d+).(\d+).(\d+)/);
                    tl.debug(`For the module ${moduleName} the current semver Version is ${currentsemver} and the latest semver version is ${latestsemver}`);
                    let displayWarning = false;
                    if (checkOnlyMajorVersion && Number(currentMajor) < Number(latestMajor) - versionTolerance) {
                        displayWarning = true;
                    }
                    if (!checkOnlyMajorVersion && (Number(currentMajor) < Number(latestMajor) || Number(currentMinor) < Number(latestMinor) - versionTolerance)) {
                        displayWarning = true;
                    }
                    if (displayWarning) {
                        tl.warning(tl.loc('lowerAzWarning', displayName, currentsemver, latestsemver));
                    }
                }
            }
        }
        catch (err) {
            tl.debug(`Error on validating Azure version: ${err.message}. Hence skipping the check for latest version of ${moduleName}.`);
        }
    });
}
exports.validateAzModuleVersion = validateAzModuleVersion;
