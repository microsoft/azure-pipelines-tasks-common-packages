"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SiteContainer = exports.VolumeMount = exports.EnvironmentVariable = exports.AUTH_TYPE = void 0;
var AUTH_TYPE;
(function (AUTH_TYPE) {
    AUTH_TYPE["ANONYMOUS"] = "Anonymous";
    AUTH_TYPE["USERCREDENTIALS"] = "UserCredentials";
    AUTH_TYPE["SYSTEM_IDENTITY"] = "SystemIdentity";
    AUTH_TYPE["USER_ASSIGNED"] = "UserAssigned";
})(AUTH_TYPE = exports.AUTH_TYPE || (exports.AUTH_TYPE = {}));
class EnvironmentVariable {
    constructor(name, value) {
        this.name = name;
        this.value = value;
    }
    getName() {
        return this.name;
    }
    getValue() {
        return this.value;
    }
    setName(name) {
        this.name = name;
    }
    setValue(value) {
        this.value = value;
    }
    static fromJson(item) {
        return new EnvironmentVariable(item.name, item.value);
    }
    static toJson(envVar) {
        return {
            name: envVar.getName(),
            value: envVar.getValue()
        };
    }
}
exports.EnvironmentVariable = EnvironmentVariable;
class VolumeMount {
    constructor(containerMountPath, volumeSubPath, readOnly) {
        this.containerMountPath = containerMountPath;
        this.volumeSubPath = volumeSubPath;
        this.readOnly = readOnly;
    }
    getContainerMountPath() {
        return this.containerMountPath;
    }
    getVolumeSubPath() {
        return this.volumeSubPath;
    }
    getReadOnly() {
        return this.readOnly;
    }
    setContainerMountPath(containerMountPath) {
        this.containerMountPath = containerMountPath;
    }
    setVolumeSubPath(volumeSubPath) {
        this.volumeSubPath = volumeSubPath;
    }
    setReadOnly(readOnly) {
        this.readOnly = readOnly;
    }
    static fromJson(item) {
        return new VolumeMount(item.containerMountPath, item.volumeSubPath, item.readOnly);
    }
    static toJson(volumeMount) {
        return {
            containerMountPath: volumeMount.getContainerMountPath(),
            volumeSubPath: volumeMount.getVolumeSubPath(),
            readOnly: volumeMount.getReadOnly()
        };
    }
}
exports.VolumeMount = VolumeMount;
class SiteContainer {
    constructor(name, image, isMain, targetPort, startupCommand, authType, userName, passwordSecret, userManagedIdentityClientId, environmentVariables, volumeMounts, inheritAppSettingsAndConnectionStrings) {
        this.name = name;
        this.image = image;
        this.isMain = isMain;
        this.targetPort = targetPort;
        this.startupCommand = startupCommand;
        this.authType = authType;
        this.userName = userName;
        this.passwordSecret = passwordSecret;
        this.userManagedIdentityClientId = userManagedIdentityClientId;
        this.environmentVariables = environmentVariables;
        this.volumeMounts = volumeMounts;
        this.inheritAppSettingsAndConnectionStrings = inheritAppSettingsAndConnectionStrings;
    }
    getName() {
        return this.name;
    }
    getImage() {
        return this.image;
    }
    getIsMain() {
        return this.isMain;
    }
    getTargetPort() {
        return this.targetPort;
    }
    getStartupCommand() {
        return this.startupCommand;
    }
    getAuthType() {
        return this.authType;
    }
    getUserName() {
        return this.userName;
    }
    getPasswordSecret() {
        return this.passwordSecret;
    }
    getUserManagedIdentityClientId() {
        return this.userManagedIdentityClientId;
    }
    getEnvironmentVariables() {
        return this.environmentVariables;
    }
    getVolumeMounts() {
        return this.volumeMounts;
    }
    getInheritAppSettingsAndConnectionStrings() {
        return this.inheritAppSettingsAndConnectionStrings;
    }
    setName(name) {
        this.name = name;
    }
    setImage(image) {
        this.image = image;
    }
    setIsMain(isMain) {
        this.isMain = isMain;
    }
    setTargetPort(targetPort) {
        this.targetPort = targetPort;
    }
    setStartupCommand(startupCommand) {
        this.startupCommand = startupCommand;
    }
    setAuthType(authType) {
        this.authType = authType;
    }
    setUserName(userName) {
        this.userName = userName;
    }
    setPasswordSecret(passwordSecret) {
        this.passwordSecret = passwordSecret;
    }
    setUserManagedIdentityClientId(userManagedIdentityClientId) {
        this.userManagedIdentityClientId = userManagedIdentityClientId;
    }
    setEnvironmentVariables(environmentVariables) {
        this.environmentVariables = environmentVariables;
    }
    setVolumeMounts(volumeMounts) {
        this.volumeMounts = volumeMounts;
    }
    setInheritAppSettingsAndConnectionStrings(inheritAppSettingsAndConnectionStrings) {
        this.inheritAppSettingsAndConnectionStrings = inheritAppSettingsAndConnectionStrings;
    }
    static fromJson(item) {
        var _a, _b, _c;
        return new SiteContainer(item.name, item.image, item.isMain, (_a = item.targetPort) === null || _a === void 0 ? void 0 : _a.toString(), item.startupCommand, item.authType, item.userName, item.passwordSecret, item.userManagedIdentityClientId, (_b = item.environmentVariables) === null || _b === void 0 ? void 0 : _b.map((env) => new EnvironmentVariable(env.name, env.value)), (_c = item.volumeMounts) === null || _c === void 0 ? void 0 : _c.map((mount) => new VolumeMount(mount.containerMountPath, mount.volumeSubPath, mount.readOnly)), item.inheritAppSettingsAndConnectionStrings);
    }
}
exports.SiteContainer = SiteContainer;
