"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getKubeConfigForFleet = exports.getKubeConfig = exports.getKubeConfigFromFleet = void 0;
const tl = require("azure-pipelines-task-lib/task");
const azure_arm_aks_service_1 = require("./azure-arm-aks-service");
const azure_arm_endpoint_1 = require("./azure-arm-endpoint");
function getKubeConfigFromAKS(azureSubscriptionEndpoint, resourceGroup, name, isFleet, useClusterAdmin) {
    return __awaiter(this, void 0, void 0, function* () {
        const azureEndpoint = yield (new azure_arm_endpoint_1.AzureRMEndpoint(azureSubscriptionEndpoint)).getEndpoint();
        const aks = new azure_arm_aks_service_1.AzureAksService(azureEndpoint);
        tl.debug(tl.loc("KubernetesClusterResourceGroup", name, resourceGroup));
        let base64Kubeconfig;
        const USE_AKS_CREDENTIAL_API = tl.getBoolFeatureFlag('USE_AKS_CREDENTIAL_API');
        if (USE_AKS_CREDENTIAL_API) {
            let clusterInfo = yield aks.getClusterCredential(resourceGroup, name, useClusterAdmin);
            base64Kubeconfig = Buffer.from(clusterInfo.value, 'base64');
        }
        else {
            let clusterInfo = yield aks.getAccessProfile(resourceGroup, name, useClusterAdmin);
            base64Kubeconfig = Buffer.from(clusterInfo.properties.kubeConfig, 'base64');
        }
        return base64Kubeconfig.toString();
    });
}
function getKubeConfigFromFleet(azureSubscriptionEndpoint, resourceGroup, fleetName) {
    return __awaiter(this, void 0, void 0, function* () {
        tl.debug(tl.loc("KubernetesClusterResourceGroup", fleetName, resourceGroup));
        const azureEndpoint = yield (new azure_arm_endpoint_1.AzureRMEndpoint(azureSubscriptionEndpoint)).getEndpoint();
        const aks = new azure_arm_aks_service_1.AzureAksService(azureEndpoint);
        let clusterInfo = yield aks.getFleetCredential(resourceGroup, fleetName);
        let base64Kubeconfig = Buffer.from(clusterInfo.value, 'base64');
        return base64Kubeconfig.toString();
    });
}
exports.getKubeConfigFromFleet = getKubeConfigFromFleet;
function getKubeConfig(azureSubscriptionEndpoint, resourceGroup, clusterName, useClusterAdmin) {
    return __awaiter(this, void 0, void 0, function* () {
        return getKubeConfigFromAKS(azureSubscriptionEndpoint, resourceGroup, clusterName, false, useClusterAdmin);
    });
}
exports.getKubeConfig = getKubeConfig;
function getKubeConfigForFleet(azureSubscriptionEndpoint, resourceGroup, fleetName) {
    return __awaiter(this, void 0, void 0, function* () {
        return getKubeConfigFromFleet(azureSubscriptionEndpoint, resourceGroup, fleetName);
    });
}
exports.getKubeConfigForFleet = getKubeConfigForFleet;
