"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.sanitizeKuduLogForConsole = exports.Kudu = exports.KuduServiceManagementClient = void 0;
const crypto = require("crypto");
const fs = require("fs");
const path = require("path");
const tl = require("azure-pipelines-task-lib/task");
const constants_1 = require("./constants");
const webClient = require("./webClient");
tl.setResourcePath(path.join(__dirname, 'module.json'), true);
class KuduServiceManagementClient {
    constructor(scmUri, authHeader, cookie) {
        this._cookie = undefined;
        this._authHeader = authHeader;
        this._scmUri = scmUri;
        if (cookie) {
            this._cookie = cookie;
            tl.debug(`initialized with affinity cookie ${JSON.stringify(this._cookie)}`);
        }
    }
    beginRequest(request, reqOptions, contentType) {
        return __awaiter(this, void 0, void 0, function* () {
            request.headers = request.headers || {};
            request.headers["Authorization"] = this._authHeader;
            if (!request.headers['Content-Type'] || !!contentType) {
                request.headers['Content-Type'] = contentType || 'application/json; charset=utf-8';
            }
            if (!!this._cookie) {
                tl.debug(`setting affinity cookie ${JSON.stringify(this._cookie)}`);
                request.headers['Cookie'] = this._cookie;
            }
            let retryCount = reqOptions && (typeof reqOptions.retryCount === 'number') ? reqOptions.retryCount : 5;
            while (retryCount >= 0) {
                try {
                    let httpResponse = yield webClient.sendRequest(request, reqOptions);
                    // Capture cookie from response if not already set
                    if (httpResponse.headers['set-cookie'] && !this._cookie) {
                        this._cookie = httpResponse.headers['set-cookie'];
                        tl.debug(`loaded affinity cookie ${JSON.stringify(this._cookie)}`);
                    }
                    return httpResponse;
                }
                catch (exception) {
                    let exceptionString = exception.toString();
                    if (exceptionString.indexOf("Hostname/IP doesn't match certificates's altnames") != -1
                        || exceptionString.indexOf("unable to verify the first certificate") != -1
                        || exceptionString.indexOf("unable to get local issuer certificate") != -1) {
                        tl.warning(tl.loc('ASE_SSLIssueRecommendation'));
                    }
                    if (retryCount > 0 && exceptionString.indexOf('Request timeout') != -1 && (!reqOptions || reqOptions.retryRequestTimedout)) {
                        tl.debug('encountered request timedout issue in Kudu. Retrying again');
                        retryCount -= 1;
                        continue;
                    }
                    throw new Error(exceptionString);
                }
            }
        });
    }
    getRequestUri(uriFormat, queryParameters) {
        uriFormat = uriFormat[0] == "/" ? uriFormat : "/" + uriFormat;
        if (queryParameters && queryParameters.length > 0) {
            uriFormat = uriFormat + '?' + queryParameters.join('&');
        }
        return this._scmUri + uriFormat;
    }
    getScmUri() {
        return this._scmUri;
    }
}
exports.KuduServiceManagementClient = KuduServiceManagementClient;
class Kudu {
    constructor(scmUri, authHeader, cookie) {
        this.client = new KuduServiceManagementClient(scmUri, authHeader, cookie);
    }
    updateDeployment(requestBody) {
        return __awaiter(this, void 0, void 0, function* () {
            var httpRequest = new webClient.WebRequest();
            httpRequest.method = 'PUT';
            httpRequest.body = JSON.stringify(requestBody);
            httpRequest.uri = this.client.getRequestUri(`/api/deployments/${requestBody.id}`);
            try {
                let webRequestOptions = { retriableErrorCodes: [], retriableStatusCodes: [], retryCount: 1, retryIntervalInSeconds: 5, retryRequestTimedout: true };
                var response = yield this.client.beginRequest(httpRequest, webRequestOptions);
                tl.debug(`updateDeployment. Data: ${JSON.stringify(response)}`);
                if (response.statusCode == 200) {
                    console.log(tl.loc("Successfullyupdateddeploymenthistory", response.body.url));
                    return response.body.id;
                }
                throw response;
            }
            catch (error) {
                throw Error(tl.loc('Failedtoupdatedeploymenthistory', this._getFormattedError(error)));
            }
        });
    }
    getKuduStackTraceUrl() {
        let stackTraceUrl = this.client.getRequestUri(`/api/vfs/LogFiles/kudu/trace`);
        return stackTraceUrl;
    }
    getContinuousJobs() {
        return __awaiter(this, void 0, void 0, function* () {
            var httpRequest = new webClient.WebRequest();
            httpRequest.method = 'GET';
            httpRequest.uri = this.client.getRequestUri(`/api/continuouswebjobs`);
            try {
                var response = yield this.client.beginRequest(httpRequest);
                tl.debug(`getContinuousJobs. Data: ${JSON.stringify(response)}`);
                if (response.statusCode == 200) {
                    return response.body;
                }
                throw response;
            }
            catch (error) {
                throw Error(tl.loc('FailedToGetContinuousWebJobs', this._getFormattedError(error)));
            }
        });
    }
    startContinuousWebJob(jobName) {
        return __awaiter(this, void 0, void 0, function* () {
            console.log(tl.loc('StartingWebJob', jobName));
            var httpRequest = new webClient.WebRequest();
            httpRequest.method = 'POST';
            httpRequest.uri = this.client.getRequestUri(`/api/continuouswebjobs/${jobName}/start`);
            try {
                var response = yield this.client.beginRequest(httpRequest);
                tl.debug(`startContinuousWebJob. Data: ${JSON.stringify(response)}`);
                if (response.statusCode == 200) {
                    console.log(tl.loc('StartedWebJob', jobName));
                    return response.body;
                }
                throw response;
            }
            catch (error) {
                throw Error(tl.loc('FailedToStartContinuousWebJob', jobName, this._getFormattedError(error)));
            }
        });
    }
    stopContinuousWebJob(jobName) {
        return __awaiter(this, void 0, void 0, function* () {
            console.log(tl.loc('StoppingWebJob', jobName));
            var httpRequest = new webClient.WebRequest();
            httpRequest.method = 'POST';
            httpRequest.uri = this.client.getRequestUri(`/api/continuouswebjobs/${jobName}/stop`);
            try {
                var response = yield this.client.beginRequest(httpRequest);
                tl.debug(`stopContinuousWebJob. Data: ${JSON.stringify(response)}`);
                if (response.statusCode == 200) {
                    console.log(tl.loc('StoppedWebJob', jobName));
                    return response.body;
                }
                throw response;
            }
            catch (error) {
                throw Error(tl.loc('FailedToStopContinuousWebJob', jobName, this._getFormattedError(error)));
            }
        });
    }
    installSiteExtension(extensionID) {
        return __awaiter(this, void 0, void 0, function* () {
            console.log(tl.loc("InstallingSiteExtension", extensionID));
            var httpRequest = new webClient.WebRequest();
            httpRequest.method = 'PUT';
            httpRequest.uri = this.client.getRequestUri(`/api/siteextensions/${extensionID}`);
            try {
                var response = yield this.client.beginRequest(httpRequest);
                tl.debug(`installSiteExtension. Data: ${JSON.stringify(response)}`);
                if (response.statusCode == 200) {
                    console.log(tl.loc("SiteExtensionInstalled", extensionID));
                    return response.body;
                }
                throw response;
            }
            catch (error) {
                throw Error(tl.loc('FailedToInstallSiteExtension', extensionID, this._getFormattedError(error)));
            }
        });
    }
    installSiteExtensionWithVersion(extensionID, version) {
        return __awaiter(this, void 0, void 0, function* () {
            console.log(tl.loc("InstallingSiteExtensionWithVersion", extensionID, version));
            var httpRequest = new webClient.WebRequest();
            httpRequest.method = 'PUT';
            httpRequest.uri = this.client.getRequestUri(`/api/siteextensions/${extensionID}`);
            httpRequest.body = JSON.stringify({ version: version });
            httpRequest.headers = {
                'Content-Type': 'application/json'
            };
            try {
                var response = yield this.client.beginRequest(httpRequest);
                tl.debug(`installSiteExtensionWithVersion. Data: ${JSON.stringify(response)}`);
                if (response.statusCode == 200) {
                    console.log(tl.loc("SiteExtensionInstalledWithVersion", extensionID, version));
                    return response.body;
                }
                throw response;
            }
            catch (error) {
                throw Error(tl.loc('FailedToInstallSiteExtensionWithVersion', extensionID, version, this._getFormattedError(error)));
            }
        });
    }
    getSiteExtensions() {
        return __awaiter(this, void 0, void 0, function* () {
            var httpRequest = new webClient.WebRequest();
            httpRequest.method = 'GET';
            httpRequest.uri = this.client.getRequestUri(`/api/siteextensions`, ['checkLatest=false']);
            try {
                var response = yield this.client.beginRequest(httpRequest);
                tl.debug(`getSiteExtensions. Data: ${JSON.stringify(response)}`);
                if (response.statusCode == 200) {
                    return response.body;
                }
                throw response;
            }
            catch (error) {
                throw Error(tl.loc('FailedToGetSiteExtensions', this._getFormattedError(error)));
            }
        });
    }
    getAllSiteExtensions() {
        return __awaiter(this, void 0, void 0, function* () {
            var httpRequest = new webClient.WebRequest();
            httpRequest.method = 'GET';
            httpRequest.uri = this.client.getRequestUri(`/api/extensionfeed`);
            try {
                var response = yield this.client.beginRequest(httpRequest);
                tl.debug(`getAllSiteExtensions. Data: ${JSON.stringify(response)}`);
                if (response.statusCode == 200) {
                    return response.body;
                }
                throw response;
            }
            catch (error) {
                throw Error(tl.loc('FailedToGetAllSiteExtensions', this._getFormattedError(error)));
            }
        });
    }
    getProcess(processID) {
        return __awaiter(this, void 0, void 0, function* () {
            var httpRequest = new webClient.WebRequest();
            httpRequest.method = 'GET';
            httpRequest.uri = this.client.getRequestUri(`/api/processes/${processID}`);
            try {
                var response = yield this.client.beginRequest(httpRequest);
                tl.debug(`getProcess. status code: ${response.statusCode} - ${response.statusMessage}`);
                if (response.statusCode == 200) {
                    return response.body;
                }
                throw response;
            }
            catch (error) {
                throw Error(tl.loc('FailedToGetProcess', this._getFormattedError(error)));
            }
        });
    }
    killProcess(processID) {
        return __awaiter(this, void 0, void 0, function* () {
            var httpRequest = new webClient.WebRequest();
            httpRequest.method = 'DELETE';
            httpRequest.uri = this.client.getRequestUri(`/api/processes/${processID}`);
            var reqOptions = {
                retriableErrorCodes: ["ETIMEDOUT"],
                retriableStatusCodes: [503],
                retryCount: 1,
                retryIntervalInSeconds: 5,
                retryRequestTimedout: true
            };
            try {
                var response = yield this.client.beginRequest(httpRequest, reqOptions);
                tl.debug(`killProcess. Data: ${JSON.stringify(response)}`);
                if (response.statusCode == 502) {
                    tl.debug(`Killed Process ${processID}`);
                    return;
                }
                throw response;
            }
            catch (error) {
                throw Error(tl.loc('FailedToKillProcess', this._getFormattedError(error)));
            }
        });
    }
    getAppSettings() {
        return __awaiter(this, void 0, void 0, function* () {
            var httpRequest = new webClient.WebRequest();
            httpRequest.method = 'GET';
            httpRequest.uri = this.client.getRequestUri(`/api/settings`);
            try {
                var response = yield this.client.beginRequest(httpRequest);
                tl.debug(`getAppSettings. Data: ${JSON.stringify(response)}`);
                if (response.statusCode == 200) {
                    return response.body;
                }
                throw response;
            }
            catch (error) {
                throw Error(tl.loc('FailedToFetchKuduAppSettings', this._getFormattedError(error)));
            }
        });
    }
    listDir(physicalPath) {
        return __awaiter(this, void 0, void 0, function* () {
            physicalPath = physicalPath.replace(/[\\]/g, "/");
            physicalPath = physicalPath[0] == "/" ? physicalPath.slice(1) : physicalPath;
            var httpRequest = new webClient.WebRequest();
            httpRequest.method = 'GET';
            httpRequest.uri = this.client.getRequestUri(`/api/vfs/${physicalPath}/`);
            httpRequest.headers = {
                'If-Match': '*'
            };
            try {
                var response = yield this.client.beginRequest(httpRequest);
                tl.debug(`listFiles. Data: ${JSON.stringify(response)}`);
                if ([200, 201, 204].indexOf(response.statusCode) != -1) {
                    return response.body;
                }
                else if (response.statusCode === 404) {
                    return null;
                }
                else {
                    throw response;
                }
            }
            catch (error) {
                throw Error(tl.loc('FailedToListPath', physicalPath, this._getFormattedError(error)));
            }
        });
    }
    getFileContent(physicalPath, fileName) {
        return __awaiter(this, void 0, void 0, function* () {
            physicalPath = physicalPath.replace(/[\\]/g, "/");
            physicalPath = physicalPath[0] == "/" ? physicalPath.slice(1) : physicalPath;
            var httpRequest = new webClient.WebRequest();
            httpRequest.method = 'GET';
            httpRequest.uri = this.client.getRequestUri(`/api/vfs/${physicalPath}/${fileName}`);
            httpRequest.headers = {
                'If-Match': '*'
            };
            try {
                var response = yield this.client.beginRequest(httpRequest);
                tl.debug(`getFileContent. Status code: ${response.statusCode} - ${response.statusMessage}`);
                if ([200, 201, 204].indexOf(response.statusCode) != -1) {
                    return response.body;
                }
                else if (response.statusCode === 404) {
                    return null;
                }
                else {
                    throw response;
                }
            }
            catch (error) {
                throw Error(tl.loc('FailedToGetFileContent', physicalPath, fileName, this._getFormattedError(error)));
            }
        });
    }
    uploadFile(physicalPath, fileName, filePath) {
        return __awaiter(this, void 0, void 0, function* () {
            physicalPath = physicalPath.replace(/[\\]/g, "/");
            physicalPath = physicalPath[0] == "/" ? physicalPath.slice(1) : physicalPath;
            if (!tl.exist(filePath)) {
                throw new Error(tl.loc('FilePathInvalid', filePath));
            }
            var httpRequest = new webClient.WebRequest();
            httpRequest.method = 'PUT';
            httpRequest.uri = this.client.getRequestUri(`/api/vfs/${physicalPath}/${fileName}`);
            httpRequest.headers = {
                'If-Match': '*'
            };
            httpRequest.body = fs.createReadStream(filePath);
            try {
                var response = yield this.client.beginRequest(httpRequest);
                tl.debug(`uploadFile. Data: ${JSON.stringify(response)}`);
                if ([200, 201, 204].indexOf(response.statusCode) != -1) {
                    return response.body;
                }
                throw response;
            }
            catch (error) {
                throw Error(tl.loc('FailedToUploadFile', physicalPath, fileName, this._getFormattedError(error)));
            }
        });
    }
    createPath(physicalPath) {
        return __awaiter(this, void 0, void 0, function* () {
            physicalPath = physicalPath.replace(/[\\]/g, "/");
            physicalPath = physicalPath[0] == "/" ? physicalPath.slice(1) : physicalPath;
            var httpRequest = new webClient.WebRequest();
            httpRequest.method = 'PUT';
            httpRequest.uri = this.client.getRequestUri(`/api/vfs/${physicalPath}/`);
            httpRequest.headers = {
                'If-Match': '*'
            };
            try {
                var response = yield this.client.beginRequest(httpRequest);
                tl.debug(`createPath. Data: ${JSON.stringify(response)}`);
                if ([200, 201, 204].indexOf(response.statusCode) != -1) {
                    return response.body;
                }
                throw response;
            }
            catch (error) {
                throw Error(tl.loc('FailedToCreatePath', physicalPath, this._getFormattedError(error)));
            }
        });
    }
    runCommand(physicalPath, command) {
        return __awaiter(this, void 0, void 0, function* () {
            var httpRequest = new webClient.WebRequest();
            httpRequest.method = 'POST';
            httpRequest.uri = this.client.getRequestUri(`/api/command`);
            httpRequest.headers = {
                'If-Match': '*'
            };
            httpRequest.body = JSON.stringify({
                'command': command,
                'dir': physicalPath
            });
            try {
                tl.debug('Executing Script on Kudu. Command: ' + command);
                let webRequestOptions = { retriableErrorCodes: null, retriableStatusCodes: null, retryCount: 5, retryIntervalInSeconds: 5, retryRequestTimedout: false };
                var response = yield this.client.beginRequest(httpRequest, webRequestOptions);
                tl.debug(`runCommand. Data: ${JSON.stringify(response)}`);
                if (response.statusCode == 200) {
                    return;
                }
                else {
                    throw response;
                }
            }
            catch (error) {
                throw Error(error.toString());
            }
        });
    }
    extractZIP(webPackage, physicalPath) {
        return __awaiter(this, void 0, void 0, function* () {
            physicalPath = physicalPath.replace(/[\\]/g, "/");
            physicalPath = physicalPath[0] == "/" ? physicalPath.slice(1) : physicalPath;
            var httpRequest = new webClient.WebRequest();
            httpRequest.method = 'PUT';
            httpRequest.uri = this.client.getRequestUri(`/api/zip/${physicalPath}/`);
            httpRequest.headers = {
                'Content-Type': 'multipart/form-data',
                'If-Match': '*'
            };
            httpRequest.body = fs.createReadStream(webPackage);
            try {
                var response = yield this.client.beginRequest(httpRequest);
                tl.debug(`extractZIP. Data: ${JSON.stringify(response)}`);
                if (response.statusCode == 200) {
                    return;
                }
                else {
                    throw response;
                }
            }
            catch (error) {
                throw Error(tl.loc('Failedtodeploywebapppackageusingkuduservice', this._getFormattedError(error)));
            }
        });
    }
    zipDeploy(webPackage, queryParameters, addChecksumHeader) {
        return __awaiter(this, void 0, void 0, function* () {
            let httpRequest = new webClient.WebRequest();
            httpRequest.method = 'POST';
            httpRequest.uri = this.client.getRequestUri(`/api/zipdeploy`, queryParameters);
            var rs = fs.createReadStream(webPackage);
            var checksum = undefined;
            httpRequest.body = rs;
            httpRequest.headers = {
                'Content-Type': 'application/octet-stream'
            };
            if (addChecksumHeader !== undefined && addChecksumHeader) {
                checksum = yield this._computeFileChecksum(rs);
                if (checksum !== undefined) {
                    httpRequest.headers["x-ms-artifact-checksum"] = checksum;
                }
            }
            try {
                let response = yield this.client.beginRequest(httpRequest);
                tl.debug(`ZIP Deploy response: ${JSON.stringify(response)}`);
                if (response.statusCode == 200) {
                    tl.debug('Deployment passed');
                    return null;
                }
                else if (response.statusCode == 202) {
                    let pollableURL = response.headers.location;
                    if (!!pollableURL) {
                        tl.debug(`Polling for ZIP Deploy URL: ${pollableURL}`);
                        return yield this._getDeploymentDetailsFromPollURL(pollableURL);
                    }
                    else {
                        tl.debug('zip deploy returned 202 without pollable URL.');
                        return null;
                    }
                }
                else {
                    throw response;
                }
            }
            catch (error) {
                throw new Error(tl.loc('PackageDeploymentFailed', this._getFormattedError(error)));
            }
        });
    }
    warDeploy(webPackage, queryParameters) {
        return __awaiter(this, void 0, void 0, function* () {
            let httpRequest = new webClient.WebRequest();
            httpRequest.method = 'POST';
            httpRequest.uri = this.client.getRequestUri(`/api/wardeploy`, queryParameters);
            httpRequest.body = fs.createReadStream(webPackage);
            httpRequest.headers = {
                'Content-Type': 'application/octet-stream'
            };
            try {
                let response = yield this.client.beginRequest(httpRequest);
                tl.debug(`War Deploy response: ${JSON.stringify(response)}`);
                if (response.statusCode == 200) {
                    tl.debug('Deployment passed');
                    return null;
                }
                else if (response.statusCode == 202) {
                    let pollableURL = response.headers.location;
                    if (!!pollableURL) {
                        tl.debug(`Polling for War Deploy URL: ${pollableURL}`);
                        return yield this._getDeploymentDetailsFromPollURL(pollableURL);
                    }
                    else {
                        tl.debug('war deploy returned 202 without pollable URL.');
                        return null;
                    }
                }
                else {
                    throw response;
                }
            }
            catch (error) {
                throw new Error(tl.loc('PackageDeploymentFailed', this._getFormattedError(error)));
            }
        });
    }
    oneDeploy(webPackage, queryParameters, addChecksumHeader) {
        return __awaiter(this, void 0, void 0, function* () {
            let httpRequest = new webClient.WebRequest();
            httpRequest.method = 'POST';
            httpRequest.uri = this.client.getRequestUri(`/api/publish`, queryParameters);
            var rs = fs.createReadStream(webPackage);
            var checksum = undefined;
            httpRequest.body = rs;
            httpRequest.headers = httpRequest.headers || {};
            if (addChecksumHeader !== undefined && addChecksumHeader) {
                checksum = yield this._computeFileChecksum(rs);
                if (checksum !== undefined) {
                    httpRequest.headers["x-ms-artifact-checksum"] = checksum;
                }
            }
            let requestOptions = new webClient.WebRequestOptions();
            //Bydefault webclient.sendRequest retries for  [500, 502, 503, 504]
            requestOptions.retriableStatusCodes = [500, 502, 503, 504];
            requestOptions.retryIntervalInSeconds = 5;
            try {
                let response = yield this.client.beginRequest(httpRequest, requestOptions, 'application/octet-stream');
                tl.debug(`OneDeploy response: ${JSON.stringify(response)}`);
                if (response.statusCode == 200) {
                    tl.debug('Deployment passed');
                    return null;
                }
                else if (response.statusCode == 202) {
                    let pollableURL = response.headers.location;
                    if (!!pollableURL) {
                        tl.debug(`Polling for OneDeploy URL: ${pollableURL}`);
                        return yield this._getDeploymentDetailsFromPollURL(pollableURL);
                    }
                    else {
                        tl.debug('OneDeploy returned 202 without pollable URL.');
                        return null;
                    }
                }
                else {
                    throw response;
                }
            }
            catch (error) {
                throw new Error(tl.loc('PackageDeploymentFailed', this._getFormattedError(error)));
            }
        });
    }
    getDeploymentDetails(deploymentID) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                var httpRequest = new webClient.WebRequest();
                httpRequest.method = 'GET';
                httpRequest.uri = this.client.getRequestUri(`/api/deployments/${deploymentID}`);
                ;
                var response = yield this.client.beginRequest(httpRequest);
                tl.debug(`getDeploymentDetails. Data: ${JSON.stringify(response)}`);
                if (response.statusCode == 200) {
                    return response.body;
                }
                throw response;
            }
            catch (error) {
                throw Error(tl.loc('FailedToGetDeploymentLogs', this._getFormattedError(error)));
            }
        });
    }
    getDeploymentLogs(log_url) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                var httpRequest = new webClient.WebRequest();
                httpRequest.method = 'GET';
                httpRequest.uri = log_url;
                var response = yield this.client.beginRequest(httpRequest);
                tl.debug(`getDeploymentLogs. Data: ${JSON.stringify(response)}`);
                if (response.statusCode == 200) {
                    return response.body;
                }
                throw response;
            }
            catch (error) {
                throw Error(tl.loc('FailedToGetDeploymentLogs', this._getFormattedError(error)));
            }
        });
    }
    deleteFile(physicalPath, fileName) {
        return __awaiter(this, void 0, void 0, function* () {
            physicalPath = physicalPath.replace(/[\\]/g, "/");
            physicalPath = physicalPath[0] == "/" ? physicalPath.slice(1) : physicalPath;
            var httpRequest = new webClient.WebRequest();
            httpRequest.method = 'DELETE';
            httpRequest.uri = this.client.getRequestUri(`/api/vfs/${physicalPath}/${fileName}`);
            httpRequest.headers = {
                'If-Match': '*'
            };
            try {
                var response = yield this.client.beginRequest(httpRequest);
                tl.debug(`deleteFile. Data: ${JSON.stringify(response)}`);
                if ([200, 201, 204, 404].indexOf(response.statusCode) != -1) {
                    return;
                }
                else {
                    throw response;
                }
            }
            catch (error) {
                throw Error(tl.loc('FailedToDeleteFile', physicalPath, fileName, this._getFormattedError(error)));
            }
        });
    }
    deleteFolder(physicalPath) {
        return __awaiter(this, void 0, void 0, function* () {
            physicalPath = physicalPath.replace(/[\\]/g, "/");
            physicalPath = physicalPath[0] == "/" ? physicalPath.slice(1) : physicalPath;
            var httpRequest = new webClient.WebRequest();
            httpRequest.method = 'DELETE';
            httpRequest.uri = this.client.getRequestUri(`/api/vfs/${physicalPath}`);
            httpRequest.headers = {
                'If-Match': '*'
            };
            try {
                var response = yield this.client.beginRequest(httpRequest);
                tl.debug(`deleteFolder. Data: ${JSON.stringify(response)}`);
                if ([200, 201, 204, 404].indexOf(response.statusCode) != -1) {
                    return;
                }
                else {
                    throw response;
                }
            }
            catch (error) {
                throw Error(tl.loc('FailedToDeleteFolder', physicalPath, this._getFormattedError(error)));
            }
        });
    }
    _getDeploymentDetailsFromPollURL(pollURL) {
        return __awaiter(this, void 0, void 0, function* () {
            let httpRequest = new webClient.WebRequest();
            httpRequest.method = 'GET';
            httpRequest.uri = pollURL;
            httpRequest.headers = {};
            while (true) {
                let response = yield this.client.beginRequest(httpRequest);
                if (response.statusCode == 200 || response.statusCode == 202) {
                    var result = response.body;
                    tl.debug(`POLL URL RESULT: ${JSON.stringify(response)}`);
                    if (result.status == constants_1.KUDU_DEPLOYMENT_CONSTANTS.SUCCESS || result.status == constants_1.KUDU_DEPLOYMENT_CONSTANTS.FAILED) {
                        return result;
                    }
                    else {
                        tl.debug(`Deployment status: ${result.status} '${result.status_text}'. retry after 5 seconds`);
                        yield webClient.sleepFor(5);
                        continue;
                    }
                }
                else {
                    throw response;
                }
            }
        });
    }
    _getFormattedError(error) {
        if (error && error.statusCode) {
            return `${error.statusMessage} (CODE: ${error.statusCode})`;
        }
        else if (error && error.message) {
            if (error.statusCode) {
                error.message = `${typeof error.message.valueOf() == 'string' ? error.message : error.message.Code + " - " + error.message.Message} (CODE: ${error.statusCode})`;
            }
            return error.message;
        }
        return error;
    }
    _computeFileChecksum(stream) {
        return new Promise((resolve, reject) => {
            const hash = crypto.createHash('sha256');
            stream.on('data', (data) => {
                hash.update(data);
            });
            stream.on('end', () => {
                const result = hash.digest('hex');
                resolve(result);
            });
            stream.on('error', (error) => {
                resolve(undefined);
            });
        });
    }
    /**
     * Warms up the Kudu service using the dedicated warmup endpoint.
     * Uses /api/deployments?warmup=true with retry logic.
     */
    warmup() {
        return __awaiter(this, void 0, void 0, function* () {
            var httpRequest = new webClient.WebRequest();
            httpRequest.method = 'GET';
            httpRequest.uri = this.client.getRequestUri(`/api/deployments`, ['warmup=true']);
            const maxRetries = 2;
            for (let attempt = 1; attempt <= maxRetries; attempt++) {
                try {
                    tl.debug(`Kudu warmup attempt ${attempt}/${maxRetries}`);
                    var reqOptions = {
                        retriableErrorCodes: ["ETIMEDOUT"],
                        retriableStatusCodes: [503],
                        retryCount: 0,
                        retryIntervalInSeconds: 5,
                        retryRequestTimedout: true
                    };
                    var response = yield this.client.beginRequest(httpRequest, reqOptions);
                    if (response.statusCode >= 200 && response.statusCode < 300) {
                        tl.debug('Kudu warmup successful');
                        return;
                    }
                    tl.debug(`Kudu warmup returned status ${response.statusCode}`);
                }
                catch (error) {
                    tl.debug(`Kudu warmup attempt ${attempt} failed: ${error}`);
                }
            }
            tl.debug('Kudu warmup failed after all retries, proceeding without warmup');
        });
    }
}
exports.Kudu = Kudu;
// Fix for MSRC 125166 / ICM 31000000654080.
//
// Consuming tasks (AzureRmWebAppDeployment, AzureWebApp, AzureFunctionApp and their container
// variants) echo remote, cross-trust-boundary content fetched via Kudu.getFileContent /
// Kudu.getDeploymentLogs (Kudu/Oryx deployment build logs, post-deployment script stdout/stderr)
// verbatim via console.log() before printing. The Azure Pipelines agent scans ALL task stdout
// for the literal sequence "##vso[" and executes any matching logging command it finds,
// regardless of which line of code produced it. Because the Oryx build log is populated by
// whatever the application's build (e.g. npm install -> postinstall) prints - content that may
// be authored by a lower-trust party than the pipeline definition (external contributors,
// transitive npm dependencies) - an attacker who only controls the app SOURCE can get arbitrary
// ##vso commands (task.setvariable, task.setsecret, task.setendpoint, ...) executed at full
// pipeline/agent trust, without ever touching the pipeline YAML.
//
// IMPORTANT: this helper is intentionally NOT applied inside Kudu.getFileContent /
// Kudu.getDeploymentLogs themselves. Those methods are generic file/log fetchers reused by
// callers for non-print, data-purpose reads too (e.g. manifest file contents, active deployment
// IDs compared for equality, script return codes compared to '0'). Mutating the returned string
// at that layer would risk corrupting those comparisons/parses. Sanitization must be applied by
// each caller only at the point where fetched content is about to be printed to the console.
// It is kept in this file (rather than a separate module) so it stays co-located with the Kudu
// class whose output it exists to sanitize.
//
// Enforcement rollout is gated behind a pipeline feature (checked via tl.getPipelineFeature,
// which reads the "DistributedTask.Tasks.<name>" pipeline variable) - tl.getBoolFeatureFlag is
// deprecated in favor of tl.getPipelineFeature and is intentionally not used here:
//   EnableKuduLogVsoCommandSanitization -> ENFORCE: neutralize the "##vso[" trigger sequence
//                                          before printing, so the content can no longer be
//                                          parsed as a logging command by the agent.
//
// Detection telemetry is NOT feature-gated: whenever a ##vso[...] command is detected in
// remote log content, it is always reported via telemetry.publish (regardless of the feature
// above), so real-world impact/prevalence can be measured before and after enforcement ramps.
// This is safe to always emit unconditionally because the telemetry payload itself is fully
// controlled by this code (fixed keys, command names extracted from a bounded regex) - it is
// not remote/attacker content.
//
// If no ##vso[...] pattern is present in the text, this is a no-op (no telemetry emitted for
// clean logs).
// Used only to decide whether there is anything to do at all (telemetry and/or enforcement).
// Intentionally NOT restricted to any command-name charset, so the kill switch below does not
// depend on the agent's current command-name parsing rules - any "##vso[" (or leading "##[")
// occurrence is treated as something to neutralize when enforcement is on.
const VSO_COMMAND_PRESENCE_REGEX = /##vso\[/i;
// Used only to name detected commands for telemetry. This charset is a best-effort label and
// intentionally must NOT be used to decide whether enforcement/telemetry should run - see
// VSO_COMMAND_PRESENCE_REGEX above for that gate.
const VSO_COMMAND_NAME_REGEX = /##vso\[([a-zA-Z0-9_.]+)/gi;
const KUDU_LOG_SANITIZER_TELEMETRY_AREA = 'TaskHub';
const KUDU_LOG_SANITIZER_ENFORCE_PIPELINE_FEATURE = 'EnableKuduLogVsoCommandSanitization';
// For telemetry naming only - see comment on VSO_COMMAND_NAME_REGEX above.
function findVsoCommands(text) {
    const found = new Set();
    let match;
    const regex = new RegExp(VSO_COMMAND_NAME_REGEX);
    while ((match = regex.exec(text)) !== null) {
        found.add(match[1].toLowerCase());
    }
    return Array.from(found);
}
// Emits telemetry using the same "##vso[telemetry.publish ...]" channel as
// azure-pipelines-tasks-utility-common/telemetry, without adding a new dependency to this
// package for a small, self-issued payload.
function emitKuduLogSanitizerDetectionTelemetry(feature, enforced, commands) {
    try {
        const payload = {
            event: enforced ? 'KuduLogVsoCommandsSanitized' : 'KuduLogVsoCommandsDetected',
            enforced: enforced,
            commandCount: commands.length,
            commands: commands.join(',')
        };
        console.log(`##vso[telemetry.publish area=${KUDU_LOG_SANITIZER_TELEMETRY_AREA};feature=${feature}]${JSON.stringify(payload)}`);
    }
    catch (err) {
        tl.debug(`sanitizeKuduLogForConsole: failed to emit telemetry: ${err}`);
    }
}
/**
 * Pipeline-feature gated sanitizer for remote Kudu/Oryx log content, to be called by task code
 * immediately before printing content obtained from Kudu.getFileContent / Kudu.getDeploymentLogs
 * (see the comment above for the full rationale and feature name).
 *
 * @param text the raw remote log content about to be printed to the console.
 * @param telemetryFeature the `feature` value to tag emitted telemetry with - callers should
 *        pass a value identifying their own task (e.g. 'AzureRmWebAppDeployment',
 *        'AzureFunctionApp') so telemetry can be attributed correctly.
 *
 * - Detection telemetry always runs: if `text` contains any ##vso[...] command sequence, it is
 *   always reported via telemetry.publish, regardless of the pipeline feature state.
 * - EnableKuduLogVsoCommandSanitization off (default today): text is returned completely
 *   unmodified - telemetry-only, zero behavior change for customers.
 * - EnableKuduLogVsoCommandSanitization on: enforce. Neutralizes the "##vso[" (and leading
 *   "##[") trigger sequences so the agent can no longer parse them as logging commands.
 */
function sanitizeKuduLogForConsole(text, telemetryFeature) {
    if (!text || !VSO_COMMAND_PRESENCE_REGEX.test(text)) {
        return text;
    }
    const activate = tl.getPipelineFeature(KUDU_LOG_SANITIZER_ENFORCE_PIPELINE_FEATURE);
    // Command names are extracted purely for telemetry labeling - see comment on
    // VSO_COMMAND_NAME_REGEX/findVsoCommands above. Whether we got here (and whether we
    // enforce below) is decided solely by VSO_COMMAND_PRESENCE_REGEX.
    emitKuduLogSanitizerDetectionTelemetry(telemetryFeature, activate, findVsoCommands(text));
    if (!activate) {
        // Telemetry-only: report above, but do not touch the text that gets printed.
        return text;
    }
    return text.replace(/##vso\[/gi, '##_vso[').replace(/^##\[/gm, '##_[');
}
exports.sanitizeKuduLogForConsole = sanitizeKuduLogForConsole;
