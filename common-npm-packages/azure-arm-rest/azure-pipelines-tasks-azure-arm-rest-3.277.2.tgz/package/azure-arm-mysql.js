"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MysqlServers = exports.FirewallRules = exports.AzureMysqlManagementClient = void 0;
const path = require("path");
const tl = require("azure-pipelines-task-lib/task");
const Q = require("q");
const azureServiceClient = require("./AzureServiceClient");
const azureServiceClientBase = require("./AzureServiceClientBase");
const constants = require("./constants");
const webClient = require("./webClient");
tl.setResourcePath(path.join(__dirname, 'module.json'), true);
class AzureMysqlManagementClient extends azureServiceClient.ServiceClient {
    constructor(credentials, subscriptionId, baseUri, options) {
        super(credentials, subscriptionId);
        this.apiVersion = constants.mysqlApiVersion;
        this.acceptLanguage = 'en-US';
        this.generateClientRequestId = true;
        if (!options)
            options = {};
        if (baseUri) {
            this.baseUri = baseUri;
        }
        if (options.apiVersion) {
            this.apiVersion = options.apiVersion;
        }
        if (options.acceptLanguage) {
            this.acceptLanguage = options.acceptLanguage;
        }
        if (options.longRunningOperationRetryTimeout) {
            this.longRunningOperationRetryTimeout = options.longRunningOperationRetryTimeout;
        }
        if (options.generateClientRequestId) {
            this.generateClientRequestId = options.generateClientRequestId;
        }
        this.firewallRules = new FirewallRules(this);
        this.mysqlServers = new MysqlServers(this);
    }
}
exports.AzureMysqlManagementClient = AzureMysqlManagementClient;
class FirewallRules {
    constructor(client) {
        this.client = client;
    }
    /**
     * Create or update firewall rule for mysql server
     * @param resourceGroupName     resource group name of mysql server
     * @param serverName            mysql server name
     * @param firewallRuleName      rule name to be added or updated
     * @param parameters            optional parameter like start and end ip address
     * @param callback              response callback
     */
    createOrUpdate(resourceGroupName, serverName, firewallRuleName, parameters, callback) {
        var client = this.client;
        if (!callback) {
            throw new Error(tl.loc("CallbackCannotBeNull"));
        }
        // Validate
        try {
            this.client.isValidResourceGroupName(resourceGroupName);
            if (!this.client.isNameValid(serverName)) {
                throw new Error(tl.loc("MysqlServerNameCannotBeEmpty"));
            }
            if (!this.client.isNameValid(firewallRuleName)) {
                throw new Error(tl.loc("FirewallRuleNameCannotBeNull"));
            }
        }
        catch (error) {
            return callback(error);
        }
        var httpRequest = new webClient.WebRequest();
        httpRequest.method = 'PUT';
        httpRequest.headers = {};
        httpRequest.uri = this.client.getRequestUri('//subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.DBforMySQL/servers/{serverName}/firewallRules/{firewallRuleName}', {
            '{resourceGroupName}': resourceGroupName,
            '{serverName}': serverName,
            '{firewallRuleName}': firewallRuleName
        });
        if (parameters !== null && parameters !== undefined) {
            httpRequest.body = JSON.stringify(parameters);
        }
        this.client.beginRequest(httpRequest).then((response) => __awaiter(this, void 0, void 0, function* () {
            var deferred = Q.defer();
            var statusCode = response.statusCode;
            tl.debug("Response for add firewall rule " + statusCode);
            if (statusCode != 200 && statusCode != 201 && statusCode != 202) {
                // Generate Error
                deferred.reject(new azureServiceClientBase.ApiResult(azureServiceClientBase.ToError(response)));
            }
            else if (statusCode === 202) {
                this._recursiveGetCall(resourceGroupName, serverName, firewallRuleName, 5, 0).then((response) => {
                    deferred.resolve(new azureServiceClientBase.ApiResult(null, response));
                }, (error) => {
                    deferred.reject(error);
                });
            }
            else {
                // Generate Response
                deferred.resolve(new azureServiceClientBase.ApiResult(null, response.body));
            }
            return deferred.promise;
        })).then((apiResult) => callback(apiResult.error, apiResult.result), (error) => callback(error));
    }
    /**
     * Delete firewall rule of mysql server
     * @param resourceGroupName     resource group name of mysql server
     * @param serverName            mysql server name
     * @param firewallRuleName      firewall rule name to be deleted
     * @param callback              response callback
     */
    delete(resourceGroupName, serverName, firewallRuleName, callback) {
        var client = this.client;
        if (!callback) {
            throw new Error(tl.loc("CallbackCannotBeNull"));
        }
        // Validate
        try {
            this.client.isValidResourceGroupName(resourceGroupName);
            if (!this.client.isNameValid(serverName)) {
                throw new Error(tl.loc("MysqlServerNameCannotBeEmpty"));
            }
            if (!this.client.isNameValid(firewallRuleName)) {
                throw new Error(tl.loc("FirewallRuleNameCannotBeNull"));
            }
        }
        catch (error) {
            return callback(error);
        }
        var httpRequest = new webClient.WebRequest();
        httpRequest.method = 'DELETE';
        httpRequest.headers = {};
        httpRequest.uri = this.client.getRequestUri('//subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.DBforMySQL/servers/{serverName}/firewallRules/{firewallRuleName}', {
            '{resourceGroupName}': resourceGroupName,
            '{serverName}': serverName,
            '{firewallRuleName}': firewallRuleName
        });
        this.client.beginRequest(httpRequest).then((response) => __awaiter(this, void 0, void 0, function* () {
            var deferred = Q.defer();
            var statusCode = response.statusCode;
            tl.debug("Response for delete firewall rule " + statusCode);
            if (statusCode != 200 && statusCode != 202 && statusCode != 204) {
                // Generate Error
                deferred.reject(new azureServiceClientBase.ApiResult(azureServiceClientBase.ToError(response)));
            }
            else {
                // Generate Response
                deferred.resolve(new azureServiceClientBase.ApiResult(null, response.body));
            }
            return deferred.promise;
        })).then((apiResult) => callback(apiResult.error, apiResult.result), (error) => callback(error));
    }
    /**
     * Get firewall rule of mysql server
     * @param resourceGroupName     resource group name of mysql server
     * @param serverName            mysql server name
     * @param firewallRuleName      firewall rule name to be deleted
     * @param callback              response callback
     */
    get(resourceGroupName, serverName, firewallRuleName, callback) {
        var client = this.client;
        if (!callback) {
            throw new Error(tl.loc("CallbackCannotBeNull"));
        }
        // Validate
        try {
            this.client.isValidResourceGroupName(resourceGroupName);
            if (!this.client.isNameValid(serverName)) {
                throw new Error(tl.loc("MysqlServerNameCannotBeEmpty"));
            }
            if (!this.client.isNameValid(firewallRuleName)) {
                throw new Error(tl.loc("FirewallRuleNameCannotBeNull"));
            }
        }
        catch (error) {
            return callback(error);
        }
        var httpRequest = new webClient.WebRequest();
        httpRequest.method = 'GET';
        httpRequest.headers = {};
        httpRequest.uri = this.client.getRequestUri('//subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.DBforMySQL/servers/{serverName}/firewallRules/{firewallRuleName}', {
            '{resourceGroupName}': resourceGroupName,
            '{serverName}': serverName,
            '{firewallRuleName}': firewallRuleName
        });
        tl.debug("Calling get firewall ");
        this.client.beginRequest(httpRequest).then((response) => __awaiter(this, void 0, void 0, function* () {
            var deferred = Q.defer();
            var statusCode = response.statusCode;
            tl.debug("Response for get firewall rule " + JSON.stringify(response));
            if (statusCode === 200) {
                // Generate Response
                deferred.resolve(new azureServiceClientBase.ApiResult(null, response));
            }
            else {
                // Generate exception
                deferred.reject(new azureServiceClientBase.ApiResult(azureServiceClientBase.ToError(response)));
            }
            return deferred.promise;
        })).then((apiResult) => callback(apiResult.error, apiResult.result), (error) => callback(error));
    }
    /**
     * Retry get call to check firewall rule has added or not
     * @param resourceGroupName     resource group name of mysql server
     * @param serverName            mysql server name
     * @param firewallRuleName      firewall rule name to be deleted
     * @param retryOption           no of time to retry
     */
    _recursiveGetCall(resourceGroupName, serverName, firewallRuleName, retryOption, timeToWait) {
        var deferred = Q.defer();
        let waitedTime = 2000 + timeToWait * 2;
        setTimeout(() => {
            this.get(resourceGroupName, serverName, firewallRuleName, (error, result, request, response) => {
                if (error) {
                    if (retryOption > 0) {
                        deferred.resolve(this._recursiveGetCall(resourceGroupName, serverName, firewallRuleName, retryOption - 1, waitedTime));
                    }
                    else {
                        deferred.reject(new Error(tl.loc("NotAbleToCreateFirewallRule", error)));
                    }
                }
                else {
                    deferred.resolve(new azureServiceClientBase.ApiResult(null, result));
                }
            });
        }, waitedTime);
        return deferred.promise;
    }
}
exports.FirewallRules = FirewallRules;
class MysqlServers {
    constructor(client) {
        this.client = client;
    }
    /**
     * Get all the mysql server belongs to one subscription
     * @param callback  Response callback
     */
    list(callback) {
        if (!callback) {
            throw new Error(tl.loc("CallbackCannotBeNull"));
        }
        // Create HTTP transport objects
        var httpRequest = new webClient.WebRequest();
        httpRequest.method = 'GET';
        httpRequest.headers = {};
        httpRequest.uri = this.client.getRequestUri('//subscriptions/{subscriptionId}/providers/Microsoft.DBforMySQL/servers', {});
        // Set body to be null
        httpRequest.body = null;
        //send request
        var result = [];
        this.client.beginRequest(httpRequest).then((response) => __awaiter(this, void 0, void 0, function* () {
            if (response.statusCode == 200) {
                if (response.body.value) {
                    result = result.concat(response.body.value);
                }
                if (response.body.nextLink) {
                    var nextResult = yield this.client.accumulateResultFromPagedResult(response.body.nextLink);
                    if (nextResult.error) {
                        return new azureServiceClientBase.ApiResult(nextResult.error);
                    }
                    result.concat(nextResult.result);
                }
                return new azureServiceClientBase.ApiResult(null, result);
            }
            else {
                return new azureServiceClientBase.ApiResult(azureServiceClientBase.ToError(response));
            }
        })).then((apiResult) => callback(apiResult.error, apiResult.result), (error) => callback(error));
    }
}
exports.MysqlServers = MysqlServers;
