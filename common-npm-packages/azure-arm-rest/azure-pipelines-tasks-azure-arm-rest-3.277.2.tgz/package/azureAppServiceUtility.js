"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AzureAppServiceUtility = void 0;
const tl = require("azure-pipelines-task-lib/task");
const Q = require("q");
var parseString = require('xml2js').parseString;
const azure_arm_app_service_kudu_1 = require("./azure-arm-app-service-kudu");
const webClient = require("./webClient");
const SiteContainer_1 = require("./SiteContainer");
class AzureAppServiceUtility {
    constructor(appService, telemetryFeature) {
        this._appService = appService;
        this._telemetryFeature = telemetryFeature || "AzureAppServiceDeployment"; //TODO modify telemetry.publish command so that agent automatically pass task name and version to the server then remove this parameter
    }
    getWebDeployPublishingProfile() {
        return __awaiter(this, void 0, void 0, function* () {
            var publishingProfile = yield this._appService.getPublishingProfileWithSecrets();
            var defer = Q.defer();
            parseString(publishingProfile, (error, result) => {
                if (!!error) {
                    defer.reject(error);
                }
                var publishProfile = result && result.publishData && result.publishData.publishProfile ? result.publishData.publishProfile : null;
                if (publishProfile) {
                    for (var index in publishProfile) {
                        if (publishProfile[index].$ && publishProfile[index].$.publishMethod === "MSDeploy") {
                            defer.resolve(result.publishData.publishProfile[index].$);
                        }
                    }
                }
                defer.reject(tl.loc('ErrorNoSuchDeployingMethodExists'));
            });
            return defer.promise;
        });
    }
    getApplicationURL(virtualApplication) {
        return __awaiter(this, void 0, void 0, function* () {
            let webDeployProfile = yield this.getWebDeployPublishingProfile();
            return (yield webDeployProfile.destinationAppUrl) + (virtualApplication ? "/" + virtualApplication : "");
        });
    }
    pingApplication() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                var applicationUrl = yield this.getApplicationURL();
                if (!applicationUrl) {
                    tl.debug('Application Url not found.');
                    return;
                }
                var webRequest = new webClient.WebRequest();
                webRequest.method = 'GET';
                webRequest.uri = applicationUrl;
                let webRequestOptions = { retriableErrorCodes: [], retriableStatusCodes: [], retryCount: 1, retryIntervalInSeconds: 5, retryRequestTimedout: true };
                var response = yield webClient.sendRequest(webRequest, webRequestOptions);
                tl.debug(`App Service status Code: '${response.statusCode}'. Status Message: '${response.statusMessage}'`);
            }
            catch (error) {
                tl.debug(`Unable to ping App Service. Error: ${error}`);
            }
        });
    }
    getPhysicalPath(virtualApplication) {
        return __awaiter(this, void 0, void 0, function* () {
            if (!virtualApplication) {
                return '/site/wwwroot';
            }
            virtualApplication = (virtualApplication.startsWith("/")) ? virtualApplication.substring(1) : virtualApplication;
            // construct URL depending on virtualApplication or root of webapplication
            var physicalPath = null;
            var virtualPath = "/" + virtualApplication;
            var appConfigSettings = yield this._appService.getConfiguration();
            var virtualApplicationMappings = appConfigSettings.properties && appConfigSettings.properties.virtualApplications;
            if (virtualApplicationMappings) {
                for (var mapping of virtualApplicationMappings) {
                    if (mapping.virtualPath.toLowerCase() == virtualPath.toLowerCase()) {
                        physicalPath = mapping.physicalPath;
                        break;
                    }
                }
            }
            var physicalToVirtualPathMap = physicalPath
                ? { 'virtualPath': virtualPath, 'physicalPath': physicalPath }
                : null;
            if (!physicalToVirtualPathMap) {
                throw Error(tl.loc("VirtualApplicationDoesNotExist", virtualApplication));
            }
            tl.debug(`Virtual Application Map: Physical path: '${physicalToVirtualPathMap.physicalPath}'. Virtual path: '${physicalToVirtualPathMap.virtualPath}'.`);
            return physicalToVirtualPathMap.physicalPath;
        });
    }
    /**
     * Gets a Kudu service client for deployments.
     * @param warmupInstanceId Optional instance ID for SPN auth to pin all requests to a single instance (ARRAffinity cookie)
     */
    getKuduService(warmupInstanceId) {
        return __awaiter(this, void 0, void 0, function* () {
            // Build cookie if warmupInstanceId is provided (for SPN to pin to specific instance)
            const cookie = warmupInstanceId
                ? [`ARRAffinity=${warmupInstanceId}`, `ARRAffinitySameSite=${warmupInstanceId}`]
                : undefined;
            const publishingCredentials = yield this._appService.getPublishingCredentials();
            const scmUri = publishingCredentials.properties["scmUri"];
            if (!scmUri) {
                throw Error(tl.loc('KuduSCMDetailsAreEmpty'));
            }
            const authHeader = yield this.getKuduAuthHeader(publishingCredentials);
            // For publish profile, don't pass cookie - it will be captured from response
            return new azure_arm_app_service_kudu_1.Kudu(publishingCredentials.properties["scmUri"], authHeader, cookie);
        });
    }
    getKuduAuthHeader(publishingCredentials) {
        return __awaiter(this, void 0, void 0, function* () {
            const scmPolicyCheck = yield this.isSitePublishingCredentialsEnabled();
            let token = "";
            let method = "";
            const password = publishingCredentials.properties["publishingPassword"];
            if (scmPolicyCheck === false) {
                token = yield this._appService._client.getCredentials().acquireTokenForScope("appservice");
                method = "Bearer";
                // Though bearer AuthN is used, lets try to set publish profile password for mask hints to maintain compat with old behavior for MSDEPLOY.
                // This needs to be cleaned up once MSDEPLOY suppport is removed. Safe handle the exception setting up mask hint as we dont want to fail here.
                try {
                    tl.setVariable(`AZURE_APP_MSDEPLOY_${this._appService.getSlot()}_PASSWORD`, password, true);
                }
                catch (error) {
                    // safe handle the exception setting up mask hint
                    tl.debug(`Setting mask hint for publish profile password failed with error: ${error}`);
                }
            }
            else {
                tl.setVariable(`AZURE_APP_SERVICE_KUDU_${this._appService.getSlot()}_PASSWORD`, password, true);
                const userName = publishingCredentials.properties["publishingUserName"];
                const buffer = Buffer.from(userName + ':' + password);
                token = buffer.toString('base64');
                method = "Basic";
            }
            const authMethodtelemetry = {
                authMethod: method
            };
            tl.debug(`Using ${method} authentication method for Kudu service.`);
            console.log(`##vso[telemetry.publish area=TaskDeploymentMethod;feature=${this._telemetryFeature}]${JSON.stringify(authMethodtelemetry)}`);
            return method + " " + token;
        });
    }
    updateAndMonitorAppSettings(addProperties, deleteProperties, formatJSON, perSlot = true) {
        return __awaiter(this, void 0, void 0, function* () {
            if (formatJSON) {
                var appSettingsProperties = {};
                for (var property in addProperties) {
                    appSettingsProperties[addProperties[property].name] = addProperties[property].value;
                }
                if (!!addProperties) {
                    console.log(tl.loc('UpdatingAppServiceApplicationSettings', JSON.stringify(appSettingsProperties)));
                }
                if (!!deleteProperties) {
                    console.log(tl.loc('DeletingAppServiceApplicationSettings', JSON.stringify(Object.keys(deleteProperties))));
                }
                var isNewValueUpdated = yield this._appService.patchApplicationSettings(appSettingsProperties, deleteProperties, true);
            }
            else {
                for (var property in addProperties) {
                    if (!!addProperties[property] && addProperties[property].value !== undefined) {
                        addProperties[property] = addProperties[property].value;
                    }
                }
                if (!!addProperties) {
                    console.log(tl.loc('UpdatingAppServiceApplicationSettings', JSON.stringify(addProperties)));
                }
                if (!!deleteProperties) {
                    console.log(tl.loc('DeletingAppServiceApplicationSettings', JSON.stringify(Object.keys(deleteProperties))));
                }
                var isNewValueUpdated = yield this._appService.patchApplicationSettings(addProperties, deleteProperties);
            }
            if (!!isNewValueUpdated) {
                console.log(tl.loc('UpdatedAppServiceApplicationSettings'));
            }
            else {
                console.log(tl.loc('AppServiceApplicationSettingsAlreadyPresent'));
            }
            if (perSlot) {
                yield this._appService.patchApplicationSettingsSlot(addProperties);
            }
            return isNewValueUpdated;
        });
    }
    enableRenameLockedFiles() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                var webAppSettings = yield this._appService.getApplicationSettings();
                if (webAppSettings && webAppSettings.properties) {
                    if (webAppSettings.properties.MSDEPLOY_RENAME_LOCKED_FILES !== '1') {
                        tl.debug(`Rename locked files value found to be ${webAppSettings.properties.MSDEPLOY_RENAME_LOCKED_FILES}. Updating the value to 1`);
                        yield this.updateAndMonitorAppSettings({ 'MSDEPLOY_RENAME_LOCKED_FILES': '1' });
                        console.log(tl.loc('RenameLockedFilesEnabled'));
                    }
                    else {
                        tl.debug('Rename locked files is already enabled in App Service');
                    }
                }
            }
            catch (error) {
                throw new Error(tl.loc('FailedToEnableRenameLockedFiles', error));
            }
        });
    }
    updateStartupCommandAndRuntimeStack(runtimeStack, startupCommand) {
        return __awaiter(this, void 0, void 0, function* () {
            var configDetails = yield this._appService.getConfiguration();
            var appCommandLine = configDetails.properties.appCommandLine;
            startupCommand = (!!startupCommand) ? startupCommand : appCommandLine;
            var linuxFxVersion = configDetails.properties.linuxFxVersion;
            runtimeStack = (!!runtimeStack) ? runtimeStack : linuxFxVersion;
            if (startupCommand != appCommandLine || runtimeStack != linuxFxVersion) {
                var properties = { linuxFxVersion: runtimeStack, appCommandLine: startupCommand };
                for (var property in properties) {
                    if (!!properties[property] && properties[property].value !== undefined) {
                        properties[property] = properties[property].value;
                    }
                }
                console.log(tl.loc('UpdatingAppServiceConfigurationSettings', JSON.stringify(properties)));
                yield this._appService.patchConfiguration({ 'properties': properties });
                console.log(tl.loc('UpdatedAppServiceConfigurationSettings'));
            }
            else {
                tl.debug(`Skipped updating the values. linuxFxVersion: ${linuxFxVersion} : appCommandLine: ${appCommandLine}`);
            }
        });
    }
    isSitePublishingCredentialsEnabled() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                let scmAuthPolicy = yield this._appService.getSitePublishingCredentialPolicies();
                tl.debug(`Site Publishing Policy check: ${JSON.stringify(scmAuthPolicy)}`);
                if (scmAuthPolicy && scmAuthPolicy.properties.allow) {
                    tl.debug("Web App does allow SCM access");
                    return true;
                }
                else {
                    tl.debug("Web App does not allow SCM Access");
                    return false;
                }
            }
            catch (error) {
                tl.debug(`Call to get SCM Policy check failed: ${error}`);
                return false;
            }
        });
    }
    isFunctionAppOnCentauri() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                let details = yield this._appService.get();
                if (details.properties["managedEnvironmentId"]) {
                    tl.debug("Function Container app is on Centauri.");
                    return true;
                }
                else {
                    return false;
                }
            }
            catch (error) {
                tl.debug(`Skipping Centauri check: ${error}`);
                return false;
            }
        });
    }
    updateSiteContainer(siteContainer) {
        return __awaiter(this, void 0, void 0, function* () {
            const properties = yield this.filterProperties(siteContainer);
            yield this._appService.updateSiteContainer(properties, siteContainer.getName());
        });
    }
    filterProperties(siteContainer) {
        return __awaiter(this, void 0, void 0, function* () {
            const filteredProperties = {};
            const environmentVariablesProperties = [];
            if (siteContainer.getEnvironmentVariables()) {
                siteContainer.getEnvironmentVariables().forEach(env => {
                    environmentVariablesProperties.push(SiteContainer_1.EnvironmentVariable.toJson(env));
                });
            }
            const volumeMountsProperties = [];
            if (siteContainer.getVolumeMounts()) {
                siteContainer.getVolumeMounts().forEach((mount) => {
                    volumeMountsProperties.push(SiteContainer_1.VolumeMount.toJson(mount));
                });
            }
            const allProperties = {
                image: siteContainer.getImage(),
                targetPort: siteContainer.getTargetPort(),
                isMain: siteContainer.getIsMain(),
                startupCommand: siteContainer.getStartupCommand(),
                authType: siteContainer.getAuthType(),
                userName: siteContainer.getUserName(),
                passwordSecret: siteContainer.getPasswordSecret(),
                userManagedIdentityClientId: siteContainer.getUserManagedIdentityClientId(),
                inheritAppSettingsAndConnectionStrings: siteContainer.getInheritAppSettingsAndConnectionStrings()
            };
            for (const key in allProperties) {
                const value = allProperties[key];
                if (value !== null && value !== undefined && value !== '') {
                    filteredProperties[key] = value;
                }
            }
            if (volumeMountsProperties.length > 0) {
                filteredProperties["volumeMounts"] = volumeMountsProperties;
            }
            if (environmentVariablesProperties.length > 0) {
                filteredProperties["environmentVariables"] = environmentVariablesProperties;
            }
            return filteredProperties;
        });
    }
    // Method to get app service instances
    getAppserviceInstances() {
        return __awaiter(this, void 0, void 0, function* () {
            return yield this._appService._getAppServiceInstances();
        });
    }
}
exports.AzureAppServiceUtility = AzureAppServiceUtility;
