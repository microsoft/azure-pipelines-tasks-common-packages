"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AzureRmEndpointAuthenticationScheme = exports.AzureServicePrinicipalAuthentications = exports.KUDU_DEPLOYMENT_CONSTANTS = exports.APIVersions = exports.WebsiteEnableSyncUpdateSiteKey = exports.AzureDeployPackageArtifactAlias = exports.mysqlApiVersion = exports.productionSlot = exports.APPLICATION_INSIGHTS_EXTENSION_NAME = exports.AzureEnvironments = void 0;
exports.AzureEnvironments = {
    AzureStack: 'azurestack'
};
exports.APPLICATION_INSIGHTS_EXTENSION_NAME = "Microsoft.ApplicationInsights.AzureWebSites";
exports.productionSlot = "production";
exports.mysqlApiVersion = '2017-12-01';
exports.AzureDeployPackageArtifactAlias = "Azure_App_Service_Deploy_PackageArtifactAlias";
exports.WebsiteEnableSyncUpdateSiteKey = "WEBSITE_ENABLE_SYNC_UPDATE_SITE";
exports.APIVersions = {
    azure_arm_appinsights: '2015-05-01',
    azure_arm_metric_alerts: '2016-03-01'
};
exports.KUDU_DEPLOYMENT_CONSTANTS = {
    SUCCESS: 4,
    FAILED: 3
};
exports.AzureServicePrinicipalAuthentications = {
    "servicePrincipalKey": "spnKey",
    "servicePrincipalCertificate": "spnCertificate"
};
exports.AzureRmEndpointAuthenticationScheme = {
    "ServicePrincipal": "serviceprincipal",
    "ManagedServiceIdentity": "managedserviceidentity",
    "PublishProfile": "publishprofile",
    "WorkloadIdentityFederation": "workloadidentityfederation"
};
