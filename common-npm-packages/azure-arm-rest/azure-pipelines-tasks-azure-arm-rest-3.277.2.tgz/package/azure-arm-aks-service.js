"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AzureAksService = void 0;
const path = require("path");
const tl = require("azure-pipelines-task-lib/task");
const AzureServiceClient_1 = require("./AzureServiceClient");
const AzureServiceClientBase_1 = require("./AzureServiceClientBase");
const webClient = require("./webClient");
tl.setResourcePath(path.join(__dirname, 'module.json'), true);
class AzureAksService {
    constructor(endpoint) {
        this._client = new AzureServiceClient_1.ServiceClient(endpoint.applicationTokenCredentials, endpoint.subscriptionID, 30);
    }
    beginRequest(uri, parameters, apiVersion, method) {
        var webRequest = new webClient.WebRequest();
        webRequest.method = method || 'GET';
        webRequest.uri = this._client.getRequestUri(uri, parameters, null, apiVersion);
        return this._client.beginRequestExpBackoff(webRequest, 3).then((response) => {
            if (response.statusCode >= 200 && response.statusCode < 300) {
                return response;
            }
            else {
                throw (0, AzureServiceClientBase_1.ToError)(response);
            }
        });
    }
    getAccessProfile(resourceGroup, clusterName, useClusterAdmin) {
        var accessProfileName = !!useClusterAdmin ? 'clusterAdmin' : 'clusterUser';
        return this.beginRequest(`//subscriptions/{subscriptionId}/resourceGroups/{ResourceGroupName}/providers/Microsoft.ContainerService/managedClusters/{ClusterName}/accessProfiles/{AccessProfileName}`, {
            '{ResourceGroupName}': resourceGroup,
            '{ClusterName}': clusterName,
            '{AccessProfileName}': accessProfileName
        }, '2017-08-31', "GET").then((response) => {
            return response.body;
        }, (reason) => {
            throw Error(tl.loc('CantDownloadAccessProfile', clusterName, this._client.getFormattedError(reason)));
        });
    }
    createFleetParameters(resourceGroup, name) {
        const uri = `//subscriptions/{subscriptionId}/resourceGroups/{ResourceGroupName}/providers/Microsoft.ContainerService/fleets/{FleetName}/listCredentials`;
        const parameters = {
            '{ResourceGroupName}': resourceGroup,
            '{FleetName}': name,
        };
        const apiVersion = '2024-04-01';
        return { uri, parameters, apiVersion };
    }
    createManagedClusterParameters(resourceGroup, name, useClusterAdmin) {
        const credentialAction = !!useClusterAdmin ? 'listClusterAdminCredential' : 'listClusterUserCredential';
        const uri = `//subscriptions/{subscriptionId}/resourceGroups/{ResourceGroupName}/providers/Microsoft.ContainerService/managedClusters/{ClusterName}/{CredentialAction}`;
        const parameters = {
            '{ResourceGroupName}': resourceGroup,
            '{ClusterName}': name,
            '{CredentialAction}': credentialAction,
        };
        const apiVersion = '2024-05-01';
        return { uri, parameters, apiVersion };
    }
    getCredentials(resourceGroup, name, uri, parameters, apiVersion) {
        return this.beginRequest(uri, parameters, apiVersion, "POST").then((response) => {
            return response.body;
        }, (reason) => {
            throw Error(tl.loc('CantDownloadClusterCredentials', name, this._client.getFormattedError(reason)));
        });
    }
    getClusterCredential(resourceGroup, name, useClusterAdmin, credentialName) {
        const { uri, parameters, apiVersion } = this.createManagedClusterParameters(resourceGroup, name, useClusterAdmin);
        const credentialsPromise = this.getCredentials(resourceGroup, name, uri, parameters, apiVersion);
        return credentialsPromise.then((credentials) => {
            const credential = credentials.kubeconfigs.find(cred => cred.name === (credentialName || (!!useClusterAdmin ? 'clusterAdmin' : 'clusterUser')));
            if (credential === undefined) {
                throw Error(tl.loc('CantDownloadClusterCredentials', name, `${credentialName || 'default'} not found in the list of credentials.`));
            }
            return credential;
        });
    }
    getFleetCredential(resourceGroup, name) {
        const { uri, parameters, apiVersion } = this.createFleetParameters(resourceGroup, name);
        const credentialsPromise = this.getCredentials(resourceGroup, name, uri, parameters, apiVersion);
        return credentialsPromise.then((credentials) => {
            const credential = credentials.kubeconfigs[0];
            if (credential === undefined) {
                throw Error(tl.loc('CantDownloadClusterCredentials'));
            }
            return credential;
        });
    }
}
exports.AzureAksService = AzureAksService;
