import { AzureEndpoint } from './azureModels';
export declare class AzureRMEndpoint {
    endpoint: AzureEndpoint;
    private _connectedServiceName;
    private _environments;
    private _azureScopes;
    constructor(connectedServiceName: string);
    getEndpoint(useGraphActiveDirectoryResource?: boolean, useMSAL?: boolean): Promise<AzureEndpoint>;
    private _updateAzureStackData;
    private getScopesByEnvironment;
}
export declare function dispose(): void;
