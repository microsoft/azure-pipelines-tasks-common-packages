"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ServiceClient = void 0;
const path = require("path");
const tl = require("azure-pipelines-task-lib/task");
const AzureServiceClientBase_1 = require("./AzureServiceClientBase");
tl.setResourcePath(path.join(__dirname, 'module.json'), true);
class ServiceClient extends AzureServiceClientBase_1.AzureServiceClientBase {
    constructor(credentials, subscriptionId, timeout) {
        super(credentials, timeout);
        this.validateInputs(subscriptionId);
        this.subscriptionId = subscriptionId;
    }
    getRequestUri(uriFormat, parameters, queryParameters, apiVersion) {
        parameters['{subscriptionId}'] = encodeURIComponent(this.subscriptionId);
        return super.getRequestUriForBaseUri(this.baseUri, uriFormat, parameters, queryParameters, apiVersion);
    }
    isValidResourceGroupName(resourceGroupName) {
        if (!resourceGroupName === null || resourceGroupName === undefined || typeof resourceGroupName.valueOf() !== 'string') {
            throw new Error(tl.loc("ResourceGroupCannotBeNull"));
        }
        if (resourceGroupName !== null && resourceGroupName !== undefined) {
            if (resourceGroupName.length > 90) {
                throw new Error(tl.loc("ResourceGroupExceededLength"));
            }
            if (resourceGroupName.length < 1) {
                throw new Error(tl.loc("ResourceGroupDeceededLength"));
            }
            if (resourceGroupName.match(/^[-\w\._\(\)]+$/) === null) {
                throw new Error(tl.loc("ResourceGroupDoesntMatchPattern"));
            }
        }
    }
    validateInputs(subscriptionId) {
        if (!subscriptionId) {
            throw new Error(tl.loc("SubscriptionIdCannotBeNull"));
        }
    }
}
exports.ServiceClient = ServiceClient;
