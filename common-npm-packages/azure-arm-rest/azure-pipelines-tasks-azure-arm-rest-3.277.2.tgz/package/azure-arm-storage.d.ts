import msRestAzure = require('./azure-arm-common');
import azureServiceClient = require('./AzureServiceClient');
import Model = require('./azureModels');
export declare class StorageManagementClient extends azureServiceClient.ServiceClient {
    storageAccounts: StorageAccounts;
    constructor(credentials: msRestAzure.ApplicationTokenCredentials, subscriptionId: string, baseUri?: any, options?: any);
}
export declare class StorageAccounts {
    private client;
    constructor(client: any);
    list(options: any): Promise<Model.StorageAccount[]>;
    listClassicAndRMAccounts(options: any): Promise<Model.StorageAccount[]>;
    getClassicOrArmAccountByName(accountName: string, options: any): Promise<Model.StorageAccount | undefined>;
    listKeys(resourceGroupName: string, accountName: string, options: any, storageAccountType?: string): Promise<string[]>;
    get(storageAccountName: string): Promise<Model.StorageAccount>;
    getStorageAccountProperties(resourceGroupName: string, storageAccountName: string): Promise<Model.StorageAccount | undefined>;
    static getResourceGroupNameFromUri(resourceUri: string): string;
    /**
     * The method is wrapping the request call for the azure storage service.
     * SubscrubtionID is placed automatically in this.client.getRequestUri method based on this.client.subscriptionId
     * The same with apiVersion
     */
    private sendRequest;
    private getStorageAccountsByUri;
    private static isNonEmptyInternal;
}
