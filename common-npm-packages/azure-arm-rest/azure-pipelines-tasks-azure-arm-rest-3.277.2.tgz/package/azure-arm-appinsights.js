"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ApplicationInsightsResources = exports.AzureApplicationInsights = void 0;
const path = require("path");
const tl = require("azure-pipelines-task-lib/task");
const AzureServiceClient_1 = require("./AzureServiceClient");
const AzureServiceClientBase_1 = require("./AzureServiceClientBase");
const constants_1 = require("./constants");
const webClient = require("./webClient");
tl.setResourcePath(path.join(__dirname, 'module.json'), true);
class AzureApplicationInsights {
    constructor(endpoint, resourceGroupName, name) {
        this._client = new AzureServiceClient_1.ServiceClient(endpoint.applicationTokenCredentials, endpoint.subscriptionID, 30);
        this._endpoint = endpoint;
        this._resourceGroupName = resourceGroupName;
        this._name = name;
    }
    get() {
        return __awaiter(this, void 0, void 0, function* () {
            var httpRequest = new webClient.WebRequest();
            httpRequest.method = 'GET';
            httpRequest.uri = this._client.getRequestUri(`//subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/microsoft.insights/components/{resourceName}`, {
                '{resourceGroupName}': this._resourceGroupName,
                '{resourceName}': this._name,
            }, null, '2015-05-01');
            try {
                var response = yield this._client.beginRequest(httpRequest);
                if (response.statusCode == 200) {
                    return response.body;
                }
                throw (0, AzureServiceClientBase_1.ToError)(response);
            }
            catch (error) {
                throw Error(tl.loc('FailedToGetApplicationInsightsResource', this._name, this._client.getFormattedError(error)));
            }
        });
    }
    update(insightProperties) {
        return __awaiter(this, void 0, void 0, function* () {
            var httpRequest = new webClient.WebRequest();
            httpRequest.method = 'PUT';
            httpRequest.body = JSON.stringify(insightProperties);
            httpRequest.uri = this._client.getRequestUri(`//subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/microsoft.insights/components/{resourceName}`, {
                '{resourceGroupName}': this._resourceGroupName,
                '{resourceName}': this._name,
            }, null, constants_1.APIVersions.azure_arm_appinsights);
            try {
                var response = yield this._client.beginRequest(httpRequest);
                if (response.statusCode == 200 || response.statusCode == 201) {
                    return response.body;
                }
                throw (0, AzureServiceClientBase_1.ToError)(response);
            }
            catch (error) {
                throw Error(tl.loc('FailedToUpdateApplicationInsightsResource', this._name, this._client.getFormattedError(error)));
            }
        });
    }
    addReleaseAnnotation(annotation) {
        return __awaiter(this, void 0, void 0, function* () {
            var httpRequest = new webClient.WebRequest();
            httpRequest.method = 'PUT';
            httpRequest.body = JSON.stringify(annotation);
            httpRequest.uri = this._client.getRequestUri(`//subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/microsoft.insights/components/{resourceName}/Annotations`, {
                '{resourceGroupName}': this._resourceGroupName,
                '{resourceName}': this._name,
            }, null, constants_1.APIVersions.azure_arm_appinsights);
            try {
                var response = yield this._client.beginRequest(httpRequest);
                tl.debug(`addReleaseAnnotation. Data : ${JSON.stringify(response)}`);
                if (response.statusCode == 200 || response.statusCode == 201) {
                    return;
                }
                throw (0, AzureServiceClientBase_1.ToError)(response);
            }
            catch (error) {
                throw Error(tl.loc('FailedToUpdateApplicationInsightsResource', this._name, this._client.getFormattedError(error)));
            }
        });
    }
    getResourceGroupName() {
        return this._resourceGroupName;
    }
}
exports.AzureApplicationInsights = AzureApplicationInsights;
class ApplicationInsightsResources {
    constructor(endpoint) {
        this._client = new AzureServiceClient_1.ServiceClient(endpoint.applicationTokenCredentials, endpoint.subscriptionID, 30);
        this._endpoint = endpoint;
    }
    list(resourceGroupName, filter) {
        return __awaiter(this, void 0, void 0, function* () {
            var httpRequest = new webClient.WebRequest();
            httpRequest.method = 'GET';
            resourceGroupName = resourceGroupName ? `resourceGroups/${resourceGroupName}` : '';
            httpRequest.uri = this._client.getRequestUri(`//subscriptions/{subscriptionId}/${resourceGroupName}/providers/microsoft.insights/components`, {}, filter, constants_1.APIVersions.azure_arm_appinsights);
            try {
                var response = yield this._client.beginRequest(httpRequest);
                if (response.statusCode == 200) {
                    var responseBody = response.body;
                    var applicationInsightsResources = [];
                    if (responseBody.value && responseBody.value.length > 0) {
                        for (var value of responseBody.value) {
                            applicationInsightsResources.push(value);
                        }
                    }
                    return applicationInsightsResources;
                }
                throw (0, AzureServiceClientBase_1.ToError)(response);
            }
            catch (error) {
                throw Error(tl.loc('FailedToGetApplicationInsightsResource', this._client.getFormattedError(error)));
            }
        });
    }
}
exports.ApplicationInsightsResources = ApplicationInsightsResources;
