"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AzureAppService = exports.ServiceClient_1 = void 0;
const tl = require("azure-pipelines-task-lib/task");
const webClient = require("./webClient");
const path = require("path");
const AzureServiceClient_1 = require("./AzureServiceClient");
const AzureServiceClientBase_1 = require("./AzureServiceClientBase");
const constants = require("./constants");
const CorrelationIdInResponse = "x-ms-correlation-request-id";
tl.setResourcePath(path.join(__dirname, 'module.json'), true);
class ServiceClient_1 extends AzureServiceClient_1.ServiceClient {
    beginRequest(request, reqOptions) {
        return __awaiter(this, void 0, void 0, function* () {
            var token = yield this.getCredentials().getToken();
            request.headers = request.headers || {};
            request.headers["Authorization"] = "Bearer " + token;
            if (this.acceptLanguage) {
                request.headers['accept-language'] = this.acceptLanguage;
            }
            if (!request.headers['Content-Type']) {
                request.headers['Content-Type'] = 'application/json; charset=utf-8';
            }
            var httpResponse = null;
            try {
                httpResponse = yield webClient.sendRequest(request, reqOptions);
                if (httpResponse.statusCode === 401 && httpResponse.body && httpResponse.body.error && httpResponse.body.error.code === "ExpiredAuthenticationToken") {
                    // The access token might have expire. Re-issue the request after refreshing the token.
                    token = yield this.getCredentials().getToken(true);
                    request.headers["Authorization"] = "Bearer " + token;
                    httpResponse = yield webClient.sendRequest(request, reqOptions);
                }
                if (!!httpResponse.headers[CorrelationIdInResponse]) {
                    tl.debug(`Correlation ID from ARM api call response : ${httpResponse.headers[CorrelationIdInResponse]}`);
                }
            }
            catch (exception) {
                let exceptionString = exception.toString();
                if (exceptionString.indexOf("Hostname/IP doesn't match certificates's altnames") != -1
                    || exceptionString.indexOf("unable to verify the first certificate") != -1
                    || exceptionString.indexOf("unable to get local issuer certificate") != -1) {
                    tl.warning(tl.loc('ASE_SSLIssueRecommendation'));
                }
                throw exception;
            }
            return httpResponse;
        });
    }
}
exports.ServiceClient_1 = ServiceClient_1;
class AzureAppService {
    constructor(endpoint, resourceGroup, name, slot, appKind, isConsumptionApp) {
        this._client = new ServiceClient_1(endpoint.applicationTokenCredentials, endpoint.subscriptionID, 30);
        this._resourceGroup = resourceGroup;
        this._name = name;
        this._slot = (slot && slot.toLowerCase() == constants.productionSlot) ? null : slot;
        this._appKind = appKind;
        this._isConsumptionApp = isConsumptionApp;
    }
    start() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                var webRequest = new webClient.WebRequest();
                webRequest.method = 'POST';
                var slotUrl = !!this._slot ? `/slots/${this._slot}` : '';
                webRequest.uri = this._client.getRequestUri(`//subscriptions/{subscriptionId}/resourceGroups/{ResourceGroupName}/providers/Microsoft.Web/sites/{name}/${slotUrl}/start`, {
                    '{ResourceGroupName}': this._resourceGroup,
                    '{name}': this._name
                }, null, '2016-08-01');
                console.log(tl.loc('StartingAppService', this._getFormattedName()));
                var response = yield this._client.beginRequest(webRequest);
                if (response.statusCode != 200) {
                    throw (0, AzureServiceClientBase_1.ToError)(response);
                }
                console.log(tl.loc('StartedAppService', this._getFormattedName()));
            }
            catch (error) {
                throw Error(tl.loc('FailedToStartAppService', this._getFormattedName(), this._client.getFormattedError(error)));
            }
        });
    }
    stop() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                var webRequest = new webClient.WebRequest();
                webRequest.method = 'POST';
                var slotUrl = !!this._slot ? `/slots/${this._slot}` : '';
                webRequest.uri = this._client.getRequestUri(`//subscriptions/{subscriptionId}/resourceGroups/{ResourceGroupName}/providers/Microsoft.Web/sites/{name}/${slotUrl}/stop`, {
                    '{ResourceGroupName}': this._resourceGroup,
                    '{name}': this._name
                }, null, '2016-08-01');
                console.log(tl.loc('StoppingAppService', this._getFormattedName()));
                var response = yield this._client.beginRequest(webRequest);
                if (response.statusCode != 200) {
                    throw (0, AzureServiceClientBase_1.ToError)(response);
                }
                console.log(tl.loc('StoppedAppService', this._getFormattedName()));
            }
            catch (error) {
                throw Error(tl.loc('FailedToStopAppService', this._getFormattedName(), this._client.getFormattedError(error)));
            }
        });
    }
    restart() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                var webRequest = new webClient.WebRequest();
                webRequest.method = 'POST';
                var slotUrl = !!this._slot ? `/slots/${this._slot}` : '';
                webRequest.uri = this._client.getRequestUri(`//subscriptions/{subscriptionId}/resourceGroups/{ResourceGroupName}/providers/Microsoft.Web/sites/{name}/${slotUrl}/restart`, {
                    '{ResourceGroupName}': this._resourceGroup,
                    '{name}': this._name
                }, null, '2016-08-01');
                console.log(tl.loc('RestartingAppService', this._getFormattedName()));
                var response = yield this._client.beginRequest(webRequest);
                if (response.statusCode != 200) {
                    throw (0, AzureServiceClientBase_1.ToError)(response);
                }
                console.log(tl.loc('RestartedAppService', this._getFormattedName()));
            }
            catch (error) {
                throw Error(tl.loc('FailedToRestartAppService', this._getFormattedName(), this._client.getFormattedError(error)));
            }
        });
    }
    delete() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                var webRequest = new webClient.WebRequest();
                webRequest.method = 'DELETE';
                var slotUrl = !!this._slot ? `/slots/${this._slot}` : '';
                webRequest.uri = this._client.getRequestUri(`//subscriptions/{subscriptionId}/resourceGroups/{ResourceGroupName}/providers/Microsoft.Web/sites/{name}/${slotUrl}`, {
                    '{ResourceGroupName}': this._resourceGroup,
                    '{name}': this._name
                }, null, '2016-08-01');
                console.log(tl.loc('DeletingAppServiceSlot', this._getFormattedName()));
                var response = yield this._client.beginRequest(webRequest);
                if (response.statusCode != 200) {
                    throw (0, AzureServiceClientBase_1.ToError)(response);
                }
                console.log(tl.loc('DeletedAppServiceSlot', this._getFormattedName()));
            }
            catch (error) {
                throw Error(tl.loc('FailedToDeleteAppServiceSlot', this._getFormattedName(), this._client.getFormattedError(error)));
            }
        });
    }
    swap(slotName, preserveVNet) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                var webRequest = new webClient.WebRequest();
                webRequest.method = 'POST';
                webRequest.body = JSON.stringify({
                    targetSlot: slotName,
                    preserveVnet: preserveVNet
                });
                var slotUrl = !!this._slot ? `/slots/${this._slot}` : '';
                webRequest.uri = this._client.getRequestUri(`//subscriptions/{subscriptionId}/resourceGroups/{ResourceGroupName}/providers/Microsoft.Web/sites/{name}/${slotUrl}/slotsswap`, {
                    '{ResourceGroupName}': this._resourceGroup,
                    '{name}': this._name,
                    '{slotUrl}': slotUrl
                }, null, '2016-08-01');
                console.log(tl.loc('SwappingAppServiceSlotSlots', this._name, this.getSlot(), slotName));
                var response = yield this._client.beginRequest(webRequest);
                if (response.statusCode == 202) {
                    response = yield this._client.getLongRunningOperationResult(response);
                }
                if (response.statusCode != 200) {
                    throw (0, AzureServiceClientBase_1.ToError)(response);
                }
                console.log(tl.loc('SwappedAppServiceSlotSlots', this._name, this.getSlot(), slotName));
            }
            catch (error) {
                throw Error(tl.loc('FailedToSwapAppServiceSlotSlots', this._name, this.getSlot(), slotName, this._client.getFormattedError(error)));
            }
        });
    }
    swapSlotWithPreview(slotName, preserveVNet) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                var webRequest = new webClient.WebRequest();
                webRequest.method = 'POST';
                webRequest.body = JSON.stringify({
                    targetSlot: slotName,
                    preserveVnet: preserveVNet
                });
                var slotUrl = !!this._slot ? `/slots/${this._slot}` : '';
                webRequest.uri = this._client.getRequestUri(`//subscriptions/{subscriptionId}/resourceGroups/{ResourceGroupName}/providers/Microsoft.Web/sites/{name}/${slotUrl}/applySlotConfig`, {
                    '{ResourceGroupName}': this._resourceGroup,
                    '{name}': this._name,
                    '{slotUrl}': slotUrl
                }, null, '2016-08-01');
                console.log(tl.loc('SwappingAppServiceSlotSlotsPhase1', this._name, this.getSlot(), slotName));
                var response = yield this._client.beginRequest(webRequest);
                if (response.statusCode != 200) {
                    throw (0, AzureServiceClientBase_1.ToError)(response);
                }
                console.log(tl.loc('SwappedAppServiceSlotSlotsPhase1', this._name, this.getSlot(), slotName));
                console.log(tl.loc('PreviewSwapPhase1', this._name, this.getSlot()));
            }
            catch (error) {
                throw Error(tl.loc('FailedToSwapAppServiceSlotSlotsPhase1', this._name, this.getSlot(), slotName, this._client.getFormattedError(error)));
            }
        });
    }
    cancelSwapSlotWithPreview() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                var webRequest = new webClient.WebRequest();
                webRequest.method = 'POST';
                var slotUrl = !!this._slot ? `/slots/${this._slot}` : '';
                webRequest.uri = this._client.getRequestUri(`//subscriptions/{subscriptionId}/resourceGroups/{ResourceGroupName}/providers/Microsoft.Web/sites/{name}/${slotUrl}/resetSlotConfig`, {
                    '{ResourceGroupName}': this._resourceGroup,
                    '{name}': this._name,
                    '{slotUrl}': slotUrl
                }, null, '2016-08-01');
                console.log(tl.loc('CancelSwapAppServiceSlotSlotsPhase1', this._name, this.getSlot()));
                var response = yield this._client.beginRequest(webRequest);
                if (response.statusCode != 200) {
                    throw (0, AzureServiceClientBase_1.ToError)(response);
                }
                console.log(tl.loc('CancelledSwapAppServiceSlotSlotsPhase1', this._name, this.getSlot()));
            }
            catch (error) {
                throw Error(tl.loc('FailedToCancelSwapAppServiceSlotSlotsPhase1', this._name, this.getSlot(), this._client.getFormattedError(error)));
            }
        });
    }
    get(force) {
        return __awaiter(this, void 0, void 0, function* () {
            if (force || !this._appServiceConfigurationDetails) {
                this._appServiceConfigurationDetails = yield this._get();
            }
            return this._appServiceConfigurationDetails;
        });
    }
    getPublishingProfileWithSecrets(force) {
        return __awaiter(this, void 0, void 0, function* () {
            if (force || !this._appServicePublishingProfile) {
                this._appServicePublishingProfile = yield this._getPublishingProfileWithSecrets();
            }
            return this._appServicePublishingProfile;
        });
    }
    getPublishingCredentials() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                var httpRequest = new webClient.WebRequest();
                httpRequest.method = 'POST';
                var slotUrl = !!this._slot ? `/slots/${this._slot}` : '';
                httpRequest.uri = this._client.getRequestUri(`//subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.Web/sites/{name}/${slotUrl}/config/publishingcredentials/list`, {
                    '{resourceGroupName}': this._resourceGroup,
                    '{name}': this._name,
                }, null, '2016-08-01');
                var response = yield this._client.beginRequest(httpRequest);
                if (response.statusCode != 200) {
                    throw (0, AzureServiceClientBase_1.ToError)(response);
                }
                return response.body;
            }
            catch (error) {
                throw Error(tl.loc('FailedToGetAppServicePublishingCredentials', this._getFormattedName(), this._client.getFormattedError(error)));
            }
        });
    }
    getApplicationSettings(force) {
        return __awaiter(this, void 0, void 0, function* () {
            if (force || !this._appServiceApplicationSetings) {
                this._appServiceApplicationSetings = yield this._getApplicationSettings();
            }
            return this._appServiceApplicationSetings;
        });
    }
    updateApplicationSettings(applicationSettings) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                var httpRequest = new webClient.WebRequest();
                httpRequest.method = 'PUT';
                httpRequest.body = JSON.stringify(applicationSettings);
                var slotUrl = !!this._slot ? `/slots/${this._slot}` : '';
                httpRequest.uri = this._client.getRequestUri(`//subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.Web/sites/{name}/${slotUrl}/config/appsettings`, {
                    '{resourceGroupName}': this._resourceGroup,
                    '{name}': this._name,
                }, null, '2016-08-01');
                var response = yield this._client.beginRequest(httpRequest);
                if (response.statusCode != 200) {
                    throw (0, AzureServiceClientBase_1.ToError)(response);
                }
                return response.body;
            }
            catch (error) {
                throw Error(tl.loc('FailedToUpdateAppServiceApplicationSettings', this._getFormattedName(), this._client.getFormattedError(error)));
            }
        });
    }
    patchApplicationSettings(addProperties, deleteProperties, formatJSON) {
        return __awaiter(this, void 0, void 0, function* () {
            var applicationSettings = yield this.getApplicationSettings();
            var isNewValueUpdated = false;
            for (var key in addProperties) {
                if (formatJSON) {
                    if (JSON.stringify(applicationSettings.properties[key]) != JSON.stringify(addProperties[key])) {
                        tl.debug(`Value of ${key} has been changed to ${JSON.stringify(addProperties[key])}`);
                        isNewValueUpdated = true;
                    }
                    else {
                        tl.debug(`${key} is already present.`);
                    }
                }
                else {
                    if (applicationSettings.properties[key] != addProperties[key]) {
                        tl.debug(`Value of ${key} has been changed to ${addProperties[key]}`);
                        isNewValueUpdated = true;
                    }
                    else {
                        tl.debug(`${key} is already present.`);
                    }
                }
                applicationSettings.properties[key] = addProperties[key];
            }
            for (var key in deleteProperties) {
                if (key in applicationSettings.properties) {
                    delete applicationSettings.properties[key];
                    tl.debug(`Removing app setting : ${key}`);
                    isNewValueUpdated = true;
                }
            }
            if (isNewValueUpdated) {
                applicationSettings.properties[constants.WebsiteEnableSyncUpdateSiteKey] = this._isConsumptionApp ? 'false' : 'true';
                yield this.updateApplicationSettings(applicationSettings);
            }
            return isNewValueUpdated;
        });
    }
    patchApplicationSettingsSlot(addProperties) {
        return __awaiter(this, void 0, void 0, function* () {
            var appSettingsSlotSettings = yield this.getSlotConfigurationNames();
            let appSettingNames = appSettingsSlotSettings.properties.appSettingNames;
            var isNewValueUpdated = false;
            for (var key in addProperties) {
                if (!appSettingNames) {
                    appSettingsSlotSettings.properties.appSettingNames = [];
                    appSettingNames = appSettingsSlotSettings.properties.appSettingNames;
                }
                if (addProperties[key].slotSetting == true) {
                    if ((appSettingNames.length == 0) || (!appSettingNames.includes(addProperties[key].name))) {
                        appSettingNames.push(addProperties[key].name);
                    }
                    tl.debug(`Slot setting updated for key : ${addProperties[key].name}`);
                    isNewValueUpdated = true;
                }
            }
            if (isNewValueUpdated) {
                yield this._updateSlotConfigSettings(appSettingsSlotSettings);
            }
        });
    }
    getSlotConfigurationNames(force) {
        return __awaiter(this, void 0, void 0, function* () {
            if (force || !this._appServiceConfigurationSettings) {
                this._appServiceConfigurationSettings = yield this._getSlotConfigurationNames();
            }
            return this._appServiceConfigurationSettings;
        });
    }
    _getSlotConfigurationNames() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                var httpRequest = new webClient.WebRequest();
                httpRequest.method = 'GET';
                httpRequest.uri = this._client.getRequestUri(`//subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.Web/sites/{name}/config/slotConfigNames`, {
                    '{resourceGroupName}': this._resourceGroup,
                    '{name}': this._name,
                }, null, '2016-08-01');
                var response = yield this._client.beginRequest(httpRequest);
                if (response.statusCode != 200) {
                    throw (0, AzureServiceClientBase_1.ToError)(response);
                }
                return response.body;
            }
            catch (error) {
                throw Error(tl.loc('FailedToGetAppServiceSlotConfigurationNames', this._getFormattedName(), this._client.getFormattedError(error)));
            }
        });
    }
    _getConnectionStrings(force) {
        return __awaiter(this, void 0, void 0, function* () {
            if (force || !this._appServiceConnectionString) {
                try {
                    var httpRequest = new webClient.WebRequest();
                    httpRequest.method = 'POST';
                    var slotUrl = !!this._slot ? `/slots/${this._slot}` : '';
                    httpRequest.uri = this._client.getRequestUri(`//subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.Web/sites/{name}/${slotUrl}/config/connectionstrings/list`, {
                        '{resourceGroupName}': this._resourceGroup,
                        '{name}': this._name,
                    }, null, '2016-08-01');
                    var response = yield this._client.beginRequest(httpRequest);
                    if (response.statusCode != 200) {
                        throw (0, AzureServiceClientBase_1.ToError)(response);
                    }
                    this._appServiceConnectionString = response.body;
                }
                catch (error) {
                    throw Error(tl.loc('FailedToGetAppServiceConnectionStrings', this._getFormattedName(), this._client.getFormattedError(error)));
                }
            }
            return this._appServiceConnectionString;
        });
    }
    patchConnectionString(addProperties) {
        return __awaiter(this, void 0, void 0, function* () {
            var connectionStringSettings = yield this._getConnectionStrings();
            var isNewValueUpdated = false;
            for (var key in addProperties) {
                if (JSON.stringify(connectionStringSettings.properties[key]) != JSON.stringify(addProperties[key])) {
                    tl.debug(`Value of ${key} has been changed to ${JSON.stringify(addProperties[key])}`);
                    isNewValueUpdated = true;
                }
                else {
                    tl.debug(`${key} is already present.`);
                }
                connectionStringSettings.properties[key] = addProperties[key];
            }
            if (isNewValueUpdated) {
                yield this._updateConnectionStrings(connectionStringSettings);
            }
        });
    }
    _updateConnectionStrings(connectionStringSettings) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                var httpRequest = new webClient.WebRequest();
                httpRequest.method = 'PUT';
                httpRequest.body = JSON.stringify(connectionStringSettings);
                var slotUrl = !!this._slot ? `/slots/${this._slot}` : '';
                httpRequest.uri = this._client.getRequestUri(`//subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.Web/sites/{name}/${slotUrl}/config/connectionstrings`, {
                    '{resourceGroupName}': this._resourceGroup,
                    '{name}': this._name,
                }, null, '2016-08-01');
                var response = yield this._client.beginRequest(httpRequest);
                if (response.statusCode != 200) {
                    throw (0, AzureServiceClientBase_1.ToError)(response);
                }
                return response.body;
            }
            catch (error) {
                throw Error(tl.loc('FailedToUpdateAppServiceConnectionStrings', this._getFormattedName(), this._client.getFormattedError(error)));
            }
        });
    }
    patchConnectionStringSlot(addProperties) {
        return __awaiter(this, void 0, void 0, function* () {
            var connectionStringSlotSettings = yield this.getSlotConfigurationNames();
            let connectionStringNames = connectionStringSlotSettings.properties.connectionStringNames;
            var isNewValueUpdated = false;
            for (var key in addProperties) {
                if (!connectionStringNames) {
                    connectionStringSlotSettings.properties.connectionStringNames = [];
                    connectionStringNames = connectionStringSlotSettings.properties.connectionStringNames;
                }
                if (addProperties[key].slotSetting == true) {
                    if ((connectionStringNames.length == 0) || (!connectionStringNames.includes(key))) {
                        connectionStringNames.push(key);
                    }
                    tl.debug(`Slot setting updated for key : ${key}`);
                    isNewValueUpdated = true;
                }
            }
            if (isNewValueUpdated) {
                yield this._updateSlotConfigSettings(connectionStringSlotSettings);
            }
        });
    }
    _updateSlotConfigSettings(SlotConfigSettings) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                var httpRequest = new webClient.WebRequest();
                httpRequest.method = 'PUT';
                httpRequest.body = JSON.stringify(SlotConfigSettings);
                httpRequest.uri = this._client.getRequestUri(`//subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.Web/sites/{name}/config/slotConfigNames`, {
                    '{resourceGroupName}': this._resourceGroup,
                    '{name}': this._name,
                }, null, '2016-08-01');
                var response = yield this._client.beginRequest(httpRequest);
                if (response.statusCode != 200) {
                    throw (0, AzureServiceClientBase_1.ToError)(response);
                }
                return response.body;
            }
            catch (error) {
                throw Error(tl.loc('FailedToUpdateAppServiceConfigSlotSettings', this._getFormattedName(), this._client.getFormattedError(error)));
            }
        });
    }
    getConfiguration() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                var httpRequest = new webClient.WebRequest();
                httpRequest.method = 'GET';
                var slotUrl = !!this._slot ? `/slots/${this._slot}` : '';
                httpRequest.uri = this._client.getRequestUri(`//subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.Web/sites/{name}/${slotUrl}/config/web`, {
                    '{resourceGroupName}': this._resourceGroup,
                    '{name}': this._name,
                }, null, '2018-02-01');
                var response = yield this._client.beginRequest(httpRequest);
                if (response.statusCode != 200) {
                    throw (0, AzureServiceClientBase_1.ToError)(response);
                }
                return response.body;
            }
            catch (error) {
                throw Error(tl.loc('FailedToGetAppServiceConfiguration', this._getFormattedName(), this._client.getFormattedError(error)));
            }
        });
    }
    updateConfiguration(applicationSettings) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                var httpRequest = new webClient.WebRequest();
                httpRequest.method = 'PUT';
                httpRequest.body = JSON.stringify(applicationSettings);
                var slotUrl = !!this._slot ? `/slots/${this._slot}` : '';
                httpRequest.uri = this._client.getRequestUri(`//subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.Web/sites/{name}/${slotUrl}/config/web`, {
                    '{resourceGroupName}': this._resourceGroup,
                    '{name}': this._name,
                }, null, '2018-02-01');
                var response = yield this._client.beginRequest(httpRequest);
                if (response.statusCode != 200) {
                    throw (0, AzureServiceClientBase_1.ToError)(response);
                }
                return response.body;
            }
            catch (error) {
                throw Error(tl.loc('FailedToUpdateAppServiceConfiguration', this._getFormattedName(), this._client.getFormattedError(error)));
            }
        });
    }
    updateConfigurationSettings(properties, formatJSON) {
        return __awaiter(this, void 0, void 0, function* () {
            if (formatJSON) {
                var configurationSettingsProperties = properties[0];
                console.log(tl.loc('UpdatingAppServiceConfigurationSettings', JSON.stringify(configurationSettingsProperties)));
                yield this.patchConfiguration({ 'properties': configurationSettingsProperties });
            }
            else {
                for (var property in properties) {
                    if (!!properties[property] && properties[property].value !== undefined) {
                        properties[property] = properties[property].value;
                    }
                }
                console.log(tl.loc('UpdatingAppServiceConfigurationSettings', JSON.stringify(properties)));
                yield this.patchConfiguration({ 'properties': properties });
            }
            console.log(tl.loc('UpdatedAppServiceConfigurationSettings'));
        });
    }
    patchConfiguration(properties) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                var httpRequest = new webClient.WebRequest();
                httpRequest.method = 'PATCH';
                httpRequest.body = JSON.stringify(properties);
                var slotUrl = !!this._slot ? `/slots/${this._slot}` : '';
                httpRequest.uri = this._client.getRequestUri(`//subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.Web/sites/{name}/${slotUrl}/config/web`, {
                    '{resourceGroupName}': this._resourceGroup,
                    '{name}': this._name,
                }, null, '2018-02-01');
                var response = yield this._client.beginRequest(httpRequest);
                if (response.statusCode != 200 && response.statusCode != 202) {
                    throw (0, AzureServiceClientBase_1.ToError)(response);
                }
                return response.body;
            }
            catch (error) {
                throw Error(tl.loc('FailedToPatchAppServiceConfiguration', this._getFormattedName(), this._client.getFormattedError(error)));
            }
        });
    }
    getMetadata() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                var httpRequest = new webClient.WebRequest();
                httpRequest.method = 'POST';
                var slotUrl = !!this._slot ? `/slots/${this._slot}` : '';
                httpRequest.uri = this._client.getRequestUri(`//subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.Web/sites/{name}/${slotUrl}/config/metadata/list`, {
                    '{resourceGroupName}': this._resourceGroup,
                    '{name}': this._name,
                }, null, '2016-08-01');
                var response = yield this._client.beginRequest(httpRequest);
                if (response.statusCode != 200) {
                    throw (0, AzureServiceClientBase_1.ToError)(response);
                }
                return response.body;
            }
            catch (error) {
                throw Error(tl.loc('FailedToGetAppServiceMetadata', this._getFormattedName(), this._client.getFormattedError(error)));
            }
        });
    }
    updateMetadata(applicationSettings) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                var httpRequest = new webClient.WebRequest();
                httpRequest.method = 'PUT';
                httpRequest.body = JSON.stringify(applicationSettings);
                var slotUrl = !!this._slot ? `/slots/${this._slot}` : '';
                httpRequest.uri = this._client.getRequestUri(`//subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.Web/sites/{name}/${slotUrl}/config/metadata`, {
                    '{resourceGroupName}': this._resourceGroup,
                    '{name}': this._name,
                }, null, '2016-08-01');
                var response = yield this._client.beginRequest(httpRequest);
                if (response.statusCode != 200) {
                    throw (0, AzureServiceClientBase_1.ToError)(response);
                }
                return response.body;
            }
            catch (error) {
                throw Error(tl.loc('FailedToUpdateAppServiceMetadata', this._getFormattedName(), this._client.getFormattedError(error)));
            }
        });
    }
    patchMetadata(properties) {
        return __awaiter(this, void 0, void 0, function* () {
            var applicationSettings = yield this.getMetadata();
            for (var key in properties) {
                applicationSettings.properties[key] = properties[key];
            }
            yield this.updateMetadata(applicationSettings);
        });
    }
    getSlot() {
        return this._slot ? this._slot : "production";
    }
    getSiteVirtualNetworkConnections() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                var httpRequest = new webClient.WebRequest();
                httpRequest.method = 'GET';
                var slotUrl = !!this._slot ? `/slots/${this._slot}` : '';
                httpRequest.uri = this._client.getRequestUri(`//subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.Web/sites/{name}/${slotUrl}/virtualNetworkConnections`, {
                    '{resourceGroupName}': this._resourceGroup,
                    '{name}': this._name,
                }, null, '2022-03-01');
                let requestOptions = new webClient.WebRequestOptions();
                requestOptions.retryCount = 1;
                var response = yield this._client.beginRequest(httpRequest, requestOptions);
                if (response.statusCode != 200) {
                    throw (0, AzureServiceClientBase_1.ToError)(response);
                }
                return response.body;
            }
            catch (error) {
                throw Error(`Failed to get Virtual Network Connections. Error: ${this._client.getFormattedError(error)}`);
            }
        });
    }
    getSitePrivateEndpointConnections() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                var httpRequest = new webClient.WebRequest();
                httpRequest.method = 'GET';
                var slotUrl = !!this._slot ? `/slots/${this._slot}` : '';
                httpRequest.uri = this._client.getRequestUri(`//subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.Web/sites/{name}/${slotUrl}/privateEndpointConnections`, {
                    '{resourceGroupName}': this._resourceGroup,
                    '{name}': this._name,
                }, null, '2022-03-01');
                let requestOptions = new webClient.WebRequestOptions();
                requestOptions.retryCount = 1;
                var response = yield this._client.beginRequest(httpRequest, requestOptions);
                if (response.statusCode != 200) {
                    throw (0, AzureServiceClientBase_1.ToError)(response);
                }
                return response.body;
            }
            catch (error) {
                throw Error(`Failed to get Private Endpoint Connections. Error: ${this._client.getFormattedError(error)}`);
            }
        });
    }
    getConnectionStringValidation(connectionDetails) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                var httpRequest = new webClient.WebRequest();
                httpRequest.method = 'POST';
                httpRequest.body = JSON.stringify(connectionDetails);
                var slotUrl = !!this._slot ? `/slots/${this._slot}` : '';
                httpRequest.uri = this._client.getRequestUri(`//subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.Web/sites/{name}/${slotUrl}/extensions/DaaS/api/connectionstringvalidation/validate/`, {
                    '{resourceGroupName}': this._resourceGroup,
                    '{name}': this._name,
                }, null, '2022-03-01');
                let requestOptions = new webClient.WebRequestOptions();
                requestOptions.retryCount = 1;
                var response = yield this._client.beginRequest(httpRequest, requestOptions);
                if (response.statusCode != 200) {
                    throw (0, AzureServiceClientBase_1.ToError)(response);
                }
                return response.body;
            }
            catch (error) {
                throw Error(`Failed to get Connection String Validation. Error: ${this._client.getFormattedError(error)}`);
            }
        });
    }
    syncFunctionTriggers() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                let i = 0;
                let retryCount = 5;
                let retryIntervalInSeconds = 2;
                let timeToWait = retryIntervalInSeconds;
                var httpRequest = new webClient.WebRequest();
                httpRequest.method = 'POST';
                var slotUrl = !!this._slot ? `/slots/${this._slot}` : '';
                httpRequest.uri = this._client.getRequestUri(`//subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.Web/sites/{name}/${slotUrl}/syncfunctiontriggers`, {
                    '{resourceGroupName}': this._resourceGroup,
                    '{name}': this._name,
                }, null, '2016-08-01');
                while (true) {
                    var response = yield this._client.beginRequest(httpRequest);
                    if (response.statusCode == 200) {
                        return response.body;
                    }
                    else if (response.statusCode == 400) {
                        if (++i < retryCount) {
                            yield webClient.sleepFor(timeToWait);
                            timeToWait = timeToWait * retryIntervalInSeconds + retryIntervalInSeconds;
                            continue;
                        }
                        else {
                            throw (0, AzureServiceClientBase_1.ToError)(response);
                        }
                    }
                    else {
                        throw (0, AzureServiceClientBase_1.ToError)(response);
                    }
                }
            }
            catch (error) {
                throw Error(tl.loc('FailedToSyncTriggers', this._getFormattedName(), this._client.getFormattedError(error)));
            }
        });
    }
    _getPublishingProfileWithSecrets() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                var httpRequest = new webClient.WebRequest();
                httpRequest.method = 'POST';
                var slotUrl = !!this._slot ? `/slots/${this._slot}` : '';
                httpRequest.uri = this._client.getRequestUri(`//subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.Web/sites/{name}/${slotUrl}/publishxml`, {
                    '{resourceGroupName}': this._resourceGroup,
                    '{name}': this._name,
                }, null, '2016-08-01');
                var response = yield this._client.beginRequest(httpRequest);
                if (response.statusCode != 200) {
                    throw (0, AzureServiceClientBase_1.ToError)(response);
                }
                var publishingProfile = response.body;
                return publishingProfile;
            }
            catch (error) {
                throw Error(tl.loc('FailedToGetAppServicePublishingProfile', this._getFormattedName(), this._client.getFormattedError(error)));
            }
        });
    }
    _getApplicationSettings() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                var httpRequest = new webClient.WebRequest();
                httpRequest.method = 'POST';
                var slotUrl = !!this._slot ? `/slots/${this._slot}` : '';
                httpRequest.uri = this._client.getRequestUri(`//subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.Web/sites/{name}/${slotUrl}/config/appsettings/list`, {
                    '{resourceGroupName}': this._resourceGroup,
                    '{name}': this._name,
                }, null, '2016-08-01');
                var response = yield this._client.beginRequest(httpRequest);
                if (response.statusCode != 200) {
                    throw (0, AzureServiceClientBase_1.ToError)(response);
                }
                return response.body;
            }
            catch (error) {
                throw Error(tl.loc('FailedToGetAppServiceApplicationSettings', this._getFormattedName(), this._client.getFormattedError(error)));
            }
        });
    }
    _get() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                var httpRequest = new webClient.WebRequest();
                httpRequest.method = 'GET';
                var slotUrl = !!this._slot ? `/slots/${this._slot}` : '';
                httpRequest.uri = this._client.getRequestUri(`//subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.Web/sites/{name}/${slotUrl}`, {
                    '{resourceGroupName}': this._resourceGroup,
                    '{name}': this._name,
                }, null, '2016-08-01');
                var response = yield this._client.beginRequest(httpRequest);
                if (response.statusCode != 200) {
                    throw (0, AzureServiceClientBase_1.ToError)(response);
                }
                var appDetails = response.body;
                return appDetails;
            }
            catch (error) {
                throw Error(tl.loc('FailedToGetAppServiceDetails', this._getFormattedName(), this._client.getFormattedError(error)));
            }
        });
    }
    _getFormattedName() {
        return this._slot ? `${this._name}-${this._slot}` : this._name;
    }
    getName() {
        return this._name;
    }
    getSitePublishingCredentialPolicies() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                var httpRequest = new webClient.WebRequest();
                httpRequest.method = 'GET';
                var slotUrl = !!this._slot ? `/slots/${this._slot}` : '';
                const isAzureStack = this._client.getCredentials().isAzureStackEnvironment;
                const apiVersion = isAzureStack ? '2020-12-01' : '2022-03-01';
                httpRequest.uri = this._client.getRequestUri(`//subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.Web/sites/{name}/${slotUrl}/basicPublishingCredentialsPolicies/scm`, {
                    '{resourceGroupName}': this._resourceGroup,
                    '{name}': this._name,
                }, null, apiVersion);
                let requestOptions = new webClient.WebRequestOptions();
                requestOptions.retryCount = 1;
                var response = yield this._client.beginRequest(httpRequest, requestOptions);
                if (response.statusCode != 200) {
                    throw (0, AzureServiceClientBase_1.ToError)(response);
                }
                return response.body;
            }
            catch (error) {
                throw Error(`Failed to get SitePublishingCredentialPolicies. Error: ${this._client.getFormattedError(error)}`);
            }
        });
    }
    updateSiteContainer(siteContainerProperties, siteContainerName) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const httpRequest = new webClient.WebRequest();
                httpRequest.method = 'PUT';
                httpRequest.body = JSON.stringify({
                    properties: siteContainerProperties
                });
                const slotUrl = !!this._slot ? `/slots/${this._slot}` : '';
                httpRequest.uri = this._client.getRequestUri(`//subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.Web/sites/{name}/${slotUrl}/sitecontainers/${siteContainerName}`, {
                    '{resourceGroupName}': this._resourceGroup,
                    '{name}': this._name,
                }, null, '2024-11-01');
                const response = yield this._client.beginRequest(httpRequest);
                if (response.statusCode != 200) {
                    throw (0, AzureServiceClientBase_1.ToError)(response);
                }
                return response.body;
            }
            catch (error) {
                throw Error(tl.loc('FailedToUpdateSiteContainer', this._getFormattedName(), siteContainerName, this._client.getFormattedError(error)));
            }
        });
    }
    _getAppServiceInstances() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                var slotUrl = !!this._slot ? `/slots/${this._slot}` : '';
                var httpRequest = new webClient.WebRequest();
                httpRequest.method = 'GET';
                httpRequest.uri = this._client.getRequestUri(`//subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.Web/sites/{name}/${slotUrl}/instances`, {
                    '{resourceGroupName}': this._resourceGroup,
                    '{name}': this._name,
                }, null, '2025-03-01');
                var response = yield this._client.beginRequest(httpRequest);
                if (response.statusCode != 200) {
                    throw (0, AzureServiceClientBase_1.ToError)(response);
                }
                return response.body;
            }
            catch (error) {
                throw Error(tl.loc('FailedToGetAppServiceInstances', this._getFormattedName(), this._client.getFormattedError(error)));
            }
        });
    }
}
exports.AzureAppService = AzureAppService;
