"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ApplicationInsightsTests = void 0;
const assert = require("assert");
const ttm = __importStar(require("azure-pipelines-task-lib/mock-test"));
const path = __importStar(require("path"));
function ApplicationInsightsTests(defaultTimeout = 2000) {
    it('azure-arm-appinsights-webtests ApplicationInsightsWebTests', function (done) {
        this.timeout(defaultTimeout);
        let tp = path.join(__dirname, 'azure-arm-appinsights-webtests-tests.js');
        let tr = new ttm.MockTestRunner(tp);
        let passed = true;
        tr.runAsync()
            .then(() => {
            assert(tr.succeeded, "azure-arm-appinsights-tests should have passed but failed.");
            console.log("\tvalidating list");
            list(tr);
            console.log("\tvalidating create");
            create(tr);
            done();
        })
            .catch((error) => {
            passed = false;
            console.log(tr.stdout);
            console.log(tr.stderr);
            done(error);
        });
    });
}
exports.ApplicationInsightsTests = ApplicationInsightsTests;
function list(tr) {
    assert(tr.stdOutContained('retrieved list of tests for MOCK_RESOURCE_GROUP_NAME.'), 'Should have printed: retrieved list of tests for MOCK_RESOURCE_GROUP_NAME.');
    assert(tr.stdOutContained('WEB TEST COUNT: 2'), 'Should have printed: WEB TEST COUNT: 2');
}
function create(tr) {
    assert(tr.stdOutContained('Failed to create Web Test'), 'Should have printed: Failed to create Web Test');
    assert(tr.stdOutContained('added web test MOCK_TEST_1.'), 'added web test MOCK_TEST_1.');
}
