export declare function ResourcesTests(defaultTimeout?: number): void;
