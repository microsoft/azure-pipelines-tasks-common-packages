"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.WebClientTests = void 0;
const assert = require("assert");
const http = require("http");
const httpClient = require("typed-rest-client/HttpClient");
const tl = __importStar(require("azure-pipelines-task-lib/task"));
const azCliUtility_1 = require("../azCliUtility");
const webClient = __importStar(require("../webClient"));
function WebClientTests() {
    const originalHttpClient = httpClient.HttpClient;
    const originalSendRequest = webClient.sendRequest;
    const originalGetPipelineFeature = tl.getPipelineFeature;
    const originalDebug = tl.debug;
    const originalWarning = tl.warning;
    const originalConsoleLog = console.log;
    afterEach(() => {
        httpClient.HttpClient = originalHttpClient;
        webClient.sendRequest = originalSendRequest;
        tl.getPipelineFeature = originalGetPipelineFeature;
        tl.debug = originalDebug;
        tl.warning = originalWarning;
        console.log = originalConsoleLog;
    });
    it('applies the request socket timeout and disposes the client on success', () => __awaiter(this, void 0, void 0, function* () {
        let capturedOptions;
        let disposeCount = 0;
        httpClient.HttpClient = class {
            constructor(userAgent, handlers, options) {
                capturedOptions = options;
            }
            request() {
                return __awaiter(this, void 0, void 0, function* () {
                    return {
                        message: {
                            statusCode: 200,
                            statusMessage: 'OK',
                            headers: {}
                        },
                        readBody: () => __awaiter(this, void 0, void 0, function* () { return '{}'; })
                    };
                });
            }
            dispose() {
                disposeCount++;
            }
        };
        const request = Object.assign(new webClient.WebRequest(), {
            method: 'GET',
            uri: 'https://example.test',
            headers: {}
        });
        const options = Object.assign(new webClient.WebRequestOptions(), { socketTimeout: 3000 });
        const response = yield webClient.sendRequest(request, options);
        assert.strictEqual(response.statusCode, 200);
        assert.strictEqual(capturedOptions.socketTimeout, 3000);
        assert.strictEqual(disposeCount, 1);
    }));
    it('makes one attempt, suppresses the task issue, and disposes on failure', () => __awaiter(this, void 0, void 0, function* () {
        let requestCount = 0;
        let disposeCount = 0;
        const consoleOutput = [];
        httpClient.HttpClient = class {
            request() {
                return __awaiter(this, void 0, void 0, function* () {
                    requestCount++;
                    const error = new Error('connection reset');
                    error.code = 'ECONNRESET';
                    throw error;
                });
            }
            dispose() {
                disposeCount++;
            }
        };
        console.log = (message) => consoleOutput.push(String(message));
        const request = Object.assign(new webClient.WebRequest(), {
            method: 'GET',
            uri: 'https://example.test',
            headers: {}
        });
        const options = Object.assign(new webClient.WebRequestOptions(), {
            retryCount: 1,
            suppressErrorIssue: true
        });
        yield assert.rejects(webClient.sendRequest(request, options), /connection reset/);
        assert.strictEqual(requestCount, 1);
        assert.strictEqual(disposeCount, 1);
        assert.strictEqual(consoleOutput.some(line => line.includes('task.logissue')), false);
    }));
    it('preserves default timeout and error issue behavior when options are omitted', () => __awaiter(this, void 0, void 0, function* () {
        let capturedOptions;
        const consoleOutput = [];
        httpClient.HttpClient = class {
            constructor(userAgent, handlers, options) {
                capturedOptions = options;
            }
            request() {
                return __awaiter(this, void 0, void 0, function* () {
                    const error = new Error('request failed');
                    error.code = 'CUSTOM';
                    throw error;
                });
            }
            dispose() {
            }
        };
        console.log = (message) => consoleOutput.push(String(message));
        const request = Object.assign(new webClient.WebRequest(), {
            method: 'GET',
            uri: 'https://example.test',
            headers: {}
        });
        yield assert.rejects(webClient.sendRequest(request), /request failed/);
        assert.strictEqual(capturedOptions.socketTimeout, undefined);
        assert.strictEqual(consoleOutput.some(line => line.includes('##vso[task.logissue type=error;code=CUSTOM;]request failed')), true);
    }));
    it('terminates a request when the socket does not respond', () => __awaiter(this, void 0, void 0, function* () {
        const server = http.createServer(() => {
        });
        yield new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
        try {
            const address = server.address();
            const request = Object.assign(new webClient.WebRequest(), {
                method: 'GET',
                uri: `http://127.0.0.1:${address.port}`,
                headers: {}
            });
            const options = Object.assign(new webClient.WebRequestOptions(), {
                retryCount: 1,
                socketTimeout: 50,
                suppressErrorIssue: true
            });
            const startedAt = Date.now();
            yield assert.rejects(webClient.sendRequest(request, options));
            assert(Date.now() - startedAt < 2000, 'the socket timeout should bound the stalled request');
        }
        finally {
            server.close();
        }
    }));
    it('uses bounded request options for the advisory version check', () => __awaiter(this, void 0, void 0, function* () {
        let requestCount = 0;
        let capturedRequest;
        let capturedOptions;
        let warningCount = 0;
        tl.getPipelineFeature = () => true;
        tl.warning = () => warningCount++;
        webClient.sendRequest = (request, options) => __awaiter(this, void 0, void 0, function* () {
            requestCount++;
            capturedRequest = request;
            capturedOptions = options;
            return { body: [{ tag_name: 'azure-cli-2.90.0' }] };
        });
        yield (0, azCliUtility_1.validateAzModuleVersion)('azure-Cli', '2.80.0', 'Azure-Cli', 1);
        assert.strictEqual(requestCount, 1);
        assert.strictEqual(capturedRequest.uri, 'https://api.github.com/repos/Azure/azure-Cli/releases');
        assert.strictEqual(capturedOptions.retryCount, 1);
        assert.strictEqual(capturedOptions.socketTimeout, 3000);
        assert.strictEqual(capturedOptions.suppressErrorIssue, true);
        assert.strictEqual(warningCount, 1);
    }));
    it('logs advisory request failures at debug level and continues', () => __awaiter(this, void 0, void 0, function* () {
        const debugOutput = [];
        tl.getPipelineFeature = () => true;
        tl.debug = (message) => debugOutput.push(message);
        webClient.sendRequest = () => __awaiter(this, void 0, void 0, function* () {
            throw new Error('GitHub unavailable');
        });
        yield (0, azCliUtility_1.validateAzModuleVersion)('azure-Cli', '2.90.0', 'Azure-Cli', 1);
        assert.strictEqual(debugOutput.some(line => line.includes('GitHub unavailable') && line.includes('skipping the check')), true);
    }));
    it('does not make an advisory request when the feature is disabled', () => __awaiter(this, void 0, void 0, function* () {
        let requestCount = 0;
        tl.getPipelineFeature = () => false;
        webClient.sendRequest = () => __awaiter(this, void 0, void 0, function* () {
            requestCount++;
            return { body: [] };
        });
        yield (0, azCliUtility_1.validateAzModuleVersion)('azure-Cli', '2.90.0', 'Azure-Cli', 1);
        assert.strictEqual(requestCount, 0);
    }));
}
exports.WebClientTests = WebClientTests;
