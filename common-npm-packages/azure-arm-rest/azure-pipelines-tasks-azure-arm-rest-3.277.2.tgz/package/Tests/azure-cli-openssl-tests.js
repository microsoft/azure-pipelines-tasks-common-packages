"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const azure_arm_common_1 = require("../azure-arm-common");
function RUNTESTS() {
    return __awaiter(this, void 0, void 0, function* () {
        const applicationTokenCredentials = new azure_arm_common_1.ApplicationTokenCredentials("MOCK_SERVICE_CONNECTION", "MOCK_SPN_ID", "MOCK_TENANT_ID", "MOCK_SPN_KEY", "https://management.azure.com/", "https://login.windows.net/", "https://management.azure.com/", false);
        console.log(applicationTokenCredentials.getOpenSSLPath());
    });
}
RUNTESTS();
