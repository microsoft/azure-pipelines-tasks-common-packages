"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const azure_arm_app_service_1 = require("../azure-arm-app-service");
const mock_utils_1 = require("./mock_utils");
const tl = require("azure-pipelines-task-lib/task");
var endpoint = (0, mock_utils_1.getMockEndpoint)();
(0, mock_utils_1.mockAzureAppServiceTests)();
class AzureAppServiceTests {
    static start() {
        return __awaiter(this, void 0, void 0, function* () {
            var appSerivce = new azure_arm_app_service_1.AzureAppService(endpoint, "MOCK_RESOURCE_GROUP_NAME", "MOCK_APP_SERVICE_NAME");
            try {
                yield appSerivce.start();
            }
            catch (error) {
                console.log(error);
                tl.setResult(tl.TaskResult.Failed, 'AzureAppServiceTests.start() should have passed but failed');
            }
            var appSerivceSlot = new azure_arm_app_service_1.AzureAppService(endpoint, "MOCK_RESOURCE_GROUP_NAME", "MOCK_APP_SERVICE_NAME", "MOCK_SLOT_NAME");
            try {
                yield appSerivceSlot.start();
                tl.setResult(tl.TaskResult.Failed, 'AzureAppServiceTests.start() should have failed but passed');
            }
            catch (error) {
                console.log(error);
            }
        });
    }
    static stop() {
        return __awaiter(this, void 0, void 0, function* () {
            var appSerivce = new azure_arm_app_service_1.AzureAppService(endpoint, "MOCK_RESOURCE_GROUP_NAME", "MOCK_APP_SERVICE_NAME");
            appSerivce.stop().catch((error) => {
                tl.setResult(tl.TaskResult.Failed, 'AzureAppServiceTests.stop() should have passed but failed');
            });
            var appSerivceSlot = new azure_arm_app_service_1.AzureAppService(endpoint, "MOCK_RESOURCE_GROUP_NAME", "MOCK_APP_SERVICE_NAME", "MOCK_SLOT_NAME");
            appSerivceSlot.stop().then((value) => {
                tl.setResult(tl.TaskResult.Failed, 'AzureAppServiceTests.stop() should have failed but passed');
            }).catch((error) => {
                console.log(error);
            });
        });
    }
    static restart() {
        return __awaiter(this, void 0, void 0, function* () {
            var appSerivce = new azure_arm_app_service_1.AzureAppService(endpoint, "MOCK_RESOURCE_GROUP_NAME", "MOCK_APP_SERVICE_NAME");
            appSerivce.restart().catch((error) => {
                tl.setResult(tl.TaskResult.Failed, 'AzureAppServiceTests.restart() should have passed but failed');
            });
            var appSerivceSlot = new azure_arm_app_service_1.AzureAppService(endpoint, "MOCK_RESOURCE_GROUP_NAME", "MOCK_APP_SERVICE_NAME", "MOCK_SLOT_NAME");
            appSerivceSlot.restart().then((value) => {
                tl.setResult(tl.TaskResult.Failed, 'AzureAppServiceTests.restart() should have failed but passed');
            }).catch((error) => {
                console.log(error);
            });
        });
    }
    static delete() {
        return __awaiter(this, void 0, void 0, function* () {
            var appSerivce = new azure_arm_app_service_1.AzureAppService(endpoint, "MOCK_RESOURCE_GROUP_NAME", "MOCK_APP_SERVICE_NAME", "MOCK_SLOT_NAME");
            appSerivce.delete().catch((error) => {
                tl.setResult(tl.TaskResult.Failed, 'AzureAppServiceTests.delete() should have passed but failed');
            });
        });
    }
    static swap() {
        return __awaiter(this, void 0, void 0, function* () {
            var appSerivce = new azure_arm_app_service_1.AzureAppService(endpoint, "MOCK_RESOURCE_GROUP_NAME", "MOCK_APP_SERVICE_NAME");
            appSerivce.swap("MOCK_TARGET_SLOT", false).catch((error) => {
                console.log(error);
                tl.setResult(tl.TaskResult.Failed, 'AzureAppServiceTests.swap() should have passed but failed');
            });
            var appSerivceSlot = new azure_arm_app_service_1.AzureAppService(endpoint, "MOCK_RESOURCE_GROUP_NAME", "MOCK_APP_SERVICE_NAME", "MOCK_SLOT_NAME");
            appSerivceSlot.swap("MOCK_TARGET_SLOT", true).then((value) => {
                tl.setResult(tl.TaskResult.Failed, 'AzureAppServiceTests.swap() should have failed but passed');
            }).catch((error) => {
                console.log(error);
            });
        });
    }
    static swapSlotWithPreview() {
        return __awaiter(this, void 0, void 0, function* () {
            var appSerivce = new azure_arm_app_service_1.AzureAppService(endpoint, "MOCK_RESOURCE_GROUP_NAME", "MOCK_APP_SERVICE_NAME");
            appSerivce.swapSlotWithPreview("MOCK_TARGET_SLOT", false).catch((error) => {
                console.log(error);
                tl.setResult(tl.TaskResult.Failed, 'AzureAppServiceTests.swapSlotWithPreview() should have passed but failed');
            });
            var appSerivceSlot = new azure_arm_app_service_1.AzureAppService(endpoint, "MOCK_RESOURCE_GROUP_NAME", "MOCK_APP_SERVICE_NAME", "MOCK_SLOT_NAME");
            appSerivceSlot.swapSlotWithPreview("MOCK_TARGET_SLOT", true).then((value) => {
                tl.setResult(tl.TaskResult.Failed, 'AzureAppServiceTests.swapSlotWithPreview() should have failed but passed');
            }).catch((error) => {
                console.log(error);
            });
        });
    }
    static cancelSwapSlotWithPreview() {
        return __awaiter(this, void 0, void 0, function* () {
            var appSerivce = new azure_arm_app_service_1.AzureAppService(endpoint, "MOCK_RESOURCE_GROUP_NAME", "MOCK_APP_SERVICE_NAME");
            appSerivce.cancelSwapSlotWithPreview().catch((error) => {
                console.log(error);
                tl.setResult(tl.TaskResult.Failed, 'AzureAppServiceTests.cancelSwapSlotWithPreview() should have passed but failed');
            });
            var appSerivceSlot = new azure_arm_app_service_1.AzureAppService(endpoint, "MOCK_RESOURCE_GROUP_NAME", "MOCK_APP_SERVICE_NAME", "MOCK_SLOT_NAME");
            appSerivceSlot.cancelSwapSlotWithPreview().then((value) => {
                tl.setResult(tl.TaskResult.Failed, 'AzureAppServiceTests.cancelSwapSlotWithPreview() should have failed but passed');
            }).catch((error) => {
                console.log(error);
            });
        });
    }
    static get() {
        return __awaiter(this, void 0, void 0, function* () {
            var appSerivce = new azure_arm_app_service_1.AzureAppService(endpoint, "MOCK_RESOURCE_GROUP_NAME", "MOCK_APP_SERVICE_NAME");
            try {
                var value = yield appSerivce.get();
                console.log('MOCK_APP_SERVICE_NAME ID: ' + value.id);
            }
            catch (error) {
                console.log(error);
                tl.setResult(tl.TaskResult.Failed, 'AzureAppServiceTests.get() should have passed but failed');
            }
            var appSerivceSlot = new azure_arm_app_service_1.AzureAppService(endpoint, "MOCK_RESOURCE_GROUP_NAME", "MOCK_APP_SERVICE_NAME", "MOCK_SLOT_NAME");
            try {
                yield appSerivceSlot.get();
                tl.setResult(tl.TaskResult.Failed, 'AzureAppServiceTests.get() should have failed but passed');
            }
            catch (error) {
                console.log(error);
            }
        });
    }
    static getPublishingProfileWithSecrets() {
        return __awaiter(this, void 0, void 0, function* () {
            var appSerivce = new azure_arm_app_service_1.AzureAppService(endpoint, "MOCK_RESOURCE_GROUP_NAME", "MOCK_APP_SERVICE_NAME");
            try {
                var value = yield appSerivce.getPublishingProfileWithSecrets();
                console.log('MOCK_APP_SERVICE_NAME PUBLISHING_PROFILE : ' + value);
            }
            catch (error) {
                console.log(error);
                tl.setResult(tl.TaskResult.Failed, 'AzureAppServiceTests.getPublishingProfileWithSecrets() should have passed but failed');
            }
            var appSerivceSlot = new azure_arm_app_service_1.AzureAppService(endpoint, "MOCK_RESOURCE_GROUP_NAME", "MOCK_APP_SERVICE_NAME", "MOCK_SLOT_NAME");
            try {
                yield appSerivceSlot.getPublishingProfileWithSecrets();
                tl.setResult(tl.TaskResult.Failed, 'AzureAppServiceTests.getPublishingProfileWithSecrets() should have failed but passed');
            }
            catch (error) {
                console.log(error);
            }
        });
    }
    static getPublishingCredentials() {
        return __awaiter(this, void 0, void 0, function* () {
            var appSerivce = new azure_arm_app_service_1.AzureAppService(endpoint, "MOCK_RESOURCE_GROUP_NAME", "MOCK_APP_SERVICE_NAME");
            try {
                var value = yield appSerivce.getPublishingCredentials();
                console.log('MOCK_APP_SERVICE_NAME PUBLISHINGCREDENTIALS ID: ' + value.id);
            }
            catch (error) {
                console.log(error);
                tl.setResult(tl.TaskResult.Failed, 'AzureAppServiceTests.getPublishingCredentials() should have passed but failed');
            }
            var appSerivceSlot = new azure_arm_app_service_1.AzureAppService(endpoint, "MOCK_RESOURCE_GROUP_NAME", "MOCK_APP_SERVICE_NAME", "MOCK_SLOT_NAME");
            try {
                yield appSerivceSlot.getPublishingCredentials();
                tl.setResult(tl.TaskResult.Failed, 'AzureAppServiceTests.getPublishingCredentials() should have failed but passed');
            }
            catch (error) {
                console.log(error);
            }
        });
    }
    static getApplicationSettings() {
        return __awaiter(this, void 0, void 0, function* () {
            var appSerivce = new azure_arm_app_service_1.AzureAppService(endpoint, "MOCK_RESOURCE_GROUP_NAME", "MOCK_APP_SERVICE_NAME");
            try {
                var value = yield appSerivce.getApplicationSettings();
                console.log('MOCK_APP_SERVICE_NAME APPSETTINGS ID: ' + value.id);
            }
            catch (error) {
                console.log(error);
                tl.setResult(tl.TaskResult.Failed, 'AzureAppServiceTests.getApplicationSettings() should have passed but failed');
            }
            var appSerivceSlot = new azure_arm_app_service_1.AzureAppService(endpoint, "MOCK_RESOURCE_GROUP_NAME", "MOCK_APP_SERVICE_NAME", "MOCK_SLOT_NAME");
            try {
                yield appSerivceSlot.getApplicationSettings();
                tl.setResult(tl.TaskResult.Failed, 'AzureAppServiceTests.getApplicationSettings() should have failed but passed');
            }
            catch (error) {
                console.log(error);
            }
        });
    }
    static updateApplicationSettings() {
        return __awaiter(this, void 0, void 0, function* () {
            var appSettings = {
                id: "/subscriptions/MOCK_SUBSCRIPTION_ID/resourceGroups/vincaAzureRG/providers/Microsoft.Web/sites/MOCK_APP_SERVICE_NAME/appsettings",
                name: "MOCK_APP_SERVICE_NAME",
                type: "Microsoft.Web/sites",
                kind: "app",
                location: "South Central US",
                properties: {
                    "WEBSITE_NODE_DEFAULT_VERSION": "6.9.1",
                    "MSDEPLOY_RENAME_LOCKED_FILES": "0"
                }
            };
            var appSerivce = new azure_arm_app_service_1.AzureAppService(endpoint, "MOCK_RESOURCE_GROUP_NAME", "MOCK_APP_SERVICE_NAME");
            try {
                var value = yield appSerivce.updateApplicationSettings(appSettings);
                console.log('MOCK_APP_SERVICE_NAME PUBLISHINGCREDENTIALS ID: ' + value.id);
            }
            catch (error) {
                console.log(error);
                tl.setResult(tl.TaskResult.Failed, 'AzureAppServiceTests.updateApplicationSettings() should have passed but failed');
            }
            var appSerivceSlot = new azure_arm_app_service_1.AzureAppService(endpoint, "MOCK_RESOURCE_GROUP_NAME", "MOCK_APP_SERVICE_NAME", "MOCK_SLOT_NAME");
            try {
                yield appSerivceSlot.updateApplicationSettings(appSettings);
                tl.setResult(tl.TaskResult.Failed, 'AzureAppServiceTests.updateApplicationSettings() should have failed but passed');
            }
            catch (error) {
                console.log(error);
            }
        });
    }
    static getConfiguration() {
        return __awaiter(this, void 0, void 0, function* () {
            var appSerivce = new azure_arm_app_service_1.AzureAppService(endpoint, "MOCK_RESOURCE_GROUP_NAME", "MOCK_APP_SERVICE_NAME");
            try {
                var value = yield appSerivce.getConfiguration();
                console.log('MOCK_APP_SERVICE_NAME CONFIG_WEB ID: ' + value.id);
            }
            catch (error) {
                console.log(error);
                tl.setResult(tl.TaskResult.Failed, 'AzureAppServiceTests.getConfiguration() should have passed but failed');
            }
            var appSerivceSlot = new azure_arm_app_service_1.AzureAppService(endpoint, "MOCK_RESOURCE_GROUP_NAME", "MOCK_APP_SERVICE_NAME", "MOCK_SLOT_NAME");
            try {
                yield appSerivceSlot.getApplicationSettings();
                tl.setResult(tl.TaskResult.Failed, 'AzureAppServiceTests.getConfiguration() should have failed but passed');
            }
            catch (error) {
                console.log(error);
            }
        });
    }
    static updateConfiguration() {
        return __awaiter(this, void 0, void 0, function* () {
            var appSettings = {
                id: "/subscriptions/MOCK_SUBSCRIPTION_ID/resourceGroups/vincaAzureRG/providers/Microsoft.Web/sites/MOCK_APP_SERVICE_NAME/config/web",
                name: "MOCK_APP_SERVICE_NAME",
                type: "Microsoft.Web/sites",
                kind: "app",
                location: "South Central US",
                properties: {
                    "alwaysOn": true
                }
            };
            var appSerivce = new azure_arm_app_service_1.AzureAppService(endpoint, "MOCK_RESOURCE_GROUP_NAME", "MOCK_APP_SERVICE_NAME");
            try {
                var value = yield appSerivce.updateConfiguration(appSettings);
                console.log('MOCK_APP_SERVICE_NAME CONFIG_WEB ID: ' + value.id);
            }
            catch (error) {
                console.log(error);
                tl.setResult(tl.TaskResult.Failed, 'AzureAppServiceTests.updateConfiguration() should have passed but failed');
            }
            var appSerivceSlot = new azure_arm_app_service_1.AzureAppService(endpoint, "MOCK_RESOURCE_GROUP_NAME", "MOCK_APP_SERVICE_NAME", "MOCK_SLOT_NAME");
            try {
                yield appSerivceSlot.updateConfiguration(appSettings);
                tl.setResult(tl.TaskResult.Failed, 'AzureAppServiceTests.updateConfiguration() should have failed but passed');
            }
            catch (error) {
                console.log(error);
            }
        });
    }
    static patchConfiguration() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                var appSerivce = new azure_arm_app_service_1.AzureAppService(endpoint, "MOCK_RESOURCE_GROUP_NAME", "MOCK_APP_SERVICE_NAME");
                yield appSerivce.patchConfiguration({ 'properties': {} });
                console.log('PATCH CONFIGURATION PASSED');
            }
            catch (error) {
                console.log(error);
                tl.setResult(tl.TaskResult.Failed, 'AzureAppServiceTests.patchConfiguration() should have passed but failed');
            }
            try {
                var appSerivceSlot = new azure_arm_app_service_1.AzureAppService(endpoint, "MOCK_RESOURCE_GROUP_NAME", "MOCK_APP_SERVICE_NAME", "MOCK_SLOT_NAME");
                yield appSerivceSlot.patchConfiguration({ 'properties': {} });
                tl.setResult(tl.TaskResult.Failed, 'AzureAppServiceTests.patchConfiguration() should have failed but passed');
            }
            catch (error) {
                console.log(error);
            }
        });
    }
    static getMetadata() {
        return __awaiter(this, void 0, void 0, function* () {
            var appSerivce = new azure_arm_app_service_1.AzureAppService(endpoint, "MOCK_RESOURCE_GROUP_NAME", "MOCK_APP_SERVICE_NAME");
            try {
                var value = yield appSerivce.getMetadata();
                console.log('MOCK_APP_SERVICE_NAME CONFIG_METADATA GET ID: ' + value.id);
            }
            catch (error) {
                console.log(error);
                tl.setResult(tl.TaskResult.Failed, 'AzureAppServiceTests.getMetadata() should have passed but failed');
            }
            var appSerivceSlot = new azure_arm_app_service_1.AzureAppService(endpoint, "MOCK_RESOURCE_GROUP_NAME", "MOCK_APP_SERVICE_NAME", "MOCK_SLOT_NAME");
            try {
                yield appSerivceSlot.getMetadata();
                tl.setResult(tl.TaskResult.Failed, 'AzureAppServiceTests.getMetadata() should have failed but passed');
            }
            catch (error) {
                console.log(error);
            }
        });
    }
    static updateMetadata() {
        return __awaiter(this, void 0, void 0, function* () {
            var appSettings = {
                id: "/subscriptions/MOCK_SUBSCRIPTION_ID/resourceGroups/vincaAzureRG/providers/Microsoft.Web/sites/MOCK_APP_SERVICE_NAME/config/metadata",
                name: "MOCK_APP_SERVICE_NAME",
                type: "Microsoft.Web/sites",
                kind: "app",
                location: "South Central US",
                properties: {
                    "alwaysOn": true
                }
            };
            var appSerivce = new azure_arm_app_service_1.AzureAppService(endpoint, "MOCK_RESOURCE_GROUP_NAME", "MOCK_APP_SERVICE_NAME");
            try {
                var value = yield appSerivce.updateMetadata(appSettings);
                console.log('MOCK_APP_SERVICE_NAME CONFIG_METADATA UPDATE ID: ' + value.id);
            }
            catch (error) {
                console.log(error);
                tl.setResult(tl.TaskResult.Failed, 'AzureAppServiceTests.updateMetadata() should have passed but failed');
            }
            var appSerivceSlot = new azure_arm_app_service_1.AzureAppService(endpoint, "MOCK_RESOURCE_GROUP_NAME", "MOCK_APP_SERVICE_NAME", "MOCK_SLOT_NAME");
            try {
                yield appSerivceSlot.updateMetadata(appSettings);
                tl.setResult(tl.TaskResult.Failed, 'AzureAppServiceTests.updateMetadata() should have failed but passed');
            }
            catch (error) {
                console.log(error);
            }
        });
    }
}
function RUNTESTS() {
    return __awaiter(this, void 0, void 0, function* () {
        yield AzureAppServiceTests.start();
        yield AzureAppServiceTests.stop();
        yield AzureAppServiceTests.restart();
        yield AzureAppServiceTests.delete();
        yield AzureAppServiceTests.swap();
        yield AzureAppServiceTests.swapSlotWithPreview();
        yield AzureAppServiceTests.cancelSwapSlotWithPreview();
        yield AzureAppServiceTests.get();
        yield AzureAppServiceTests.getPublishingProfileWithSecrets();
        yield AzureAppServiceTests.getPublishingCredentials();
        yield AzureAppServiceTests.getApplicationSettings();
        yield AzureAppServiceTests.updateApplicationSettings();
        yield AzureAppServiceTests.getConfiguration();
        yield AzureAppServiceTests.updateConfiguration();
        yield AzureAppServiceTests.patchConfiguration();
        yield AzureAppServiceTests.getMetadata();
        yield AzureAppServiceTests.updateMetadata();
    });
}
RUNTESTS();
