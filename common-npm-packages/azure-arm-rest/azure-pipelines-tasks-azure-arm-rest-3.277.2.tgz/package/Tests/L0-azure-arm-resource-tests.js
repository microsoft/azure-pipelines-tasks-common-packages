"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ResourcesTests = void 0;
const assert = require("assert");
const ttm = __importStar(require("azure-pipelines-task-lib/mock-test"));
const path = __importStar(require("path"));
function ResourcesTests(defaultTimeout = 2000) {
    it('azure-arm-resource Resources', function (done) {
        this.timeout(defaultTimeout);
        let tp = path.join(__dirname, 'azure-arm-resource-tests.js');
        let tr = new ttm.MockTestRunner(tp);
        let passed = true;
        tr.runAsync()
            .then(() => {
            assert(tr.stdOutContained('ResourcesTests - getResources : 1'), "Should have printed: ResourcesTests - getResources : 1");
            done();
        })
            .catch((error) => {
            passed = false;
            console.log(tr.stdout);
            console.log(tr.stderr);
            done(error);
        });
    });
}
exports.ResourcesTests = ResourcesTests;
