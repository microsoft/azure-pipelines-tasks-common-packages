"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AksServiceTests = void 0;
const mock_utils_1 = require("./mock_utils");
const tl = require("azure-pipelines-task-lib");
const azure_arm_aks_service_1 = require("../azure-arm-aks-service");
var endpoint = (0, mock_utils_1.getMockEndpoint)();
// Mock all calls for Azure AKS Service
(0, mock_utils_1.mockAzureAksServiceTests)();
class AksServiceTests {
    static credentialsByClusterAdmin() {
        return __awaiter(this, void 0, void 0, function* () {
            let aksService = new azure_arm_aks_service_1.AzureAksService(endpoint);
            try {
                let result = yield aksService.getClusterCredential("MOCK_RESOURCE_GROUP_NAME", "MOCK_CLUSTER", true);
                console.log(`Aks Cluster Credential Found: ${result.name}`);
            }
            catch (error) {
                console.log(error);
                tl.setResult(tl.TaskResult.Failed, 'AksServiceTests.credentialsByClusterAdmin() should have passed but failed');
            }
        });
    }
    static credentialsByClusterUser() {
        return __awaiter(this, void 0, void 0, function* () {
            let aksService = new azure_arm_aks_service_1.AzureAksService(endpoint);
            try {
                let result = yield aksService.getClusterCredential("MOCK_RESOURCE_GROUP_NAME", "MOCK_CLUSTER", false);
                console.log(`Aks Cluster Credential Found: ${result.name}`);
            }
            catch (error) {
                console.log(error);
                tl.setResult(tl.TaskResult.Failed, 'AksServiceTests.credentialsByClusterUser() should have passed but failed');
            }
        });
    }
    static credentialsByCustomClusterUser() {
        return __awaiter(this, void 0, void 0, function* () {
            let aksService = new azure_arm_aks_service_1.AzureAksService(endpoint);
            try {
                let result = yield aksService.getClusterCredential("MOCK_RESOURCE_GROUP_NAME", "MOCK_CLUSTER", false, 'customUser');
                console.log(`Aks Cluster Credential Found: ${result.name}`);
            }
            catch (error) {
                console.log(error);
                tl.setResult(tl.TaskResult.Failed, 'AksServiceTests.credentialsByCustomClusterUser() should have passed but failed');
            }
        });
    }
    static credentialsFleetUser() {
        return __awaiter(this, void 0, void 0, function* () {
            let aksService = new azure_arm_aks_service_1.AzureAksService(endpoint);
            try {
                let result = yield aksService.getFleetCredential("MOCK_RESOURCE_GROUP_NAME", "MOCK_FLEET");
                console.log(`Fleet Credential Found: ${result.name}`);
            }
            catch (error) {
                console.log(error);
                tl.setResult(tl.TaskResult.Failed, 'AksServiceTests.credentialsByCustomFleetUser() should have passed but failed');
            }
        });
    }
}
exports.AksServiceTests = AksServiceTests;
function RUNTESTS() {
    return __awaiter(this, void 0, void 0, function* () {
        yield AksServiceTests.credentialsByClusterAdmin();
        yield AksServiceTests.credentialsByClusterUser();
        yield AksServiceTests.credentialsByCustomClusterUser();
        yield AksServiceTests.credentialsFleetUser();
    });
}
RUNTESTS();
