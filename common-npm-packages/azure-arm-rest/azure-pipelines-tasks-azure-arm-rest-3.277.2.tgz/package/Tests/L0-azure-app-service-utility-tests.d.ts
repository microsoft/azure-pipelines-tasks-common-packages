export declare function AzureAppServiceUtilityTests(defaultTimeout?: number): void;
