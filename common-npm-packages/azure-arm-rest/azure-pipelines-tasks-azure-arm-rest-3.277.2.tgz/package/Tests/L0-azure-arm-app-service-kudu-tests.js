"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.KuduServiceTests = void 0;
const assert = require("assert");
const ttm = __importStar(require("azure-pipelines-task-lib/mock-test"));
const path = __importStar(require("path"));
function KuduServiceTests(defaultTimeout = 2000) {
    it('azure-arm-app-service-kudu Kudu', function (done) {
        process.env['SYSTEM_DEBUG'] = 'true';
        this.timeout(defaultTimeout);
        let tp = path.join(__dirname, 'azure-arm-app-service-kudu-tests.js');
        let tr = new ttm.MockTestRunner(tp);
        let passed = true;
        tr.runAsync()
            .then(() => {
            assert(tr.succeeded, "azure-arm-app-service-kudu-tests should have passed but failed.");
            console.log("\tvalidating updateDeployment");
            updateDeployment(tr);
            console.log("\tvalidating getContinuousJobs");
            getContinuousJobs(tr);
            console.log("\tvalidating startContinuousWebJob");
            startContinuousWebJob(tr);
            console.log("\tvalidating stopContinuousWebJob");
            stopContinuousWebJob(tr);
            console.log("\tvalidating installSiteExtension");
            installSiteExtension(tr);
            console.log("\tvalidating getSiteExtensions");
            getSiteExtensions(tr);
            console.log("\tvalidating getAllSiteExtensions");
            getAllSiteExtensions(tr);
            console.log("\tvalidating getProcess");
            getProcess(tr);
            console.log("\tvalidating killProcess");
            killProcess(tr);
            console.log("\tvalidating getAppSettings");
            getAppSettings(tr);
            console.log("\tvalidating listDir");
            listDir(tr);
            console.log("\tvalidating getFileContent");
            getFileContent(tr);
            console.log("\tvalidating uploadFile");
            uploadFile(tr);
            console.log("\tvalidating createPath");
            createPath(tr);
            console.log("\tvalidating runCommand");
            runCommand(tr);
            console.log("\tvalidating extractZIP");
            extractZIP(tr);
            console.log("\tvalidating zipDeploy");
            zipDeploy(tr);
            console.log("\tvalidating deleteFile");
            deleteFile(tr);
            done();
        })
            .catch((error) => {
            passed = false;
            console.log(tr.stdout);
            console.log(tr.stderr);
            done(error);
        });
    });
}
exports.KuduServiceTests = KuduServiceTests;
function updateDeployment(tr) {
    assert(tr.stdOutContained("Successfully updated deployment History at http://MOCK_SCM_WEBSITE/api/deployments/MOCK_DEPLOYMENT_ID"), 'Should have printed: Successfully updated deployment History at http://MOCK_SCM_WEBSITE/api/deployments/MOCK_DEPLOYMENT_ID');
    assert(tr.stdOutContained("Error: Failed to update deployment history. Error: null (CODE: 501)"), 'Should have printed: Error: Failed to update deployment history. Error: null (CODE: 501)');
}
function getContinuousJobs(tr) {
    assert(tr.stdOutContained('MOCK KUDU CONTINUOUS JOBS COUNT: 2'), 'Should have printed: MOCK KUDU CONTINUOUS JOBS COUNT: 2');
    assert(tr.stdOutContained("Error: Failed to get continuous WebJobs. Error: null (CODE: 501)"), 'Should have printed: Error: Failed to get continuous WebJobs. Error: null (CODE: 501)');
}
function startContinuousWebJob(tr) {
    assert(tr.stdOutContained("WebJob 'MOCK_JOB_NAME' started."), 'Should have printed: WebJob MOCK_JOB_NAME started');
    assert(tr.stdOutContained("Error: Failed to start continuous WebJob 'MOCK_JOB_NAME'. Error: null (CODE: 501)"), 'Should have printed: Error: Failed to start continuous WebJob MOCK_JOB_NAME. Error: null (CODE: 501)');
}
function stopContinuousWebJob(tr) {
    assert(tr.stdOutContained("WebJob 'MOCK_JOB_NAME' stopped."), 'WebJob MOCK_JOB_NAME stopped');
    assert(tr.stdOutContained("Error: Failed to stop continuous WebJob 'MOCK_JOB_NAME'. Error: null (CODE: 501)"), 'Should have printed: Error: Failed to stop continuous WebJob MOCK_JOB_NAME. Error: null (CODE: 501)');
}
function installSiteExtension(tr) {
    assert(tr.stdOutContained("Site extension 'MOCK_EXTENSION' installed."), 'Should have printed: Site extension MOCK_EXTENSION installed');
    assert(tr.stdOutContained("Error: Failed to install site extension 'MOCK_EXTENSION'. Error: null (CODE: 501)"), 'Should have printed: Error: Failed to install site extension MOCK_EXTENSION. Error: null (CODE: 501)');
}
function installSiteExtensionWithVersion(tr) {
    assert(tr.stdOutContained("Site extension 'MOCK_EXTENSION' with version '1.0.0' installed successfully."), 'Should have printed: Site extension MOCK_EXTENSION with version 1.0.0 installed successfully.');
    assert(tr.stdOutContained("Failed to install site extension 'MOCK_EXTENSION' with version '1.0.0'. Error: null (CODE: 501)"), 'Should have printed: Failed to install site extension MOCK_EXTENSION with version 1.0.0. Error: null (CODE: 501)');
}
function getSiteExtensions(tr) {
    assert(tr.stdOutContained('MOCK KUDU SITE EXTENSIONS COUNT: 2'), 'Should have printed: MOCK KUDU SITE EXTENSIONS COUNT: 2');
    assert(tr.stdOutContained("Error: Failed to get site extensions. Error: null (CODE: 501)"), 'Should have printed: Error: Failed to get site extensions. Error: null (CODE: 501)');
}
function getAllSiteExtensions(tr) {
    assert(tr.stdOutContained('MOCK KUDU SITE EXTENSIONS COUNT: 3'), 'Should have printed: MOCK KUDU SITE EXTENSIONS COUNT: 3');
    assert(tr.stdOutContained("Error: Failed to get extension feed. Error: null (CODE: 501)"), 'Should have printed: Error: Failed to get extension feed. Error: null (CODE: 501)');
}
function getProcess(tr) {
    assert(tr.stdOutContained('MOCK KUDU PROCESS ID: 1'), 'Should have printed: MOCK KUDU PROCESS ID: 1');
}
function killProcess(tr) {
    assert(tr.stdOutContained('KILLED PROCESS 0'), 'Should have printed: KILLED PROCESS 0');
}
function getAppSettings(tr) {
    assert(tr.stdOutContained('KUDU APP SETTINGS {"MSDEPLOY_RENAME_LOCKED_FILES":"1","ScmType":"VSTSRM"}'), 'Should have printed: KUDU APP SETTINGS {"MSDEPLOY_RENAME_LOCKED_FILES":"1","ScmType":"VSTSRM"}');
    assert(tr.stdOutContained("Error: Failed to fetch Kudu App Settings. Error: null (CODE: 501)"), 'Should have printed: Error: Failed to fetch Kudu App Settings. Error: null (CODE: 501)');
}
function listDir(tr) {
    assert(tr.stdOutContained('KUDU LIST DIR [{"name":"web.config"},{"name":"content","size":777}]'), 'Should have printed: KUDU LIST DIR [{"name":"web.config"},{"name":"content","size":777}]');
    assert(tr.stdOutContained("Error: Failed to list path 'site/wwwroot'. Error: null (CODE: 501)"), 'Should have printed: FailedToListPath site/wwwroot null (CODE: 501)');
}
function getFileContent(tr) {
    assert(tr.stdOutContained('KUDU FILE CONTENT HELLO.TXT FILE CONTENT'), 'Should have printed: KUDU FILE CONTENT HELLO.TXT FILE CONTENT');
    assert(tr.stdOutContained('KUDU FILE CONTENT 404 - PASSED'), 'Should have printed: KUDU FILE CONTENT 404 - PASSED');
    assert(tr.stdOutContained("Error: Failed to get file content 'site/wwwroot/web.config' from Kudu. Error: null (CODE: 501)"), 'Should have printed: "Error: Failed to get file content site/wwwroot/web.config from Kudu. Error: null (CODE: 501)');
}
function uploadFile(tr) {
    assert(tr.stdOutContained('KUDU FILE UPLOAD HELLO.TXT PASSED'), 'Should have printed: KUDU FILE UPLOAD HELLO.TXT PASSED');
    assert(tr.stdOutContained("Error: Failed to upload file 'site/wwwroot/web.config from Kudu. Error: null (CODE: 501)"), 'Should have printed: Error: Failed to upload file site/wwwroot/web.config from Kudu. Error: null (CODE: 501)');
}
function createPath(tr) {
    assert(tr.stdOutContained('KUDU CREATE PATH SITE/WWWROOT PASSED'), 'Should have printed: KUDU CREATE PATH SITE/WWWROOT PASSED');
    assert(tr.stdOutContained("Error: Failed to create path 'site/wwwroot' from Kudu. Error: null (CODE: 501)"), 'Should have printed: Error: Failed to create path site/wwwroot from Kudu. Error: null (CODE: 501)');
}
function runCommand(tr) {
    assert(tr.stdOutContained('Executing Script on Kudu. Command: echo hello'), 'Should have printed: Executing Script on Kudu. Command: echo hello');
    assert(tr.stdOutContained('KUDU RUN COMMAND PASSED'), 'Should have printed: KUDU RUN COMMAND PASSED');
    assert(tr.stdOutContained('Executing Script on Kudu. Command: exit /b 1'), 'Should have printed: Executing Script on Kudu. Command: exit /b 1');
}
function extractZIP(tr) {
    assert(tr.stdOutContained('KUDU ZIP API PASSED'), 'Should have printed: KUDU ZIP API PASSED');
    assert(tr.stdOutContained("Error: Failed to deploy web package. Error: null (CODE: 501)"), 'Should have printed: Error: Failed to deploy web package. Error: null (CODE: 501)');
}
function deleteFile(tr) {
    assert(tr.stdOutContained('KUDU DELETE FILE PASSED'), 'Should have printed: KUDU DELETE FILE PASSED');
    assert(tr.stdOutContained("Error: Failed to delete file 'site/wwwroot/web.config' from Kudu. Error: null (CODE: 501)"), 'Should have printed: Error: Failed to delete file site/wwwroot/web.config from Kudu. Error: null (CODE: 501)');
}
function zipDeploy(tr) {
    assert(tr.stdOutContained('KUDU ZIP DEPLOY PASSED. ID: ZIP_DEPLOY_PASSED_ID. STATUS: 4.'), 'Should have printed: KUDU ZIP DEPLOY PASSED. ID: ZIP_DEPLOY_PASSED_ID. STATUS: 4.');
    assert(tr.stdOutContained('KUDU ZIP DEPLOY FAILED. ID: ZIP_DEPLOY_FAILED_ID. STATUS: 3.'), 'Should have printed: KUDU ZIP DEPLOY FAILED. ID: ZIP_DEPLOY_FAILED_ID. STATUS: 3.');
}
