export declare function KuduLogSanitizerTests(): void;
