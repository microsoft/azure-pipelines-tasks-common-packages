"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const mock_utils_1 = require("./mock_utils");
const tl = require("azure-pipelines-task-lib/task");
const azure_arm_resource_1 = require("../azure-arm-resource");
var endpoint = (0, mock_utils_1.getMockEndpoint)();
(0, mock_utils_1.mockAzureARMResourcesTests)();
class ResourcesTests {
    static getResources(resourceType, resourceName) {
        return __awaiter(this, void 0, void 0, function* () {
            var resources = new azure_arm_resource_1.Resources(endpoint);
            try {
                var result = yield resources.getResources(resourceType, resourceName);
                console.log('ResourcesTests - getResources : ' + result.length);
            }
            catch (error) {
                console.log(error);
                tl.setResult(tl.TaskResult.Failed, 'ResourcesTests.getResources() should have passed but failed');
            }
        });
    }
}
function RUNTESTS() {
    return __awaiter(this, void 0, void 0, function* () {
        yield ResourcesTests.getResources('Microsoft.Web/sites', 'göm-mig-från-omvärlden');
    });
}
RUNTESTS();
