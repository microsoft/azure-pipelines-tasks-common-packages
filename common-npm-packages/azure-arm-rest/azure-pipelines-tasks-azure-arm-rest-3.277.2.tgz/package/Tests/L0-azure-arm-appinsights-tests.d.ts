export declare function ApplicationInsightsTests(defaultTimeout?: number): void;
