export declare function KuduServiceTests(defaultTimeout?: number): void;
