"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AzureCliUtilityTests = void 0;
const assert = require("assert");
const path_1 = require("path");
const mock_test_1 = require("azure-pipelines-task-lib/mock-test");
function AzureCliUtilityTests() {
    it('azure-arm-rest azure-cli-utility check retry count', (done) => {
        process.env['SYSTEM_DEBUG'] = 'true';
        const tr = new mock_test_1.MockTestRunner((0, path_1.join)(__dirname, 'azure-cli-utility-tests.js'));
        tr.runAsync()
            .then(() => {
            assert(tr.stdOutContained('Retrying OIDC token fetch. Retries left: 2'));
            assert(tr.stdOutContained('Retrying OIDC token fetch. Retries left: 0'));
            assert(tr.stdOutContained('Error while trying to get OIDC token: Error: 1'));
            assert(tr.stdOutContained('Error while trying to get OIDC token: Error: 2'));
            assert(tr.stdOutContained('Error while trying to get OIDC token: Error: 3'));
            done();
        })
            .catch((error) => {
            console.log(tr.stdout);
            console.log(tr.stderr);
            done(error);
        });
    });
}
exports.AzureCliUtilityTests = AzureCliUtilityTests;
