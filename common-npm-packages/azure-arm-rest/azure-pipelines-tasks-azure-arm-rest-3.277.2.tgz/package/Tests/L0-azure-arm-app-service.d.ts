export declare function AzureAppServiceMockTests(defaultTimeout?: number): void;
