"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.OpenSSLCheck = void 0;
const assert = require("assert");
const path_1 = require("path");
const mock_test_1 = require("azure-pipelines-task-lib/mock-test");
const fs_1 = require("fs");
function OpenSSLCheck() {
    if (process.platform !== 'win32') {
        console.log('Skipping OpenSSL tests on non-Windows platform');
        return;
    }
    [{
            openSSLVersion: '3.4.2',
            featureFlagValue: false
        }, {
            openSSLVersion: '3.5.7',
            featureFlagValue: true
        }].forEach(({ openSSLVersion, featureFlagValue }) => {
        it(`azure-arm-rest check openssl path openssl${openSSLVersion}`, (done) => {
            process.env['SYSTEM_DEBUG'] = 'true';
            process.env['DISTRIBUTEDTASK_TASKS_USELATESTOPENSSLINAZUREARMREST'] = featureFlagValue.toString();
            const tr = new mock_test_1.MockTestRunner((0, path_1.join)(__dirname, 'azure-cli-openssl-tests.js'));
            const openSSLRelativePath = (0, path_1.join)(`openssl${openSSLVersion}`, 'openssl.exe');
            const openSSLAbsolutePath = (0, path_1.join)(__dirname, '..', openSSLRelativePath);
            tr.runAsync()
                .then(() => {
                assert(tr.stdOutContained(openSSLRelativePath), 'Should have printed: openssl path');
                assert(tr.succeeded, 'Test runner should have succeeded');
                assert((0, fs_1.existsSync)(openSSLAbsolutePath), `Should have existed openssl${openSSLVersion} at ${openSSLAbsolutePath}`);
                done();
            })
                .catch((error) => {
                console.log(tr.stdout);
                console.log(tr.stderr);
                done(error);
            });
        });
    });
}
exports.OpenSSLCheck = OpenSSLCheck;
