"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AzureCliUtilityTests = void 0;
const azCliUtility_1 = require("../azCliUtility");
class TaskApiNull {
    createOidcToken() {
        return __awaiter(this, void 0, void 0, function* () {
            // Simulate a failure to fetch OIDC token
            return null;
        });
    }
}
class WebApiMockNull {
    getTaskApi() {
        return new Promise((resolve) => {
            resolve(new TaskApiNull());
        });
    }
}
// Polyfill AggregateError if not available in the environment
const AggregateErrorGlobal = (typeof globalThis.AggregateError !== "undefined")
    ? globalThis.AggregateError
    : class AggregateError extends Error {
        constructor(errors) {
            super("AggregateError: " + errors.map(e => e.message).join(", "));
            this.name = "AggregateError";
            this.errors = errors;
        }
    };
class TaskApiThrowing {
    createOidcToken() {
        return __awaiter(this, void 0, void 0, function* () {
            throw new AggregateErrorGlobal([new Error('1'), new Error('2'), new Error('3')]);
        });
    }
}
class WebApiMockThrowing {
    getTaskApi() {
        return new Promise((resolve) => {
            resolve(new TaskApiThrowing());
        });
    }
}
class AzureCliUtilityTests {
    static initOIDCTokenTestRetryMechanism() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                yield (0, azCliUtility_1.initOIDCToken2)(new WebApiMockNull(), 'https://dev.azure.com/organization', 'project', 'pipeline', 'job', 'task', 0, 0);
            }
            catch (error) {
                //
            }
        });
    }
    static initOIDCTokenTestAggregateError() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                yield (0, azCliUtility_1.initOIDCToken2)(new WebApiMockThrowing(), 'https://dev.azure.com/organization', 'project', 'pipeline', 'job', 'task', 3, 0);
            }
            catch (error) {
                //
            }
        });
    }
}
exports.AzureCliUtilityTests = AzureCliUtilityTests;
function RUNTESTS() {
    return __awaiter(this, void 0, void 0, function* () {
        yield AzureCliUtilityTests.initOIDCTokenTestRetryMechanism();
        yield AzureCliUtilityTests.initOIDCTokenTestAggregateError();
    });
}
RUNTESTS();
