"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ApplicationInsightsWebTestsTests = void 0;
const mock_utils_1 = require("./mock_utils");
const tl = require("azure-pipelines-task-lib");
const azure_arm_appinsights_webtests_1 = require("../azure-arm-appinsights-webtests");
var endpoint = (0, mock_utils_1.getMockEndpoint)();
// Mock all calls for Application Insights web tests
(0, mock_utils_1.mockAzureARMAppInsightsWebTests)();
class ApplicationInsightsWebTestsTests {
    static list() {
        return __awaiter(this, void 0, void 0, function* () {
            let appInsightsWebTests = new azure_arm_appinsights_webtests_1.ApplicationInsightsWebTests(endpoint, "MOCK_RESOURCE_GROUP_NAME");
            try {
                console.log(`WEB TEST COUNT: ${(yield appInsightsWebTests.list()).length}`);
            }
            catch (error) {
                console.log(error);
                tl.setResult(tl.TaskResult.Failed, 'ApplicationInsightsWebTestsTests.get() should have passed but failed');
            }
        });
    }
    static create() {
        return __awaiter(this, void 0, void 0, function* () {
            let appInsightsWebTests = new azure_arm_appinsights_webtests_1.ApplicationInsightsWebTests(endpoint, "MOCK_RESOURCE_GROUP_NAME");
            try {
                yield appInsightsWebTests.create({
                    type: '',
                    location: '',
                    tags: {},
                    name: 'VSTS_MOCK_TEST',
                    id: "hidden-link:/subscriptions/MOCK_SUBSCRIPTION_ID/resourceGroups/MOCK_RESOURCE_GROUP_NAME/providers/microsoft.insights/components/MOCK_APP_INSIGHTS_1".toLowerCase()
                });
            }
            catch (error) {
                console.log(error);
                tl.setResult(tl.TaskResult.Failed, 'ApplicationInsightsWebTestsTests.create() should have passed but failed');
            }
            try {
                yield appInsightsWebTests.create({
                    type: '',
                    location: '',
                    tags: {},
                    name: 'VSTS_MOCK_TEST_FAIL',
                    id: "hidden-link:/subscriptions/MOCK_SUBSCRIPTION_ID/resourceGroups/MOCK_RESOURCE_GROUP_NAME/providers/microsoft.insights/components/MOCK_APP_INSIGHTS_FAIL".toLowerCase()
                });
                tl.setResult(tl.TaskResult.Failed, 'ApplicationInsightsWebTestsTests.create() should have failed but passed');
            }
            catch (error) {
                tl.error(error);
            }
        });
    }
}
exports.ApplicationInsightsWebTestsTests = ApplicationInsightsWebTestsTests;
ApplicationInsightsWebTestsTests.list();
ApplicationInsightsWebTestsTests.create();
