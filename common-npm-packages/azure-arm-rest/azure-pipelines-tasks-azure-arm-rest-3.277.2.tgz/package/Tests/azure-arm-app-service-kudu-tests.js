"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.KuduTests = void 0;
const azure_arm_app_service_kudu_1 = require("../azure-arm-app-service-kudu");
const tl = require("azure-pipelines-task-lib");
const mock_utils_1 = require("./mock_utils");
const path = require("path");
(0, mock_utils_1.mockKuduServiceTests)();
class KuduTests {
    static updateDeployment() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                var kudu = new azure_arm_app_service_kudu_1.Kudu('http://MOCK_SCM_WEBSITE', 'Bearer MOCK_SCM_TOKEN');
                yield kudu.updateDeployment({ id: 'MOCK_DEPLOYMENT_ID', type: 'Deployment' });
            }
            catch (error) {
                tl.error(error);
                tl.setResult(tl.TaskResult.Failed, 'KuduTests.updateDeployment() should have passed but failed');
            }
            try {
                var kudu = new azure_arm_app_service_kudu_1.Kudu('http://FAIL_MOCK_SCM_WEBSITE', 'Bearer MOCK_SCM_TOKEN');
                yield kudu.updateDeployment({ id: 'MOCK_DEPLOYMENT_ID', type: 'Deployment' });
                tl.setResult(tl.TaskResult.Failed, 'KuduTests.updateDeployment() should have failed but passed');
            }
            catch (error) {
                tl.error(error);
            }
        });
    }
    static getContinuousJobs() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                var kudu = new azure_arm_app_service_kudu_1.Kudu('http://MOCK_SCM_WEBSITE', 'Bearer MOCK_SCM_TOKEN');
                console.log(`MOCK KUDU CONTINUOUS JOBS COUNT: ${(yield kudu.getContinuousJobs()).length}`);
            }
            catch (error) {
                tl.error(error);
                tl.setResult(tl.TaskResult.Failed, 'KuduTests.getContinuousJobs() should have passed but failed');
            }
            try {
                var kudu = new azure_arm_app_service_kudu_1.Kudu('http://FAIL_MOCK_SCM_WEBSITE', 'Bearer MOCK_SCM_TOKEN');
                yield kudu.getContinuousJobs();
                tl.setResult(tl.TaskResult.Failed, 'KuduTests.getContinuousJobs() should have failed but passed');
            }
            catch (error) {
                tl.error(error);
            }
        });
    }
    static startContinuousWebJob() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                var kudu = new azure_arm_app_service_kudu_1.Kudu('http://MOCK_SCM_WEBSITE', 'Bearer MOCK_SCM_TOKEN');
                yield kudu.startContinuousWebJob('MOCK_JOB_NAME');
            }
            catch (error) {
                tl.error(error);
                tl.setResult(tl.TaskResult.Failed, 'KuduTests.startContinuousWebJob() should have passed but failed');
            }
            try {
                var kudu = new azure_arm_app_service_kudu_1.Kudu('http://FAIL_MOCK_SCM_WEBSITE', 'Bearer MOCK_SCM_TOKEN');
                yield kudu.startContinuousWebJob('MOCK_JOB_NAME');
                tl.setResult(tl.TaskResult.Failed, 'KuduTests.startContinuousWebJob() should have failed but passed');
            }
            catch (error) {
                tl.error(error);
            }
        });
    }
    static stopContinuousWebJob() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                var kudu = new azure_arm_app_service_kudu_1.Kudu('http://MOCK_SCM_WEBSITE', 'Bearer MOCK_SCM_TOKEN');
                yield kudu.stopContinuousWebJob('MOCK_JOB_NAME');
            }
            catch (error) {
                tl.error(error);
                tl.setResult(tl.TaskResult.Failed, 'KuduTests.stopContinuousWebJob() should have passed but failed');
            }
            try {
                var kudu = new azure_arm_app_service_kudu_1.Kudu('http://FAIL_MOCK_SCM_WEBSITE', 'Bearer MOCK_SCM_TOKEN');
                yield kudu.stopContinuousWebJob('MOCK_JOB_NAME');
                tl.setResult(tl.TaskResult.Failed, 'KuduTests.stopContinuousWebJob() should have failed but passed');
            }
            catch (error) {
                tl.error(error);
            }
        });
    }
    static installSiteExtension() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                var kudu = new azure_arm_app_service_kudu_1.Kudu('http://MOCK_SCM_WEBSITE', 'Bearer MOCK_SCM_TOKEN');
                yield kudu.installSiteExtension('MOCK_EXTENSION');
            }
            catch (error) {
                tl.error(error);
                tl.setResult(tl.TaskResult.Failed, 'KuduTests.installSiteExtension() should have passed but failed');
            }
            try {
                var kudu = new azure_arm_app_service_kudu_1.Kudu('http://FAIL_MOCK_SCM_WEBSITE', 'Bearer MOCK_SCM_TOKEN');
                yield kudu.installSiteExtension('MOCK_EXTENSION');
                tl.setResult(tl.TaskResult.Failed, 'KuduTests.installSiteExtension() should have failed but passed');
            }
            catch (error) {
                tl.error(error);
            }
        });
    }
    static installSiteExtensionWithVersion() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                var kudu = new azure_arm_app_service_kudu_1.Kudu('http://MOCK_SCM_WEBSITE', 'Bearer MOCK_SCM_TOKEN');
                yield kudu.installSiteExtensionWithVersion('MOCK_EXTENSION', '1.0.0');
                console.log('KUDU INSTALL SITE EXTENSION WITH VERSION PASSED');
            }
            catch (error) {
                tl.error(error);
                tl.setResult(tl.TaskResult.Failed, 'KuduTests.installSiteExtensionWithVersion() should have passed but failed');
            }
            try {
                var kudu = new azure_arm_app_service_kudu_1.Kudu('http://FAIL_MOCK_SCM_WEBSITE', 'Bearer MOCK_SCM_TOKEN');
                yield kudu.installSiteExtensionWithVersion('MOCK_EXTENSION', '1.0.0');
                tl.setResult(tl.TaskResult.Failed, 'KuduTests.installSiteExtensionWithVersion() should have failed but passed');
            }
            catch (error) {
                tl.error(error);
            }
        });
    }
    static getSiteExtensions() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                var kudu = new azure_arm_app_service_kudu_1.Kudu('http://MOCK_SCM_WEBSITE', 'Bearer MOCK_SCM_TOKEN');
                console.log(`MOCK KUDU SITE EXTENSIONS COUNT: ${(yield kudu.getSiteExtensions()).length}`);
            }
            catch (error) {
                tl.error(error);
                tl.setResult(tl.TaskResult.Failed, 'KuduTests.getSiteExtensions() should have passed but failed');
            }
            try {
                var kudu = new azure_arm_app_service_kudu_1.Kudu('http://FAIL_MOCK_SCM_WEBSITE', 'Bearer MOCK_SCM_TOKEN');
                yield kudu.getSiteExtensions();
                tl.setResult(tl.TaskResult.Failed, 'KuduTests.getSiteExtensions() should have failed but passed');
            }
            catch (error) {
                tl.error(error);
            }
        });
    }
    static getAllSiteExtensions() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                var kudu = new azure_arm_app_service_kudu_1.Kudu('http://MOCK_SCM_WEBSITE', 'Bearer MOCK_SCM_TOKEN');
                console.log(`MOCK KUDU SITE EXTENSIONS COUNT: ${(yield kudu.getAllSiteExtensions()).length}`);
            }
            catch (error) {
                tl.error(error);
                tl.setResult(tl.TaskResult.Failed, 'KuduTests.getAllSiteExtensions() should have passed but failed');
            }
            try {
                var kudu = new azure_arm_app_service_kudu_1.Kudu('http://FAIL_MOCK_SCM_WEBSITE', 'Bearer MOCK_SCM_TOKEN');
                yield kudu.getAllSiteExtensions();
                tl.setResult(tl.TaskResult.Failed, 'KuduTests.getAllSiteExtensions() should have failed but passed');
            }
            catch (error) {
                tl.error(error);
            }
        });
    }
    static getProcess() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                var kudu = new azure_arm_app_service_kudu_1.Kudu('http://MOCK_SCM_WEBSITE', 'Bearer MOCK_SCM_TOKEN');
                console.log(`MOCK KUDU PROCESS ID: ${(yield kudu.getProcess(0)).id}`);
            }
            catch (error) {
                tl.error(error);
                tl.setResult(tl.TaskResult.Failed, 'KuduTests.getProcess() should have passed but failed');
            }
        });
    }
    static killProcess() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                var kudu = new azure_arm_app_service_kudu_1.Kudu('http://MOCK_SCM_WEBSITE', 'Bearer MOCK_SCM_TOKEN');
                yield kudu.killProcess(0);
                console.log('KILLED PROCESS 0');
            }
            catch (error) {
                tl.error(error);
                tl.setResult(tl.TaskResult.Failed, 'KuduTests.killProcess() should have passed but failed');
            }
        });
    }
    static getAppSettings() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                var kudu = new azure_arm_app_service_kudu_1.Kudu('http://MOCK_SCM_WEBSITE', 'Bearer MOCK_SCM_TOKEN');
                var appSettings = yield kudu.getAppSettings();
                console.log(`KUDU APP SETTINGS ${JSON.stringify(appSettings)}`);
            }
            catch (error) {
                tl.error(error);
                tl.setResult(tl.TaskResult.Failed, 'KuduTests.getAppSettings() should have passed but failed');
            }
            try {
                var kudu = new azure_arm_app_service_kudu_1.Kudu('http://FAIL_MOCK_SCM_WEBSITE', 'Bearer MOCK_SCM_TOKEN');
                yield kudu.getAppSettings();
                tl.setResult(tl.TaskResult.Failed, 'KuduTests.getAppSettings() should have failed but passed');
            }
            catch (error) {
                tl.error(error);
            }
        });
    }
    static listDir() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                var kudu = new azure_arm_app_service_kudu_1.Kudu('http://MOCK_SCM_WEBSITE', 'Bearer MOCK_SCM_TOKEN');
                var listDir = yield kudu.listDir('/site/wwwroot');
                console.log(`KUDU LIST DIR ${JSON.stringify(listDir)}`);
            }
            catch (error) {
                tl.error(error);
                tl.setResult(tl.TaskResult.Failed, 'KuduTests.listDir() should have passed but failed');
            }
            try {
                var kudu = new azure_arm_app_service_kudu_1.Kudu('http://FAIL_MOCK_SCM_WEBSITE', 'Bearer MOCK_SCM_TOKEN');
                yield kudu.listDir('/site/wwwroot');
                tl.setResult(tl.TaskResult.Failed, 'KuduTests.listDir() should have failed but passed');
            }
            catch (error) {
                tl.error(error);
            }
        });
    }
    static getFileContent() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                var kudu = new azure_arm_app_service_kudu_1.Kudu('http://MOCK_SCM_WEBSITE', 'Bearer MOCK_SCM_TOKEN');
                var fileContent = yield kudu.getFileContent('/site/wwwroot', 'hello.txt');
                console.log(`KUDU FILE CONTENT ${fileContent}`);
            }
            catch (error) {
                tl.error(error);
                tl.setResult(tl.TaskResult.Failed, 'KuduTests.getFileContent() should have passed but failed');
            }
            try {
                var kudu = new azure_arm_app_service_kudu_1.Kudu('http://MOCK_SCM_WEBSITE', 'Bearer MOCK_SCM_TOKEN');
                var fileContent = yield kudu.getFileContent('/site/wwwroot', '404.txt');
                if (fileContent == null) {
                    console.log('KUDU FILE CONTENT 404 - PASSED');
                }
                else {
                    console.log('KUDU FILE CONTENT 404 - FAILED');
                }
            }
            catch (error) {
                tl.error(error);
                tl.setResult(tl.TaskResult.Failed, 'KuduTests.getFileContent() should have passed but failed');
            }
            try {
                var kudu = new azure_arm_app_service_kudu_1.Kudu('http://FAIL_MOCK_SCM_WEBSITE', 'Bearer MOCK_SCM_TOKEN');
                yield kudu.getFileContent('/site/wwwroot', 'web.config');
                tl.setResult(tl.TaskResult.Failed, 'KuduTests.getFileContent() should have failed but passed');
            }
            catch (error) {
                tl.error(error);
            }
        });
    }
    static uploadFile() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                var kudu = new azure_arm_app_service_kudu_1.Kudu('http://MOCK_SCM_WEBSITE', 'Bearer MOCK_SCM_TOKEN');
                yield kudu.uploadFile('/site/wwwroot', 'hello.txt', path.join(__dirname, 'package.json'));
                console.log('KUDU FILE UPLOAD HELLO.TXT PASSED');
            }
            catch (error) {
                tl.error(error);
                tl.setResult(tl.TaskResult.Failed, 'KuduTests.uploadFile() should have passed but failed');
            }
            try {
                var kudu = new azure_arm_app_service_kudu_1.Kudu('http://FAIL_MOCK_SCM_WEBSITE', 'Bearer MOCK_SCM_TOKEN');
                yield kudu.uploadFile('/site/wwwroot', 'web.config', path.join(__dirname, 'package.json'));
                tl.setResult(tl.TaskResult.Failed, 'KuduTests.uploadFile() should have failed but passed');
            }
            catch (error) {
                tl.error(error);
            }
        });
    }
    static createPath() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                var kudu = new azure_arm_app_service_kudu_1.Kudu('http://MOCK_SCM_WEBSITE', 'Bearer MOCK_SCM_TOKEN');
                yield kudu.createPath('/site/wwwroot');
                console.log('KUDU CREATE PATH SITE/WWWROOT PASSED');
            }
            catch (error) {
                tl.error(error);
                tl.setResult(tl.TaskResult.Failed, 'KuduTests.createPath() should have passed but failed');
            }
            try {
                var kudu = new azure_arm_app_service_kudu_1.Kudu('http://FAIL_MOCK_SCM_WEBSITE', 'Bearer MOCK_SCM_TOKEN');
                yield kudu.createPath('/site/wwwroot');
                tl.setResult(tl.TaskResult.Failed, 'KuduTests.createPath() should have failed but passed');
            }
            catch (error) {
                tl.error(error);
            }
        });
    }
    static runCommand() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                var kudu = new azure_arm_app_service_kudu_1.Kudu('http://MOCK_SCM_WEBSITE', 'Bearer MOCK_SCM_TOKEN');
                yield kudu.runCommand('site\\wwwroot', 'echo hello');
                console.log('KUDU RUN COMMAND PASSED');
            }
            catch (error) {
                tl.error(error);
                tl.setResult(tl.TaskResult.Failed, 'KuduTests.runCommand() should have passed but failed');
            }
            try {
                var kudu = new azure_arm_app_service_kudu_1.Kudu('http://FAIL_MOCK_SCM_WEBSITE', 'Bearer MOCK_SCM_TOKEN');
                yield kudu.runCommand('site\\wwwroot', 'exit /b 1');
                tl.setResult(tl.TaskResult.Failed, 'KuduTests.runCommand() should have failed but passed');
            }
            catch (error) {
                tl.error(error);
            }
        });
    }
    static extractZIP() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                var kudu = new azure_arm_app_service_kudu_1.Kudu('http://MOCK_SCM_WEBSITE', 'Bearer MOCK_SCM_TOKEN');
                var listDir = yield kudu.extractZIP(path.join(__dirname, 'package.json'), '/site/wwwroot');
                console.log('KUDU ZIP API PASSED');
            }
            catch (error) {
                tl.error(error);
                tl.setResult(tl.TaskResult.Failed, 'KuduTests.extractZIP() should have passed but failed');
            }
            try {
                var kudu = new azure_arm_app_service_kudu_1.Kudu('http://FAIL_MOCK_SCM_WEBSITE', 'Bearer MOCK_SCM_TOKEN');
                yield kudu.extractZIP(path.join(__dirname, 'package.json'), '/site/wwwroot');
                tl.setResult(tl.TaskResult.Failed, 'KuduTests.extractZIP() should have failed but passed');
            }
            catch (error) {
                tl.error(error);
            }
        });
    }
    static zipDeploy() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                let kudu = new azure_arm_app_service_kudu_1.Kudu('http://MOCK_SCM_WEBSITE', 'Bearer MOCK_SCM_TOKEN');
                let deploymentDetails = yield kudu.zipDeploy(path.join(__dirname, 'package.json'), ['deployer=VSTS_ZIP_DEPLOY']);
                console.log(`KUDU ZIP DEPLOY PASSED. ID: ${deploymentDetails.id}. STATUS: ${deploymentDetails.status}.`);
            }
            catch (error) {
                tl.error(error);
                tl.setResult(tl.TaskResult.Failed, 'KuduTests.zipDeploy() should have passed but failed');
            }
            try {
                let kudu = new azure_arm_app_service_kudu_1.Kudu('http://FAIL_MOCK_SCM_WEBSITE', 'Bearer MOCK_SCM_TOKEN');
                let deploymentDetails = yield kudu.zipDeploy(path.join(__dirname, 'package.json'), ['deployer=VSTS_ZIP_DEPLOY']);
                console.log(`KUDU ZIP DEPLOY FAILED. ID: ${deploymentDetails.id}. STATUS: ${deploymentDetails.status}.`);
            }
            catch (error) {
                tl.error(error);
            }
        });
    }
    static deleteFile() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                var kudu = new azure_arm_app_service_kudu_1.Kudu('http://MOCK_SCM_WEBSITE', 'Bearer MOCK_SCM_TOKEN');
                yield kudu.deleteFile('/site/wwwroot', 'hello.txt');
                console.log(`KUDU DELETE FILE PASSED`);
            }
            catch (error) {
                tl.error(error);
                tl.setResult(tl.TaskResult.Failed, 'KuduTests.deleteFile() should have passed but failed');
            }
            try {
                var kudu = new azure_arm_app_service_kudu_1.Kudu('http://FAIL_MOCK_SCM_WEBSITE', 'Bearer MOCK_SCM_TOKEN');
                yield kudu.deleteFile('/site/wwwroot', 'web.config');
                tl.setResult(tl.TaskResult.Failed, 'KuduTests.deleteFile() should have failed but passed');
            }
            catch (error) {
                tl.error(error);
            }
        });
    }
}
exports.KuduTests = KuduTests;
function RUNTESTS() {
    return __awaiter(this, void 0, void 0, function* () {
        yield KuduTests.updateDeployment();
        yield KuduTests.getContinuousJobs();
        yield KuduTests.startContinuousWebJob();
        yield KuduTests.stopContinuousWebJob();
        yield KuduTests.installSiteExtension();
        yield KuduTests.installSiteExtensionWithVersion();
        yield KuduTests.getSiteExtensions();
        yield KuduTests.getAllSiteExtensions();
        yield KuduTests.getProcess();
        yield KuduTests.killProcess();
        yield KuduTests.getAppSettings();
        yield KuduTests.listDir();
        yield KuduTests.getFileContent();
        yield KuduTests.uploadFile();
        yield KuduTests.createPath();
        yield KuduTests.runCommand();
        yield KuduTests.extractZIP();
        yield KuduTests.deleteFile();
        yield KuduTests.zipDeploy();
    });
}
RUNTESTS();
