"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const azure_arm_app_service_1 = require("../azure-arm-app-service");
const azureAppServiceUtility_1 = require("../azureAppServiceUtility");
const mock_utils_1 = require("./mock_utils");
const tl = require("azure-pipelines-task-lib/task");
var endpoint = (0, mock_utils_1.getMockEndpoint)();
(0, mock_utils_1.mockAzureAppServiceTests)();
(0, mock_utils_1.mockAzureAppServiceUtilityTests)();
class AzureAppServiceUtilityTests {
    static getKuduServiceWithoutWarmupInstanceId() {
        return __awaiter(this, void 0, void 0, function* () {
            var appService = new azure_arm_app_service_1.AzureAppService(endpoint, "MOCK_RESOURCE_GROUP_NAME", "MOCK_APP_SERVICE_NAME");
            var appServiceUtility = new azureAppServiceUtility_1.AzureAppServiceUtility(appService);
            try {
                var kudu = yield appServiceUtility.getKuduService();
                console.log('KUDU SERVICE CREATED WITHOUT WARMUP INSTANCE ID');
                console.log('KUDU SCM URI: ' + (kudu ? 'VALID' : 'INVALID'));
            }
            catch (error) {
                console.log(error);
                tl.setResult(tl.TaskResult.Failed, 'AzureAppServiceUtilityTests.getKuduServiceWithoutWarmupInstanceId() should have passed but failed');
            }
        });
    }
    static getKuduServiceWithWarmupInstanceId() {
        return __awaiter(this, void 0, void 0, function* () {
            var appService = new azure_arm_app_service_1.AzureAppService(endpoint, "MOCK_RESOURCE_GROUP_NAME", "MOCK_APP_SERVICE_NAME");
            var appServiceUtility = new azureAppServiceUtility_1.AzureAppServiceUtility(appService);
            try {
                var kudu = yield appServiceUtility.getKuduService("MOCK_INSTANCE_ID_123");
                console.log('KUDU SERVICE CREATED WITH WARMUP INSTANCE ID: MOCK_INSTANCE_ID_123');
                console.log('KUDU SCM URI WITH COOKIE: ' + (kudu ? 'VALID' : 'INVALID'));
            }
            catch (error) {
                console.log(error);
                tl.setResult(tl.TaskResult.Failed, 'AzureAppServiceUtilityTests.getKuduServiceWithWarmupInstanceId() should have passed but failed');
            }
        });
    }
    static getKuduServiceWithEmptyScmUri() {
        return __awaiter(this, void 0, void 0, function* () {
            var appService = new azure_arm_app_service_1.AzureAppService(endpoint, "MOCK_RESOURCE_GROUP_NAME", "MOCK_APP_SERVICE_NAME_NO_SCM");
            var appServiceUtility = new azureAppServiceUtility_1.AzureAppServiceUtility(appService);
            try {
                yield appServiceUtility.getKuduService();
                tl.setResult(tl.TaskResult.Failed, 'AzureAppServiceUtilityTests.getKuduServiceWithEmptyScmUri() should have failed but passed');
            }
            catch (error) {
                console.log('KUDU SERVICE FAILED AS EXPECTED FOR EMPTY SCM URI');
                console.log(error);
            }
        });
    }
    static getAppserviceInstances() {
        return __awaiter(this, void 0, void 0, function* () {
            var appService = new azure_arm_app_service_1.AzureAppService(endpoint, "MOCK_RESOURCE_GROUP_NAME", "MOCK_APP_SERVICE_NAME");
            var appServiceUtility = new azureAppServiceUtility_1.AzureAppServiceUtility(appService);
            try {
                var instances = yield appServiceUtility.getAppserviceInstances();
                console.log('APP SERVICE INSTANCES COUNT: ' + instances.value.length);
                console.log('APP SERVICE INSTANCE NAMES: ' + instances.value.map((i) => i.name).join(', '));
            }
            catch (error) {
                console.log(error);
                tl.setResult(tl.TaskResult.Failed, 'AzureAppServiceUtilityTests.getAppserviceInstances() should have passed but failed');
            }
        });
    }
    static getAppserviceInstancesForSlot() {
        return __awaiter(this, void 0, void 0, function* () {
            var appServiceSlot = new azure_arm_app_service_1.AzureAppService(endpoint, "MOCK_RESOURCE_GROUP_NAME", "MOCK_APP_SERVICE_NAME", "MOCK_SLOT_NAME");
            var appServiceUtility = new azureAppServiceUtility_1.AzureAppServiceUtility(appServiceSlot);
            try {
                yield appServiceUtility.getAppserviceInstances();
                tl.setResult(tl.TaskResult.Failed, 'AzureAppServiceUtilityTests.getAppserviceInstancesForSlot() should have failed but passed');
            }
            catch (error) {
                console.log('GET INSTANCES FOR SLOT FAILED AS EXPECTED');
                console.log(error);
            }
        });
    }
    static getAppserviceInstancesEmpty() {
        return __awaiter(this, void 0, void 0, function* () {
            var appService = new azure_arm_app_service_1.AzureAppService(endpoint, "MOCK_RESOURCE_GROUP_NAME", "MOCK_APP_SERVICE_NAME_NO_INSTANCES");
            var appServiceUtility = new azureAppServiceUtility_1.AzureAppServiceUtility(appService);
            try {
                var instances = yield appServiceUtility.getAppserviceInstances();
                console.log('APP SERVICE INSTANCES EMPTY COUNT: ' + instances.value.length);
            }
            catch (error) {
                console.log(error);
                tl.setResult(tl.TaskResult.Failed, 'AzureAppServiceUtilityTests.getAppserviceInstancesEmpty() should have passed but failed');
            }
        });
    }
}
function RUNTESTS() {
    return __awaiter(this, void 0, void 0, function* () {
        yield AzureAppServiceUtilityTests.getKuduServiceWithoutWarmupInstanceId();
        yield AzureAppServiceUtilityTests.getKuduServiceWithWarmupInstanceId();
        yield AzureAppServiceUtilityTests.getKuduServiceWithEmptyScmUri();
        yield AzureAppServiceUtilityTests.getAppserviceInstances();
        yield AzureAppServiceUtilityTests.getAppserviceInstancesForSlot();
        yield AzureAppServiceUtilityTests.getAppserviceInstancesEmpty();
    });
}
RUNTESTS();
