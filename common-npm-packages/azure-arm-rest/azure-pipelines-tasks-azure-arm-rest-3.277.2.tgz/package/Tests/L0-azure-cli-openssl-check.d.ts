export declare function OpenSSLCheck(): void;
