"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AzureAppServiceUtilityTests = void 0;
const assert = require("assert");
const ttm = __importStar(require("azure-pipelines-task-lib/mock-test"));
const path = __importStar(require("path"));
function AzureAppServiceUtilityTests(defaultTimeout = 2000) {
    it('azure-app-service-utility AzureAppServiceUtility', function (done) {
        this.timeout(defaultTimeout);
        let tp = path.join(__dirname, 'azure-app-service-utility-tests.js');
        let tr = new ttm.MockTestRunner(tp);
        let passed = true;
        tr.runAsync()
            .then(() => {
            assert(tr.succeeded, "azure-app-service-utility-tests should have passed but failed.");
            console.log("\tvalidating getKuduServiceWithoutWarmupInstanceId");
            getKuduServiceWithoutWarmupInstanceId(tr);
            console.log("\tvalidating getKuduServiceWithWarmupInstanceId");
            getKuduServiceWithWarmupInstanceId(tr);
            console.log("\tvalidating getKuduServiceWithEmptyScmUri");
            getKuduServiceWithEmptyScmUri(tr);
            console.log("\tvalidating getAppserviceInstances");
            getAppserviceInstances(tr);
            console.log("\tvalidating getAppserviceInstancesForSlot");
            getAppserviceInstancesForSlot(tr);
            console.log("\tvalidating getAppserviceInstancesEmpty");
            getAppserviceInstancesEmpty(tr);
            done();
        })
            .catch((error) => {
            passed = false;
            console.log(tr.stdout);
            console.log(tr.stderr);
            done(error);
        });
    });
}
exports.AzureAppServiceUtilityTests = AzureAppServiceUtilityTests;
function getKuduServiceWithoutWarmupInstanceId(tr) {
    assert(tr.stdOutContained('KUDU SERVICE CREATED WITHOUT WARMUP INSTANCE ID'), 'Should have printed: KUDU SERVICE CREATED WITHOUT WARMUP INSTANCE ID');
    assert(tr.stdOutContained('KUDU SCM URI: VALID'), 'Should have printed: KUDU SCM URI: VALID');
}
function getKuduServiceWithWarmupInstanceId(tr) {
    assert(tr.stdOutContained('KUDU SERVICE CREATED WITH WARMUP INSTANCE ID: MOCK_INSTANCE_ID_123'), 'Should have printed: KUDU SERVICE CREATED WITH WARMUP INSTANCE ID: MOCK_INSTANCE_ID_123');
    assert(tr.stdOutContained('KUDU SCM URI WITH COOKIE: VALID'), 'Should have printed: KUDU SCM URI WITH COOKIE: VALID');
}
function getKuduServiceWithEmptyScmUri(tr) {
    assert(tr.stdOutContained('KUDU SERVICE FAILED AS EXPECTED FOR EMPTY SCM URI'), 'Should have printed: KUDU SERVICE FAILED AS EXPECTED FOR EMPTY SCM URI');
}
function getAppserviceInstances(tr) {
    assert(tr.stdOutContained('APP SERVICE INSTANCES COUNT: 3'), 'Should have printed: APP SERVICE INSTANCES COUNT: 3');
    assert(tr.stdOutContained('APP SERVICE INSTANCE NAMES: instance-1, instance-2, instance-3'), 'Should have printed: APP SERVICE INSTANCE NAMES: instance-1, instance-2, instance-3');
}
function getAppserviceInstancesForSlot(tr) {
    assert(tr.stdOutContained('GET INSTANCES FOR SLOT FAILED AS EXPECTED'), 'Should have printed: GET INSTANCES FOR SLOT FAILED AS EXPECTED');
}
function getAppserviceInstancesEmpty(tr) {
    assert(tr.stdOutContained('APP SERVICE INSTANCES EMPTY COUNT: 0'), 'Should have printed: APP SERVICE INSTANCES EMPTY COUNT: 0');
}
