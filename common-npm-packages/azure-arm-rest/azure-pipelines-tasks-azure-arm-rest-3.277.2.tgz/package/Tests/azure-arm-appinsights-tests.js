"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AzureApplicationInsightsTests = void 0;
const azure_arm_appinsights_1 = require("../azure-arm-appinsights");
const mock_utils_1 = require("./mock_utils");
const tl = require("azure-pipelines-task-lib");
var endpoint = (0, mock_utils_1.getMockEndpoint)();
(0, mock_utils_1.mockAzureApplicationInsightsTests)();
class AzureApplicationInsightsTests {
    static get() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                let azureApplicationInsights = new azure_arm_appinsights_1.AzureApplicationInsights(endpoint, "MOCK_RESOURCE_GROUP_NAME", "MOCK_APP_INSIGHTS_NAME");
                let appInsights = yield azureApplicationInsights.get();
                console.log(`GET APP INSIGHTS RESOURCE ID MOCKED: ${appInsights.id}`);
            }
            catch (error) {
                console.log(error);
                tl.setResult(tl.TaskResult.Failed, 'AzureApplicationInsightsTests.get() should have passed but failed.');
            }
            try {
                let azureApplicationInsights = new azure_arm_appinsights_1.AzureApplicationInsights(endpoint, "MOCK_RESOURCE_GROUP_NAME", "FAIL_MOCK_APP_INSIGHTS_NAME");
                let appInsights = yield azureApplicationInsights.get();
                tl.setResult(tl.TaskResult.Failed, 'AzureApplicationInsightsTests.get() should have failed but passed.');
            }
            catch (error) {
                tl.error(error);
            }
        });
    }
    static update() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                let azureApplicationInsights = new azure_arm_appinsights_1.AzureApplicationInsights(endpoint, "MOCK_RESOURCE_GROUP_NAME", "MOCK_APP_INSIGHTS_NAME");
                let appInsights = yield azureApplicationInsights.get();
                yield azureApplicationInsights.update(appInsights);
                console.log(`UPDATE APP INSIGHTS RESOURCE ID MOCKED: ${appInsights.id}`);
            }
            catch (error) {
                console.log(error);
                tl.setResult(tl.TaskResult.Failed, 'AzureApplicationInsightsTests.update() should have passed but failed.');
            }
            try {
                let azureApplicationInsights = new azure_arm_appinsights_1.AzureApplicationInsights(endpoint, "MOCK_RESOURCE_GROUP_NAME", "MOCK_APP_INSIGHTS_NAME");
                let appInsights = yield azureApplicationInsights.get();
                let azureApplicationInsightsFail = new azure_arm_appinsights_1.AzureApplicationInsights(endpoint, "MOCK_RESOURCE_GROUP_NAME", "FAIL_MOCK_APP_INSIGHTS_NAME");
                appInsights = yield azureApplicationInsightsFail.update(appInsights);
                console.log(`UPDATE APP INSIGHTS RESOURCE ID MOCKED: ${appInsights.id}`);
                tl.setResult(tl.TaskResult.Failed, 'AzureApplicationInsightsTests.update() should have failed but passed.');
            }
            catch (error) {
                tl.error(error);
            }
        });
    }
}
exports.AzureApplicationInsightsTests = AzureApplicationInsightsTests;
AzureApplicationInsightsTests.get();
AzureApplicationInsightsTests.update();
