export declare function AzureCliUtilityTests(): void;
