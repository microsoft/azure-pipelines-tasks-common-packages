export declare class AzureCliUtilityTests {
    static initOIDCTokenTestRetryMechanism(): Promise<void>;
    static initOIDCTokenTestAggregateError(): Promise<void>;
}
