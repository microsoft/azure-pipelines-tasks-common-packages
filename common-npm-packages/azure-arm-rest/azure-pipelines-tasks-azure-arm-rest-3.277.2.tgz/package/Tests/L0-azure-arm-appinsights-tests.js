"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ApplicationInsightsTests = void 0;
const assert = require("assert");
const ttm = __importStar(require("azure-pipelines-task-lib/mock-test"));
const path = __importStar(require("path"));
function ApplicationInsightsTests(defaultTimeout = 6000) {
    it('azure-arm-appinsights AzureApplicationInsights', function (done) {
        this.timeout(defaultTimeout);
        let tp = path.join(__dirname, 'azure-arm-appinsights-tests.js');
        let tr = new ttm.MockTestRunner(tp);
        let passed = true;
        tr.runAsync()
            .then(() => {
            assert(tr.succeeded, "azure-arm-appinsights should have passed but failed.");
            console.log("\tvalidating get");
            get(tr);
            console.log("\tvalidating update");
            update(tr);
            done();
        })
            .catch((error) => {
            passed = false;
            console.log(tr.stdout);
            console.log(tr.stderr);
            done(error);
        });
    });
}
exports.ApplicationInsightsTests = ApplicationInsightsTests;
function get(tr) {
    assert(tr.stdOutContained('GET APP INSIGHTS RESOURCE ID MOCKED: subscriptions/MOCK_SUBSCRIPTION_ID/resourceGroups/MOCK_RESOURCE_GROUP_NAME/providers/microsoft.insights/components/MOCK_APP_INSIGHTS_NAME'), 'Should have printed: GET APP INSIGHTS RESOURCE ID MOCKED: subscriptions/MOCK_SUBSCRIPTION_ID/resourceGroups/MOCK_RESOURCE_GROUP_NAME/providers/microsoft.insights/components/MOCK_APP_INSIGHTS_NAME');
    assert(tr.stdOutContained("Failed to get Application Insights 'FAIL_MOCK_APP_INSIGHTS_NAME' Resource. Error: Internal Server error occured. (CODE: 501)"), 'Should have printed: Failed to get Application Insights FAIL_MOCK_APP_INSIGHTS_NAME Resource. Error: Internal Server error occured. (CODE: 501)');
}
function update(tr) {
    assert(tr.stdOutContained('UPDATE APP INSIGHTS RESOURCE ID MOCKED: subscriptions/MOCK_SUBSCRIPTION_ID/resourceGroups/MOCK_RESOURCE_GROUP_NAME/providers/microsoft.insights/components/MOCK_APP_INSIGHTS_NAME'), 'Should have printed: UPDATE APP INSIGHTS RESOURCE ID MOCKED: subscriptions/MOCK_SUBSCRIPTION_ID/resourceGroups/MOCK_RESOURCE_GROUP_NAME/providers/microsoft.insights/components/MOCK_APP_INSIGHTS_NAME');
    assert(tr.stdOutContained("Failed to update Application Insights 'FAIL_MOCK_APP_INSIGHTS_NAME' Resource. Error: Internal Server error occured. (CODE: 501)"), 'Should have printed: Failed to update Application Insights FAIL_MOCK_APP_INSIGHTS_NAME Resource. Error: Internal Server error occured. (CODE: 501)');
}
