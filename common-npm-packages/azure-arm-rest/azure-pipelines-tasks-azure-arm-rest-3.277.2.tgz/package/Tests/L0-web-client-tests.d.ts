export declare function WebClientTests(): void;
