"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ServicePrincipals = exports.GraphManagementClient = void 0;
const util = require("util");
const tl = require("azure-pipelines-task-lib/task");
const Q = require("q");
const azureServiceClient = require("./AzureServiceClient");
const azureServiceClientBase = require("./AzureServiceClientBase");
const webClient = require("./webClient");
class GraphManagementClient extends azureServiceClient.ServiceClient {
    constructor(credentials, baseUri, options) {
        super(credentials, null);
        const useMSAL = credentials.getUseMSAL();
        tl.debug(`MSAL - Graph - GraphManagementClient - useMSAL = ${useMSAL}`);
        this.apiVersion = useMSAL ? '' : '1.6';
        this.acceptLanguage = 'en-US';
        this.generateClientRequestId = true;
        if (!options)
            options = {};
        if (baseUri) {
            this.baseUri = baseUri;
        }
        else {
            this.baseUri = credentials.activeDirectoryResourceId;
        }
        if (options.acceptLanguage) {
            this.acceptLanguage = options.acceptLanguage;
        }
        if (options.longRunningOperationRetryTimeout) {
            this.longRunningOperationRetryTimeout = options.longRunningOperationRetryTimeout;
        }
        if (options.generateClientRequestId) {
            this.generateClientRequestId = options.generateClientRequestId;
        }
        this.servicePrincipals = new ServicePrincipals(this);
    }
    //Since there is no subscriptionId so keeping the check here and empty.
    validateInputs(subscriptionId) {
    }
}
exports.GraphManagementClient = GraphManagementClient;
class ServicePrincipals {
    constructor(graphClient) {
        this.client = graphClient;
    }
    GetServicePrincipal(options) {
        return __awaiter(this, void 0, void 0, function* () {
            var httpRequest = new webClient.WebRequest();
            httpRequest.method = 'GET';
            httpRequest.headers = this.client.setCustomHeaders(options);
            const clientCredentials = this.client.getCredentials();
            const useMSAL = clientCredentials.getUseMSAL();
            tl.debug(`MSAL - Graph - GetServicePrincipal - useMSAL = ${useMSAL}`);
            const requestUriFormat = (useMSAL ? "v1.0/" : "") + "{tenantId}/servicePrincipals";
            var filterQuery = util.format("appId eq '%s'", clientCredentials.getClientId());
            httpRequest.uri = this.client.getRequestUri(requestUriFormat, {
                '{tenantId}': clientCredentials.getTenantId()
            }, ['$filter=' + encodeURIComponent(filterQuery)]);
            tl.debug(`MSAL - Graph - GetServicePrincipal - requestURL = ${httpRequest.uri}`);
            var deferred = Q.defer();
            this.client.beginRequest(httpRequest).then(function (response) {
                return __awaiter(this, void 0, void 0, function* () {
                    if (response.statusCode == 200) {
                        var result = null;
                        if (response.body.value) {
                            result = response.body.value[0];
                        }
                        deferred.resolve(result);
                    }
                    else {
                        deferred.reject(azureServiceClientBase.ToError(response));
                    }
                });
            }).catch(function (error) {
                deferred.reject(error);
            });
            return deferred.promise;
        });
    }
}
exports.ServicePrincipals = ServicePrincipals;
