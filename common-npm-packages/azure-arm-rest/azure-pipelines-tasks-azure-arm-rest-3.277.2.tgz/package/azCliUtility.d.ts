import { WebApi } from 'azure-devops-node-api';
export declare function setAzureCloudBasedOnServiceEndpoint(connectedService: string): void;
export declare function loginAzureRM(connectedService: string): Promise<void>;
export declare function getFederatedToken(connectedServiceName: string): Promise<string>;
export declare function initOIDCToken2(connection: WebApi, projectId: string, hub: string, planId: string, jobId: string, serviceConnectionId: string, retryCount?: number, timeToWait?: number): Promise<string>;
export declare function validateAzModuleVersion(moduleName: string, currentVersion: string, displayName: string, versionTolerance: number, checkOnlyMajorVersion?: boolean): Promise<void>;
