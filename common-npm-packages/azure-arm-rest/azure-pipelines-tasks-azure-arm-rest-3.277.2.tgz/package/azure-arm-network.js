"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.securityRules = exports.NetworkInterfaces = exports.networkSecurityGroups = exports.publicIPAddresses = exports.loadBalancers = exports.NetworkManagementClient = void 0;
const path = require("path");
const tl = require("azure-pipelines-task-lib/task");
const Q = require("q");
const azureServiceClient = require("./AzureServiceClient");
const azureServiceClientBase = require("./AzureServiceClientBase");
const webClient = require("./webClient");
tl.setResourcePath(path.join(__dirname, 'module.json'), true);
class NetworkManagementClient extends azureServiceClient.ServiceClient {
    constructor(credentials, subscriptionId, baseUri, options) {
        super(credentials, subscriptionId);
        this.apiVersion = (credentials.isAzureStackEnvironment) ? '2015-06-15' : '2016-09-01';
        this.acceptLanguage = 'en-US';
        this.generateClientRequestId = true;
        if (!options)
            options = {};
        if (baseUri) {
            this.baseUri = baseUri;
        }
        if (options.apiVersion) {
            this.apiVersion = options.apiVersion;
        }
        if (options.acceptLanguage) {
            this.acceptLanguage = options.acceptLanguage;
        }
        if (options.longRunningOperationRetryTimeout) {
            this.longRunningOperationRetryTimeout = options.longRunningOperationRetryTimeout;
        }
        if (options.generateClientRequestId) {
            this.generateClientRequestId = options.generateClientRequestId;
        }
        this.loadBalancers = new loadBalancers(this);
        this.publicIPAddresses = new publicIPAddresses(this);
        this.networkSecurityGroups = new networkSecurityGroups(this);
        this.networkInterfaces = new NetworkInterfaces(this);
        this.securityRules = new securityRules(this);
    }
}
exports.NetworkManagementClient = NetworkManagementClient;
class loadBalancers {
    constructor(client) {
        this.client = client;
    }
    list(resourceGroupName, options, callback) {
        if (!callback && typeof options === 'function') {
            callback = options;
            options = null;
        }
        if (!callback) {
            throw new Error(tl.loc("CallbackCannotBeNull"));
        }
        // Validate
        try {
            this.client.isValidResourceGroupName(resourceGroupName);
        }
        catch (error) {
            return callback(error);
        }
        // Create HTTP transport objects
        var httpRequest = new webClient.WebRequest();
        httpRequest.method = 'GET';
        httpRequest.headers = {};
        httpRequest.uri = this.client.getRequestUri('//subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.Network/loadBalancers', {
            '{resourceGroupName}': resourceGroupName
        });
        // Set Headers
        httpRequest.headers = this.client.setCustomHeaders(options);
        httpRequest.body = null;
        //send request
        var result = [];
        this.client.beginRequest(httpRequest).then((response) => __awaiter(this, void 0, void 0, function* () {
            if (response.statusCode == 200) {
                if (response.body.value) {
                    result = result.concat(response.body.value);
                }
                if (response.body.nextLink) {
                    var nextResult = yield this.client.accumulateResultFromPagedResult(response.body.nextLink);
                    if (nextResult.error) {
                        return new azureServiceClientBase.ApiResult(nextResult.error);
                    }
                    result.concat(nextResult.result);
                }
                return new azureServiceClientBase.ApiResult(null, result);
            }
            else {
                return new azureServiceClientBase.ApiResult(azureServiceClientBase.ToError(response));
            }
        })).then((apiResult) => callback(apiResult.error, apiResult.result), (error) => callback(error));
    }
    get(resourceGroupName, loadBalancerName, options, callback) {
        var client = this.client;
        if (!callback && typeof options === 'function') {
            callback = options;
            options = null;
        }
        if (!callback) {
            throw new Error(tl.loc("CallbackCannotBeNull"));
        }
        var expand = (options && options.expand !== undefined) ? options.expand : undefined;
        // Validate
        try {
            this.client.isValidResourceGroupName(resourceGroupName);
            if (loadBalancerName === null || loadBalancerName === undefined || typeof loadBalancerName.valueOf() !== 'string') {
                throw new Error(tl.loc("LoadBalancerNameCannotBeNull"));
            }
            if (expand !== null && expand !== undefined && typeof expand.valueOf() !== 'string') {
                throw new Error(tl.loc("ExpandShouldBeOfTypeString"));
            }
        }
        catch (error) {
            return callback(error);
        }
        // Create HTTP transport objects
        var httpRequest = new webClient.WebRequest();
        httpRequest.method = 'GET';
        httpRequest.uri = this.client.getRequestUri('//subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.Network/loadBalancers/{loadBalancerName}', {
            '{resourceGroupName}': resourceGroupName,
            '{loadBalancerName}': loadBalancerName
        });
        httpRequest.headers = this.client.setCustomHeaders(options);
        httpRequest.body = null;
        this.client.beginRequest(httpRequest).then((response) => {
            var deferred = Q.defer();
            if (response.statusCode == 200) {
                deferred.resolve(new azureServiceClientBase.ApiResult(null, response.body));
            }
            else {
                deferred.resolve(new azureServiceClientBase.ApiResult(azureServiceClientBase.ToError(response)));
            }
            return deferred.promise;
        }).then((apiResult) => callback(apiResult.error, apiResult.result), (error) => callback(error));
    }
    createOrUpdate(resourceGroupName, loadBalancerName, parameters, options, callback) {
        var client = this.client;
        if (!callback && typeof options === 'function') {
            callback = options;
            options = null;
        }
        if (!callback) {
            throw new Error(tl.loc("CallbackCannotBeNull"));
        }
        var expand = (options && options.expand !== undefined) ? options.expand : undefined;
        // Validate
        try {
            this.client.isValidResourceGroupName(resourceGroupName);
            if (loadBalancerName === null || loadBalancerName === undefined || typeof loadBalancerName.valueOf() !== 'string') {
                throw new Error(tl.loc("LoadBalancerNameCannotBeNull"));
            }
            if (parameters === null || parameters === undefined) {
                throw new Error(tl.loc("ParametersCannotBeNull"));
            }
        }
        catch (error) {
            return callback(error);
        }
        var httpRequest = new webClient.WebRequest();
        httpRequest.method = 'PUT';
        httpRequest.headers = {};
        httpRequest.uri = this.client.getRequestUri('//subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.Network/loadBalancers/{loadBalancerName}', {
            '{resourceGroupName}': resourceGroupName,
            '{loadBalancerName}': loadBalancerName
        });
        // Set Headers
        httpRequest.headers = this.client.setCustomHeaders(options);
        if (parameters !== null && parameters !== undefined) {
            httpRequest.body = JSON.stringify(parameters);
        }
        this.client.beginRequest(httpRequest).then((response) => {
            var deferred = Q.defer();
            var statusCode = response.statusCode;
            if (statusCode != 200 && statusCode != 201) {
                deferred.resolve(new azureServiceClientBase.ApiResult(azureServiceClientBase.ToError(response)));
            }
            else {
                this.client.getLongRunningOperationResult(response).then((operationResponse) => {
                    if (operationResponse.body.status === "Succeeded") {
                        // Generate Response
                        deferred.resolve(new azureServiceClientBase.ApiResult(null, response.body));
                    }
                    else {
                        // Generate Error
                        deferred.resolve(new azureServiceClientBase.ApiResult(azureServiceClientBase.ToError(response)));
                    }
                }, (error) => deferred.reject(error));
            }
            return deferred.promise;
        }).then((apiResult) => callback(apiResult.error, apiResult.result), (error) => callback(error));
    }
}
exports.loadBalancers = loadBalancers;
class publicIPAddresses {
    constructor(client) {
        this.client = client;
    }
    list(resourceGroupName, options, callback) {
        var client = this.client;
        if (!callback && typeof options === 'function') {
            callback = options;
            options = null;
        }
        if (!callback) {
            throw new Error(tl.loc("CallbackCannotBeNull"));
        }
        // Validate
        try {
            this.client.isValidResourceGroupName(resourceGroupName);
        }
        catch (error) {
            return callback(error);
        }
        // Create HTTP transport objects
        var httpRequest = new webClient.WebRequest();
        httpRequest.method = 'GET';
        httpRequest.uri = this.client.getRequestUri('//subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.Network/publicIPAddresses', {
            '{resourceGroupName}': resourceGroupName
        });
        // Set Headers
        httpRequest.headers = this.client.setCustomHeaders(options);
        httpRequest.body = null;
        var result = [];
        this.client.beginRequest(httpRequest).then((response) => __awaiter(this, void 0, void 0, function* () {
            if (response.statusCode == 200) {
                if (response.body.value) {
                    result = result.concat(response.body.value);
                }
                if (response.body.nextLink) {
                    var nextResult = yield this.client.accumulateResultFromPagedResult(response.body.nextLink);
                    if (nextResult.error) {
                        return new azureServiceClientBase.ApiResult(nextResult.error);
                    }
                    result = result.concat(nextResult.result);
                }
                return new azureServiceClientBase.ApiResult(null, result);
            }
            else {
                return new azureServiceClientBase.ApiResult(azureServiceClientBase.ToError(response));
            }
        })).then((apiResult) => callback(apiResult.error, apiResult.result), (error) => callback(error));
    }
}
exports.publicIPAddresses = publicIPAddresses;
class networkSecurityGroups {
    constructor(client) {
        this.client = client;
    }
    list(resourceGroupName, options, callback) {
        var client = this.client;
        if (!callback && typeof options === 'function') {
            callback = options;
            options = null;
        }
        if (!callback) {
            throw new Error(tl.loc("CallbackCannotBeNull"));
        }
        // Validate
        try {
            this.client.isValidResourceGroupName(resourceGroupName);
        }
        catch (error) {
            return callback(error);
        }
        // Create HTTP transport objects
        var httpRequest = new webClient.WebRequest();
        httpRequest.method = 'GET';
        httpRequest.uri = this.client.getRequestUri('//subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.Network/networkSecurityGroups', {
            '{resourceGroupName}': resourceGroupName
        });
        // Set Headers
        httpRequest.headers = this.client.setCustomHeaders(options);
        httpRequest.body = null;
        var result = [];
        this.client.beginRequest(httpRequest).then((response) => __awaiter(this, void 0, void 0, function* () {
            if (response.statusCode == 200) {
                if (response.body.value) {
                    result = result.concat(response.body.value);
                }
                if (response.body.nextLink) {
                    var nextResult = yield this.client.accumulateResultFromPagedResult(response.body.nextLink);
                    if (nextResult.error) {
                        return new azureServiceClientBase.ApiResult(nextResult.error);
                    }
                    result = result.concat(nextResult.result);
                }
                return new azureServiceClientBase.ApiResult(null, result);
            }
            else {
                return new azureServiceClientBase.ApiResult(azureServiceClientBase.ToError(response));
            }
        })).then((apiResult) => callback(apiResult.error, apiResult.result), (error) => callback(error));
    }
}
exports.networkSecurityGroups = networkSecurityGroups;
class NetworkInterfaces {
    constructor(client) {
        this.client = client;
    }
    list(resourceGroupName, options, callback) {
        var client = this.client;
        if (!callback && typeof options === 'function') {
            callback = options;
            options = null;
        }
        if (!callback) {
            throw new Error(tl.loc("CallbackCannotBeNull"));
        }
        // Validate
        try {
            this.client.isValidResourceGroupName(resourceGroupName);
        }
        catch (error) {
            return callback(error);
        }
        var httpRequest = new webClient.WebRequest();
        httpRequest.method = 'GET';
        httpRequest.uri = this.client.getRequestUri('//subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.Network/networkInterfaces', {
            '{resourceGroupName}': resourceGroupName
        });
        httpRequest.headers = this.client.setCustomHeaders(options);
        httpRequest.body = null;
        var result = [];
        this.client.beginRequest(httpRequest).then((response) => __awaiter(this, void 0, void 0, function* () {
            if (response.statusCode == 200) {
                if (response.body.value) {
                    result = result.concat(response.body.value);
                }
                if (response.body.nextLink) {
                    var nextResult = yield this.client.accumulateResultFromPagedResult(response.body.nextLink);
                    if (nextResult.error) {
                        return new azureServiceClientBase.ApiResult(nextResult.error);
                    }
                    result = result.concat(nextResult.result);
                }
                return new azureServiceClientBase.ApiResult(null, result);
            }
            else {
                return new azureServiceClientBase.ApiResult(azureServiceClientBase.ToError(response));
            }
        })).then((apiResult) => callback(apiResult.error, apiResult.result), (error) => callback(error));
    }
    createOrUpdate(resourceGroupName, networkInterfaceName, parameters, options, callback) {
        var client = this.client;
        if (!callback && typeof options === 'function') {
            callback = options;
            options = null;
        }
        if (!callback) {
            throw new Error(tl.loc("CallbackCannotBeNull"));
        }
        // Validate
        try {
            this.client.isValidResourceGroupName(resourceGroupName);
            if (networkInterfaceName === null || networkInterfaceName === undefined || typeof networkInterfaceName.valueOf() !== 'string') {
                throw new Error(tl.loc("NetworkInterfaceNameCannotBeNull"));
            }
            if (parameters === null || parameters === undefined) {
                throw new Error(tl.loc("ParametersCannotBeNull"));
            }
        }
        catch (error) {
            return callback(error);
        }
        // Create HTTP transport objects
        var httpRequest = new webClient.WebRequest();
        httpRequest.method = 'PUT';
        httpRequest.uri = this.client.getRequestUri('//subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.Network/networkInterfaces/{networkInterfaceName}', {
            '{networkInterfaceName}': networkInterfaceName,
            '{resourceGroupName}': resourceGroupName
        });
        httpRequest.headers = this.client.setCustomHeaders(options);
        if (parameters) {
            httpRequest.body = JSON.stringify(parameters);
        }
        this.client.beginRequest(httpRequest).then((response) => {
            var deferred = Q.defer();
            if (response.statusCode != 200 && response.statusCode != 201) {
                deferred.resolve(new azureServiceClientBase.ApiResult(azureServiceClientBase.ToError(response)));
            }
            else {
                this.client.getLongRunningOperationResult(response).then((operationResponse) => {
                    if (operationResponse.body.status === "Succeeded") {
                        deferred.resolve(new azureServiceClientBase.ApiResult(null, operationResponse.body.value));
                    }
                    else {
                        deferred.resolve(new azureServiceClientBase.ApiResult(azureServiceClientBase.ToError(operationResponse)));
                    }
                }, (error) => deferred.reject(error));
            }
            return deferred.promise;
        }).then((apiResult) => callback(apiResult.error, apiResult.result), (error) => callback(error));
    }
}
exports.NetworkInterfaces = NetworkInterfaces;
class securityRules {
    constructor(client) {
        this.client = client;
    }
    get(resourceGroupName, networkSecurityGroupName, securityRuleName, options, callback) {
        var client = this.client;
        if (!callback && typeof options === 'function') {
            callback = options;
            options = null;
        }
        if (!callback) {
            throw new Error(tl.loc("CallbackCannotBeNull"));
        }
        // Validate
        try {
            this.client.isValidResourceGroupName(resourceGroupName);
            if (networkSecurityGroupName === null || networkSecurityGroupName === undefined || typeof networkSecurityGroupName.valueOf() !== 'string') {
                throw new Error(tl.loc("NetworkSecurityGroupNameCannotBeNull"));
            }
            if (securityRuleName === null || securityRuleName === undefined || typeof securityRuleName.valueOf() !== 'string') {
                throw new Error(tl.loc("SecurityRuleNameCannotBeNull"));
            }
        }
        catch (error) {
            return callback(error);
        }
        // Create HTTP transport objects
        var httpRequest = new webClient.WebRequest();
        httpRequest.method = 'GET';
        httpRequest.uri = this.client.getRequestUri('//subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.Network/networkSecurityGroups/{networkSecurityGroupName}/securityRules/{securityRuleName}', {
            '{resourceGroupName}': resourceGroupName,
            '{networkSecurityGroupName}': networkSecurityGroupName,
            '{securityRuleName}': securityRuleName
        });
        httpRequest.headers = this.client.setCustomHeaders(options);
        httpRequest.body = null;
        // Send Request
        this.client.beginRequest(httpRequest).then((response) => {
            var deferred = Q.defer();
            if (response.statusCode == 200) {
                deferred.resolve(new azureServiceClientBase.ApiResult(null, response.body));
            }
            else {
                deferred.resolve(new azureServiceClientBase.ApiResult(azureServiceClientBase.ToError(response)));
            }
            return deferred.promise;
        }).then((apiResult) => callback(apiResult.error, apiResult.result), (error) => callback(error));
    }
    createOrUpdate(resourceGroupName, networkSecurityGroupName, securityRuleName, securityRuleParameters, callback) {
        var client = this.client;
        if (!callback) {
            throw new Error(tl.loc("CallbackCannotBeNull"));
        }
        // Validate
        try {
            this.client.isValidResourceGroupName(resourceGroupName);
            if (networkSecurityGroupName === null || networkSecurityGroupName === undefined || typeof networkSecurityGroupName.valueOf() !== 'string') {
                throw new Error(tl.loc("NetworkSecurityGroupNameCannotBeNull"));
            }
            if (securityRuleName === null || securityRuleName === undefined || typeof securityRuleName.valueOf() !== 'string') {
                throw new Error(tl.loc("SecurityRuleNameCannotBeNull"));
            }
            if (securityRuleParameters === null || securityRuleParameters === undefined) {
                throw new Error(tl.loc("SecurityRuleParametersCannotBeNull"));
            }
        }
        catch (error) {
            return callback(error);
        }
        // Create HTTP transport objects
        var httpRequest = new webClient.WebRequest();
        httpRequest.method = 'PUT';
        httpRequest.uri = this.client.getRequestUri('//subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.Network/networkSecurityGroups/{networkSecurityGroupName}/securityRules/{securityRuleName}', {
            '{resourceGroupName}': resourceGroupName,
            '{networkSecurityGroupName}': networkSecurityGroupName,
            '{securityRuleName}': securityRuleName
        });
        httpRequest.headers = this.client.setCustomHeaders(null);
        if (securityRuleParameters) {
            httpRequest.body = JSON.stringify(securityRuleParameters);
        }
        this.client.beginRequest(httpRequest).then((response) => {
            var deferred = Q.defer();
            var statusCode = response.statusCode;
            if (statusCode != 200 && statusCode != 201) {
                deferred.resolve(new azureServiceClientBase.ApiResult(azureServiceClientBase.ToError(response)));
            }
            else {
                this.client.getLongRunningOperationResult(response).then((operationResponse) => {
                    if (operationResponse.body.status === "Succeeded") {
                        deferred.resolve(new azureServiceClientBase.ApiResult(null, operationResponse.body));
                    }
                    else {
                        deferred.resolve(new azureServiceClientBase.ApiResult(azureServiceClientBase.ToError(operationResponse)));
                    }
                }, (error) => deferred.reject(error));
            }
            return deferred.promise;
        }).then((apiResult) => callback(apiResult.error, apiResult.result), (error) => callback(error));
    }
}
exports.securityRules = securityRules;
