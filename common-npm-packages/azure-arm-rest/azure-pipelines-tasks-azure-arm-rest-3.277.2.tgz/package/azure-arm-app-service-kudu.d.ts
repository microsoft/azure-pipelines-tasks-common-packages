import { WebJob, SiteExtension } from './azureModels';
import webClient = require('./webClient');
export declare class KuduServiceManagementClient {
    private _scmUri;
    private _authHeader;
    private _cookie;
    constructor(scmUri: string, authHeader: string, cookie?: string[]);
    beginRequest(request: webClient.WebRequest, reqOptions?: webClient.WebRequestOptions, contentType?: string): Promise<webClient.WebResponse>;
    getRequestUri(uriFormat: string, queryParameters?: Array<string>): string;
    getScmUri(): string;
}
export declare class Kudu {
    client: KuduServiceManagementClient;
    constructor(scmUri: string, authHeader: string, cookie?: string[]);
    updateDeployment(requestBody: any): Promise<string>;
    getKuduStackTraceUrl(): string;
    getContinuousJobs(): Promise<Array<WebJob>>;
    startContinuousWebJob(jobName: string): Promise<WebJob>;
    stopContinuousWebJob(jobName: string): Promise<WebJob>;
    installSiteExtension(extensionID: string): Promise<SiteExtension>;
    installSiteExtensionWithVersion(extensionID: string, version: string): Promise<SiteExtension>;
    getSiteExtensions(): Promise<Array<SiteExtension>>;
    getAllSiteExtensions(): Promise<Array<SiteExtension>>;
    getProcess(processID: number): Promise<any>;
    killProcess(processID: number): Promise<void>;
    getAppSettings(): Promise<Map<string, string>>;
    listDir(physicalPath: string): Promise<any>;
    getFileContent(physicalPath: string, fileName: string): Promise<string>;
    uploadFile(physicalPath: string, fileName: string, filePath: string): Promise<void>;
    createPath(physicalPath: string): Promise<any>;
    runCommand(physicalPath: string, command: string): Promise<void>;
    extractZIP(webPackage: string, physicalPath: string): Promise<void>;
    zipDeploy(webPackage: string, queryParameters?: Array<string>, addChecksumHeader?: boolean): Promise<any>;
    warDeploy(webPackage: string, queryParameters?: Array<string>): Promise<any>;
    oneDeploy(webPackage: string, queryParameters?: Array<string>, addChecksumHeader?: boolean): Promise<any>;
    getDeploymentDetails(deploymentID: string): Promise<any>;
    getDeploymentLogs(log_url: string): Promise<any>;
    deleteFile(physicalPath: string, fileName: string): Promise<void>;
    deleteFolder(physicalPath: string): Promise<void>;
    private _getDeploymentDetailsFromPollURL;
    private _getFormattedError;
    private _computeFileChecksum;
    /**
     * Warms up the Kudu service using the dedicated warmup endpoint.
     * Uses /api/deployments?warmup=true with retry logic.
     */
    warmup(): Promise<void>;
}
/**
 * Pipeline-feature gated sanitizer for remote Kudu/Oryx log content, to be called by task code
 * immediately before printing content obtained from Kudu.getFileContent / Kudu.getDeploymentLogs
 * (see the comment above for the full rationale and feature name).
 *
 * @param text the raw remote log content about to be printed to the console.
 * @param telemetryFeature the `feature` value to tag emitted telemetry with - callers should
 *        pass a value identifying their own task (e.g. 'AzureRmWebAppDeployment',
 *        'AzureFunctionApp') so telemetry can be attributed correctly.
 *
 * - Detection telemetry always runs: if `text` contains any ##vso[...] command sequence, it is
 *   always reported via telemetry.publish, regardless of the pipeline feature state.
 * - EnableKuduLogVsoCommandSanitization off (default today): text is returned completely
 *   unmodified - telemetry-only, zero behavior change for customers.
 * - EnableKuduLogVsoCommandSanitization on: enforce. Neutralizes the "##vso[" (and leading
 *   "##[") trigger sequences so the agent can no longer parse them as logging commands.
 */
export declare function sanitizeKuduLogForConsole(text: string, telemetryFeature: string): string;
