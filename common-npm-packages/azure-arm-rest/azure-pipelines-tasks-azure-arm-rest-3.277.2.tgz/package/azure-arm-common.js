"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ApplicationTokenCredentials = void 0;
const crypto = require("crypto");
const fs = require("fs");
const path = require("path");
const querystring = require("querystring");
const async_mutex_1 = require("async-mutex");
const azure_devops_node_api_1 = require("azure-devops-node-api");
const tl = require("azure-pipelines-task-lib/task");
const HttpsProxyAgent = require("https-proxy-agent");
const fetch = require("node-fetch");
const jwt = require("jsonwebtoken");
const Q = require("q");
const azCliUtility = require("./azCliUtility");
const AzureModels = require("./azureModels");
const constants = require("./constants");
const webClient = require("./webClient");
// Important note! Since the msal v2.** and @azure/identity don't work with Node 10, and we still need to support Node 10 execution handler, a dynamic loading was implemented.
// Dynamic loading imposes restrictions on type validation when compiling TypeScript and we can't use it in this case.
// For this reason, all msal types and @azure/identity types were temporarily replaced with 'any' type.
// When the support for Node 10 is dropped, the types should be restored and the dynamic loading should be removed.
/// Dynamic msal loading based on the node version
const nodeVersion = parseInt(process.version.split('.')[0].replace('v', ''));
const msalVer = nodeVersion < 16 ? "msalv1" : "msalv3";
// Maximum backoff timeout for creating AAD token in milliseconds
const MAX_CREATE_AAD_TOKEN_BACKOFF_TIMEOUT = 15000;
tl.debug('Using ' + msalVer);
const msal = require(msalVer);
/// Dynamic @azure/identity loading based on the node version
/// The @azure/identity package depends on @azure/msal-node which uses modern JavaScript features like optional chaining
/// that are not supported in Node 10. We only load it when running on Node 14+.
let azureIdentity;
if (nodeVersion >= 16) {
    azureIdentity = require("@azure/identity");
}
///
tl.setResourcePath(path.join(__dirname, 'module.json'), true);
class ApplicationTokenCredentials {
    constructor(connectedServiceName, clientId, tenantId, secret, baseUrl, authorityUrl, activeDirectoryResourceId, isAzureStackEnvironment, scheme, msiClientId, authType, certFilePath, isADFSEnabled, access_token, useMSAL, allowScopeLevelToken, scopes) {
        if (!Boolean(connectedServiceName) || typeof tenantId.valueOf() !== 'string') {
            throw new Error(tl.loc("serviceConnectionIdCannotBeEmpty"));
        }
        if (!Boolean(tenantId) || typeof tenantId.valueOf() !== 'string') {
            throw new Error(tl.loc("DomainCannotBeEmpty"));
        }
        if ((!scheme || scheme === 'ServicePrincipal')) {
            if (!Boolean(clientId) || typeof clientId.valueOf() !== 'string') {
                throw new Error(tl.loc("ClientIdCannotBeEmpty"));
            }
            if (!authType || authType == constants.AzureServicePrinicipalAuthentications.servicePrincipalKey) {
                if (!Boolean(secret) || typeof secret.valueOf() !== 'string') {
                    throw new Error(tl.loc("SecretCannotBeEmpty"));
                }
            }
            else {
                if (!Boolean(certFilePath) || typeof certFilePath.valueOf() !== 'string') {
                    throw new Error(tl.loc("InvalidCertFileProvided"));
                }
            }
        }
        if (!Boolean(baseUrl) || typeof baseUrl.valueOf() !== 'string') {
            throw new Error(tl.loc("armUrlCannotBeEmpty"));
        }
        if (!Boolean(authorityUrl) || typeof authorityUrl.valueOf() !== 'string') {
            throw new Error(tl.loc("authorityUrlCannotBeEmpty"));
        }
        if (!Boolean(activeDirectoryResourceId) || typeof activeDirectoryResourceId.valueOf() !== 'string') {
            throw new Error(tl.loc("activeDirectoryResourceIdUrlCannotBeEmpty"));
        }
        if (!Boolean(isAzureStackEnvironment) || typeof isAzureStackEnvironment.valueOf() != 'boolean') {
            isAzureStackEnvironment = false;
        }
        this.connectedServiceName = connectedServiceName;
        this.clientId = clientId;
        this.tenantId = tenantId;
        this.baseUrl = baseUrl;
        this.authorityUrl = authorityUrl;
        this.activeDirectoryResourceId = activeDirectoryResourceId;
        this.isAzureStackEnvironment = isAzureStackEnvironment;
        this.scheme = scheme ? AzureModels.Scheme[scheme] : AzureModels.Scheme['ServicePrincipal'];
        this.msiClientId = msiClientId;
        if (this.scheme == AzureModels.Scheme['ServicePrincipal']) {
            this.authType = authType ? authType : constants.AzureServicePrinicipalAuthentications.servicePrincipalKey;
            if (this.authType == constants.AzureServicePrinicipalAuthentications.servicePrincipalKey) {
                this.secret = secret;
            }
            else {
                this.certFilePath = certFilePath;
            }
        }
        this.isADFSEnabled = isADFSEnabled;
        this.accessToken = access_token;
        this.useMSAL = useMSAL;
        this.scopes = scopes;
        this.allowScopeLevelToken = allowScopeLevelToken || false;
        this.tokenMutex = new async_mutex_1.Mutex();
    }
    /**
     * @deprecated ADAL related methods are deprecated and will be removed.
     * Use Use `getMSALToken(force?: boolean)` instead.
     */
    static getMSIAuthorizationToken(retyCount, timeToWait, baseUrl, msiClientId) {
        var deferred = Q.defer();
        let webRequest = new webClient.WebRequest();
        webRequest.method = "GET";
        let apiVersion = "2018-02-01";
        const retryLimit = 5;
        msiClientId = msiClientId ? "&client_id=" + msiClientId : "";
        webRequest.uri = "http://169.254.169.254/metadata/identity/oauth2/token?api-version=" + apiVersion + "&resource=" + baseUrl + msiClientId;
        webRequest.headers = {
            "Metadata": true
        };
        webClient.sendRequest(webRequest).then((response) => {
            if (response.statusCode == 200) {
                deferred.resolve(response.body.access_token);
            }
            else if (response.statusCode == 429 || response.statusCode == 500) {
                if (retyCount < retryLimit) {
                    let waitedTime = 2000 + timeToWait * 2;
                    retyCount += 1;
                    setTimeout(() => {
                        deferred.resolve(this.getMSIAuthorizationToken(retyCount, waitedTime, baseUrl, msiClientId));
                    }, waitedTime);
                }
                else {
                    deferred.reject(tl.loc('CouldNotFetchAccessTokenforMSIStatusCode', response.statusCode, response.statusMessage));
                }
            }
            else {
                deferred.reject(tl.loc('CouldNotFetchAccessTokenforMSIDueToMSINotConfiguredProperlyStatusCode', response.statusCode, response.statusMessage));
            }
        }, (error) => {
            deferred.reject(error);
        });
        return deferred.promise;
    }
    getTenantId() {
        return this.tenantId;
    }
    getClientId() {
        return this.clientId;
    }
    getUseMSAL() {
        return this.useMSAL;
    }
    getToken(force) {
        return __awaiter(this, void 0, void 0, function* () {
            // run exclusively to prevent race conditions
            const release = yield this.tokenMutex.acquire();
            try {
                const promisedTokenResult = this.getUseMSAL() ? this.getMSALToken(force) : this.getADALToken(force);
                return yield promisedTokenResult;
            }
            finally {
                // release it for every situation
                release();
            }
        });
    }
    static initOIDCToken(connection, projectId, hub, planId, jobId, serviceConnectionId, retryCount = 0, timeToWait = 2000) {
        return __awaiter(this, void 0, void 0, function* () {
            let error;
            for (let i = retryCount > 0 ? retryCount : 3; i > 0; i--) {
                try {
                    const api = yield connection.getTaskApi();
                    const response = yield api.createOidcToken({}, projectId, hub, planId, jobId, serviceConnectionId);
                    if (response && response.oidcToken) {
                        tl.debug('Got OIDC token');
                        return response.oidcToken;
                    }
                }
                catch (e) {
                    error = e;
                }
                yield new Promise(r => setTimeout(r, timeToWait));
                tl.debug(`Retrying OIDC token fetch. Retries left: ${i}`);
            }
            let message = tl.loc('CouldNotFetchAccessTokenforAAD');
            if (error) {
                message += " " + error;
            }
            return Promise.reject(new Error(message));
        });
    }
    static getSystemAccessToken() {
        tl.debug('Getting credentials for local feeds');
        const auth = tl.getEndpointAuthorization('SYSTEMVSSCONNECTION', false);
        if (auth.scheme === 'OAuth') {
            tl.debug('Got auth token');
            return auth.parameters['AccessToken'];
        }
        else {
            tl.warning('Could not determine credentials to use');
        }
    }
    getMSAL() {
        return __awaiter(this, void 0, void 0, function* () {
            // use same instance if it already exists
            if (!this.msalInstance) {
                this.msalInstance = yield this.buildMSAL();
            }
            return this.msalInstance;
        });
    }
    getProxyClient(agentProxyURL) {
        let proxyURL = `${agentProxyURL.protocol}//${agentProxyURL.host}`;
        const agentProxyUsername = tl.getVariable("agent.proxyusername");
        const agentProxyPassword = tl.getVariable("agent.proxypassword");
        const encodedProxyUsername = agentProxyUsername ? encodeURIComponent(agentProxyUsername) : '';
        const encodedProxyPassword = agentProxyPassword ? encodeURIComponent(agentProxyPassword) : '';
        if (agentProxyUsername) {
            // basic auth
            proxyURL = `${agentProxyURL.protocol}//${encodedProxyUsername}:${encodedProxyPassword}@${agentProxyURL.host}`;
            tl.debug(`MSAL - Proxy setup with auth is: ${agentProxyURL.protocol}//${encodedProxyUsername}:***@${agentProxyURL.host}`);
        }
        else {
            // no auth
            tl.debug(`MSAL - Proxy setup with no-auth is: ${proxyURL}`);
        }
        // direct usage of msalConfig.system.proxyUrl is not available at the moment due to the fact that Object.fromEntries requires >=Node12
        const proxyAgent = new HttpsProxyAgent(proxyURL);
        const proxyNetworkClient /*msal.INetworkModule*/ = {
            sendGetRequestAsync(url, options) {
                return __awaiter(this, void 0, void 0, function* () {
                    const customOptions = Object.assign(Object.assign({}, options), { method: "GET", agent: proxyAgent });
                    const response = yield fetch(url, customOptions);
                    return {
                        status: response.status,
                        headers: Object.create(Object.prototype, response.headers.raw()),
                        body: yield response.json()
                    };
                });
            },
            sendPostRequestAsync(url, options) {
                return __awaiter(this, void 0, void 0, function* () {
                    const customOptions = Object.assign(Object.assign({}, options), { method: "POST", agent: proxyAgent });
                    const response = yield fetch(url, customOptions);
                    return {
                        status: response.status,
                        headers: Object.create(Object.prototype, response.headers.raw()),
                        body: yield response.json()
                    };
                });
            }
        };
        return proxyNetworkClient;
    }
    buildMSAL() {
        return __awaiter(this, void 0, void 0, function* () {
            // default configuration
            const authorityURL = (new URL(this.tenantId, this.authorityUrl)).toString();
            const isDebug = tl.getVariable("system.debug") && tl.getVariable("system.debug").toLowerCase() === "true";
            const msalConfig /*msal.Configuration*/ = {
                auth: {
                    clientId: this.clientId,
                    authority: authorityURL
                },
                system: {
                    loggerOptions: {
                        loggerCallback(loglevel, message, _) {
                            loglevel === msal.LogLevel.Error ? tl.error(message) : tl.debug(message);
                        },
                        piiLoggingEnabled: isDebug,
                        logLevel: isDebug ? msal.LogLevel.Trace : msal.LogLevel.Info,
                    }
                }
            };
            // proxy usage
            const agentProxyURL = tl.getVariable("agent.proxyurl") ? new URL(tl.getVariable("agent.proxyurl")) : null;
            const agentProxyBypassHosts = tl.getVariable("agent.proxybypasslist") ? JSON.parse(tl.getVariable("agent.proxybypasslist")) : [];
            const authorityHost = new URL(authorityURL).host;
            // same test logic is applied as typed-rest-client
            const bypassChecker = (elem) => elem && new RegExp(elem, 'i').test(authorityHost);
            const shouldProxyBypass = agentProxyBypassHosts.some(bypassChecker);
            if (agentProxyURL) {
                if (shouldProxyBypass) {
                    tl.debug(`MSAL - Proxy is set but will be bypassed for ${authorityURL}`);
                }
                else {
                    tl.debug('MSAL - Proxy will be used.');
                    msalConfig.system.networkClient = this.getProxyClient(agentProxyURL);
                }
            }
            let msalInstance; //msal.ConfidentialClientApplication
            // setup msal according to parameters
            switch (this.scheme) {
                case AzureModels.Scheme.ManagedServiceIdentity:
                    msalInstance = this.configureMSALWithMSI(msalConfig);
                    break;
                case AzureModels.Scheme.WorkloadIdentityFederation:
                    msalInstance = yield this.configureMSALWithOIDC(msalConfig);
                    break;
                case AzureModels.Scheme.SPN:
                default:
                    msalInstance = this.configureMSALWithSP(msalConfig);
                    break;
            }
            return msalInstance;
        });
    }
    configureMSALWithMSI(msalConfig /*msal.Configuration*/) {
        let resourceId = this.activeDirectoryResourceId;
        let accessTokenProvider /*msal.IAppTokenProvider*/ = (appTokenProviderParameters /*msal.AppTokenProviderParameters*/) => {
            tl.debug("MSAL - ManagedIdentity is used.");
            let providerResultPromise = new Promise(function (resolve, reject) {
                // same for MSAL
                let webRequest = new webClient.WebRequest();
                webRequest.method = "GET";
                let apiVersion = "2018-02-01";
                webRequest.uri = "http://169.254.169.254/metadata/identity/oauth2/token?api-version=" + apiVersion + "&resource=" + resourceId;
                webRequest.headers = {
                    "Metadata": true
                };
                webClient.sendRequest(webRequest).then((response) => {
                    if (response.statusCode == 200) {
                        let providerResult /*msal.AppTokenProviderResult*/ = {
                            accessToken: response.body.access_token,
                            expiresInSeconds: response.body.expires_in
                        };
                        resolve(providerResult);
                    }
                    else {
                        let errorMessage = tl.loc('CouldNotFetchAccessTokenforMSIStatusCode', response.statusCode, response.statusMessage);
                        reject({ errorCode: response.statusCode, errorMessage: errorMessage });
                    }
                }, (error) => {
                    reject({ errorCode: "Unkown", errorMessage: error });
                });
            });
            return providerResultPromise;
        };
        // need to be set a value even, although it is not used (library requirement)
        msalConfig.auth.clientSecret = "dummy-value";
        let msalInstance = new msal.ConfidentialClientApplication(msalConfig);
        msalInstance.SetAppTokenProvider(accessTokenProvider);
        return msalInstance;
    }
    configureMSALWithSP(msalConfig /*msal.Configuration*/) {
        switch (this.authType) {
            case constants.AzureServicePrinicipalAuthentications.servicePrincipalKey:
                tl.debug("MSAL - ServicePrincipal - clientSecret is used.");
                msalConfig.auth.clientSecret = this.secret;
                break;
            case constants.AzureServicePrinicipalAuthentications.servicePrincipalCertificate:
                tl.debug("MSAL - ServicePrincipal - certificate is used.");
                try {
                    const certFile = fs.readFileSync(this.certFilePath).toString();
                    // thumbprint
                    const certEncoded = certFile.match(/-----BEGIN CERTIFICATE-----\s*([\s\S]+?)\s*-----END CERTIFICATE-----/i)[1];
                    const certDecoded = Buffer.from(certEncoded, "base64");
                    // CodeQL [SM01510] External Dependency: Azure CLI generated certificates support only sha1 // CodeQL [SM04514] External Dependency: Azure CLI generated certificates support only sha1
                    const thumbprint = crypto.createHash("sha1").update(certDecoded).digest("hex").toUpperCase();
                    if (!thumbprint) {
                        throw new Error("MSAL - certificate - thumbprint couldn't be generated!");
                    }
                    tl.debug("MSAL - ServicePrincipal - certificate thumbprint creation is successful: " + thumbprint);
                    // privatekey
                    const privateKey = certFile.match(/-----BEGIN (.)*PRIVATE KEY-----\s*([\s\S]+?)\s*-----END (.)*PRIVATE KEY-----/i)[0];
                    if (!privateKey) {
                        throw new Error("MSAL - certificate - private key couldn't read!");
                    }
                    tl.debug("MSAL - ServicePrincipal - certificate private key reading is successful.");
                    msalConfig.auth.clientCertificate = {
                        thumbprint: thumbprint,
                        privateKey: privateKey
                    };
                }
                catch (error) {
                    throw new Error("MSAL - ServicePrincipal - certificate error: " + error);
                }
                break;
        }
        let msalInstance = new msal.ConfidentialClientApplication(msalConfig);
        return msalInstance;
    }
    getFederatedToken() {
        return __awaiter(this, void 0, void 0, function* () {
            const projectId = tl.getVariable('System.TeamProjectId');
            const hub = tl.getVariable('System.HostType');
            const planId = tl.getVariable('System.PlanId');
            const jobId = tl.getVariable('System.JobId');
            let uri = tl.getVariable('System.CollectionUri');
            if (!uri) {
                uri = tl.getVariable('System.TeamFoundationServerUri');
            }
            const token = ApplicationTokenCredentials.getSystemAccessToken();
            const authHandler = (0, azure_devops_node_api_1.getHandlerFromToken)(token);
            const connection = new azure_devops_node_api_1.WebApi(uri, authHandler);
            if (tl.getPipelineFeature("UseOIDCToken2InAzureArmRest")) {
                return azCliUtility.initOIDCToken2(connection, projectId, hub, planId, jobId, this.connectedServiceName);
            }
            const oidc_token = yield ApplicationTokenCredentials.initOIDCToken(connection, projectId, hub, planId, jobId, this.connectedServiceName, 3, 2000);
            return oidc_token;
        });
    }
    configureMSALWithOIDC(msalConfig /*msal.Configuration*/) {
        return __awaiter(this, void 0, void 0, function* () {
            tl.debug('MSAL - FederatedAccess - OIDC is used.');
            msalConfig.auth.clientAssertion = yield this.getFederatedToken();
            let msalInstance = new msal.ConfidentialClientApplication(msalConfig);
            return msalInstance;
        });
    }
    getMSALToken(force, retryCount = 3, retryWaitMS = 2000) {
        return __awaiter(this, void 0, void 0, function* () {
            tl.debug(`MSAL - getMSALToken called. force=${force}`);
            const msalApp /*msal.ConfidentialClientApplication*/ = yield this.getMSAL();
            if (force) {
                msalApp.clearCache();
            }
            try {
                const request /*msal.ClientCredentialRequest*/ = {
                    scopes: [this.activeDirectoryResourceId + "/.default"]
                };
                const response = yield msalApp.acquireTokenByClientCredential(request);
                tl.debug(`MSAL - retrieved token - isFromCache?: ${response.fromCache}`);
                return response.accessToken;
            }
            catch (error) {
                if (retryCount > 0) {
                    tl.debug(`MSAL - retrying getMSALToken - temporary error code: ${error.errorCode}`);
                    tl.debug(`MSAL - retrying getMSALToken - remaining attempts: ${retryCount}`);
                    yield new Promise(r => setTimeout(r, Math.min(retryWaitMS, MAX_CREATE_AAD_TOKEN_BACKOFF_TIMEOUT)));
                    return yield this.getMSALToken(force, (retryCount - 1), retryWaitMS * 2);
                }
                if (error.errorMessage && error.errorMessage.toString().startsWith("7000222")) {
                    // Additional error message when clientSecret has been expired
                    const organizationURL = tl.getVariable('System.CollectionUri');
                    const projectName = tl.getVariable('System.TeamProject');
                    const serviceConnectionLink = encodeURI(`${organizationURL}${projectName}/_settings/adminservices?resourceId=${this.connectedServiceName}`);
                    throw new Error(tl.loc('ExpiredServicePrincipalMessageWithLink', serviceConnectionLink));
                }
                else {
                    throw new Error(tl.loc('CouldNotFetchAccessTokenforAzureStatusCode', error.errorCode, error.errorMessage));
                }
            }
        });
    }
    acquireTokenForScope(scopeKind) {
        return __awaiter(this, void 0, void 0, function* () {
            tl.debug(`acquireTokenForScope called with scopeKind: ${scopeKind}`);
            try {
                if (this.allowScopeLevelToken && this.scopes && this.scopes[scopeKind]) {
                    tl.debug(`allowScopeLevelToken is enabled, using scope: ${this.scopes[scopeKind]}`);
                    const credential = yield this.buildCredentialByScheme();
                    const tokenResponse = yield credential.getToken(this.scopes[scopeKind]);
                    return tokenResponse.token;
                }
                else {
                    tl.debug(`allowScopeLevelToken is disabbled`);
                    return yield this.getToken();
                }
            }
            catch (error) {
                tl.debug(`acquireTokenForScopes - error: ${error}`);
                throw new Error(tl.loc('CouldNotFetchAccessTokenforAzureStatusCode', error.errorCode, error.errorMessage));
            }
        });
    }
    buildCredentialByScheme() {
        return __awaiter(this, void 0, void 0, function* () {
            tl.debug(`buildCredentialByScheme called. scheme = ${AzureModels.Scheme[this.scheme]}`);
            if (!azureIdentity) {
                throw new Error(`@azure/identity is not supported on Node ${nodeVersion}. Please use Node 16 or higher for this authentication scheme.`);
            }
            switch (this.scheme) {
                case AzureModels.Scheme.ManagedServiceIdentity:
                    tl.debug('Using ManagedIdentityCredential for MSI');
                    return new azureIdentity.ManagedIdentityCredential(this.msiClientId);
                case AzureModels.Scheme.WorkloadIdentityFederation:
                    tl.debug('Using WorkloadIdentityCredential for OIDC');
                    const federatedToken = yield this.getFederatedToken();
                    const tokenFilePath = path.join(tl.getVariable('Agent.TempDirectory') || tl.getVariable('system.DefaultWorkingDirectory'), 'token.jwt');
                    fs.writeFileSync(tokenFilePath, federatedToken);
                    return new azureIdentity.WorkloadIdentityCredential({
                        tenantId: this.tenantId,
                        clientId: this.clientId,
                        tokenFilePath: tokenFilePath
                    });
                case AzureModels.Scheme.SPN:
                default:
                    tl.debug('Using specific credential for Service Principal');
                    if (this.authType === constants.AzureServicePrinicipalAuthentications.servicePrincipalKey) {
                        tl.debug('Using ClientSecretCredential for key-based SPN');
                        return new azureIdentity.ClientSecretCredential(this.tenantId, this.clientId, this.secret);
                    }
                    else {
                        tl.debug('Using ClientCertificateCredential for certificate-based SPN');
                        return new azureIdentity.ClientCertificateCredential(this.tenantId, this.clientId, this.certFilePath);
                    }
            }
        });
    }
    /**
     * @deprecated ADAL related methods are deprecated and will be removed.
     * Use Use `getMSALToken(force?: boolean)` instead.
     */
    getADALToken(force) {
        if (!!this.accessToken && !force) {
            tl.debug("==================== USING ENDPOINT PROVIDED ACCESS TOKEN ====================");
            let deferred = Q.defer();
            deferred.resolve(this.accessToken);
            return deferred.promise;
        }
        if (!this.token_deferred || force) {
            if (this.scheme === AzureModels.Scheme.ManagedServiceIdentity) {
                this.token_deferred = ApplicationTokenCredentials.getMSIAuthorizationToken(0, 0, this.baseUrl, this.msiClientId);
            }
            else {
                this.token_deferred = this._getSPNAuthorizationToken();
            }
        }
        return this.token_deferred;
    }
    /**
     * @deprecated ADAL related methods are deprecated and will be removed.
     * Use Use `getMSALToken(force?: boolean)` instead.
     */
    _getSPNAuthorizationToken() {
        if (this.authType == constants.AzureServicePrinicipalAuthentications.servicePrincipalKey) {
            return this._getSPNAuthorizationTokenFromKey();
        }
        return this._getSPNAuthorizationTokenFromCertificate();
    }
    /**
     * @deprecated ADAL related methods are deprecated and will be removed.
     * Use Use `getMSALToken(force?: boolean)` instead.
     */
    _getSPNAuthorizationTokenFromCertificate() {
        var deferred = Q.defer();
        let webRequest = new webClient.WebRequest();
        webRequest.method = "POST";
        webRequest.uri = this.authorityUrl + (this.isADFSEnabled ? "" : this.tenantId) + "/oauth2/token/";
        webRequest.body = querystring.stringify({
            resource: this.activeDirectoryResourceId,
            client_id: this.clientId,
            grant_type: "client_credentials",
            client_assertion: this._getSPNCertificateAuthorizationToken(),
            client_assertion_type: "urn:ietf:params:oauth:client-assertion-type:jwt-bearer"
        });
        let webRequestOptions = {
            retriableErrorCodes: null,
            retriableStatusCodes: [400, 408, 409, 429, 500, 502, 503, 504],
            retryCount: null,
            retryIntervalInSeconds: null,
            retryRequestTimedout: null
        };
        webClient.sendRequest(webRequest, webRequestOptions).then((response) => {
            if (response.statusCode == 200) {
                deferred.resolve(response.body.access_token);
            }
            else if ([400, 401, 403].indexOf(response.statusCode) != -1) {
                deferred.reject(tl.loc('ExpiredServicePrincipal'));
            }
            else {
                deferred.reject(tl.loc('CouldNotFetchAccessTokenforAzureStatusCode', response.statusCode, response.statusMessage));
            }
        }, (error) => {
            deferred.reject(error);
        });
        return deferred.promise;
    }
    /**
     * @deprecated ADAL related methods are deprecated and will be removed.
     * Use Use `getMSALToken(force?: boolean)` instead.
     */
    _getSPNAuthorizationTokenFromKey() {
        var deferred = Q.defer();
        let webRequest = new webClient.WebRequest();
        webRequest.method = "POST";
        webRequest.uri = this.authorityUrl + (this.isADFSEnabled ? "" : this.tenantId) + "/oauth2/token/";
        webRequest.body = querystring.stringify({
            resource: this.activeDirectoryResourceId,
            client_id: this.clientId,
            grant_type: "client_credentials",
            client_secret: this.secret
        });
        webRequest.headers = {
            "Content-Type": "application/x-www-form-urlencoded; charset=utf-8"
        };
        let webRequestOptions = {
            retriableErrorCodes: null,
            retriableStatusCodes: [400, 403, 408, 409, 429, 500, 502, 503, 504],
            retryCount: null,
            retryIntervalInSeconds: null,
            retryRequestTimedout: null
        };
        webClient.sendRequest(webRequest, webRequestOptions).then((response) => {
            if (response.statusCode == 200) {
                deferred.resolve(response.body.access_token);
            }
            else if ([400, 401, 403].indexOf(response.statusCode) != -1) {
                deferred.reject(tl.loc('ExpiredServicePrincipal'));
            }
            else {
                deferred.reject(tl.loc('CouldNotFetchAccessTokenforAzureStatusCode', response.statusCode, response.statusMessage));
            }
        }, (error) => {
            deferred.reject(error);
        });
        return deferred.promise;
    }
    getOpenSSLPath() {
        if (tl.osType().match(/^Win/)) {
            if (tl.getPipelineFeature("UseLatestOpenSSLInAzureArmRest")) {
                return tl.which(path.join(__dirname, 'openssl3.5.7', 'openssl'));
            }
            else {
                return tl.which(path.join(__dirname, 'openssl3.4.2', 'openssl'));
            }
        }
        else {
            return tl.which('openssl');
        }
    }
    /**
     * @deprecated ADAL related methods are deprecated and will be removed.
     * Use Use `getMSALToken(force?: boolean)` instead.
     */
    _getSPNCertificateAuthorizationToken() {
        var openSSLPath = this.getOpenSSLPath();
        var openSSLArgsArray = [
            "x509",
            "-sha1",
            "-noout",
            "-in",
            this.certFilePath,
            "-fingerprint"
        ];
        tl.debug(`The OpenSSL version is ${tl.execSync(openSSLPath, 'version')}`);
        var pemExecutionResult = tl.execSync(openSSLPath, openSSLArgsArray);
        var additionalHeaders = {
            "alg": "RS256",
            "typ": "JWT",
        };
        if (pemExecutionResult.code == 0) {
            tl.debug("FINGERPRINT CREATION SUCCESSFUL");
            let shaFingerprint = pemExecutionResult.stdout;
            let shaFingerPrintHashCode = shaFingerprint.split("=")[1].replace(new RegExp(":", 'g'), "");
            let fingerPrintHashBase64 = Buffer.from(shaFingerPrintHashCode.match(/\w{2}/g).map(function (a) {
                return String.fromCharCode(parseInt(a, 16));
            }).join(""), 'binary').toString('base64');
            additionalHeaders["x5t"] = fingerPrintHashBase64;
        }
        else {
            console.log(pemExecutionResult);
            throw new Error(pemExecutionResult.stderr);
        }
        return getJWT(this.authorityUrl, this.clientId, this.tenantId, this.certFilePath, additionalHeaders, this.isADFSEnabled);
    }
}
exports.ApplicationTokenCredentials = ApplicationTokenCredentials;
/**
 * @deprecated ADAL related methods are deprecated and will be removed.
 * Use Use `getMSALToken(force?: boolean)` instead.
 */
function getJWT(url, clientId, tenantId, pemFilePath, additionalHeaders, isADFSEnabled) {
    var pemFileContent = fs.readFileSync(pemFilePath);
    var jwtObject = {
        "aud": (`${url}/${!isADFSEnabled ? tenantId : ""}/oauth2/token`).replace(/([^:]\/)\/+/g, "$1"),
        "iss": clientId,
        "sub": clientId,
        "jti": "" + Math.random(),
        "nbf": (Math.floor(Date.now() / 1000) - 1000),
        "exp": (Math.floor(Date.now() / 1000) + 8640000)
    };
    var token = jwt.sign(jwtObject, pemFileContent, { algorithm: 'RS256', header: additionalHeaders });
    return token;
}
