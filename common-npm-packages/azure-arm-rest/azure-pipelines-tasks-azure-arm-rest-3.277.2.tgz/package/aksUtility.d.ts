export declare function getKubeConfigFromFleet(azureSubscriptionEndpoint: any, resourceGroup: any, fleetName: any): Promise<string>;
export declare function getKubeConfig(azureSubscriptionEndpoint: any, resourceGroup: any, clusterName: any, useClusterAdmin: any): Promise<string>;
export declare function getKubeConfigForFleet(azureSubscriptionEndpoint: any, resourceGroup: any, fleetName: any): Promise<string>;
