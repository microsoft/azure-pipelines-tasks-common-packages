"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Scheme = exports.ComputeResourceType = void 0;
var ComputeResourceType;
(function (ComputeResourceType) {
    ComputeResourceType[ComputeResourceType["VirtualMachine"] = 0] = "VirtualMachine";
    ComputeResourceType[ComputeResourceType["VirtualMachineScaleSet"] = 1] = "VirtualMachineScaleSet";
})(ComputeResourceType = exports.ComputeResourceType || (exports.ComputeResourceType = {}));
var Scheme;
(function (Scheme) {
    Scheme[Scheme["ManagedServiceIdentity"] = 0] = "ManagedServiceIdentity";
    Scheme[Scheme["SPN"] = 1] = "SPN";
    Scheme[Scheme["WorkloadIdentityFederation"] = 2] = "WorkloadIdentityFederation";
})(Scheme = exports.Scheme || (exports.Scheme = {}));
