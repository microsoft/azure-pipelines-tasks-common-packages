"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
const tl = require("azure-pipelines-task-lib/task");
const webClient = require("./webClient");
const path = require("path");
const HttpRedirectCodes = [301, 302, 307, 308];
tl.setResourcePath(path.join(__dirname, 'module.json'), true);
class WebRequestUtility {
    static getTargetUriFromFwdLink(fwdLink) {
        return __awaiter(this, void 0, void 0, function* () {
            tl.debug("Trying to fetch target link from the fwdlink: " + fwdLink);
            var httpRequest = new webClient.WebRequest();
            httpRequest.method = 'GET';
            httpRequest.uri = fwdLink;
            var httpResponse = yield webClient.sendRequest(httpRequest);
            if (HttpRedirectCodes.indexOf(httpResponse.statusCode) == -1) {
                throw new Error(tl.loc('ARG_RedirectResponseInvalidStatusCode', httpResponse.statusCode));
            }
            var targetLink = httpResponse.headers["location"];
            if (!targetLink) {
                throw new Error(tl.loc('ARG_RedirectResponseLocationHeaderIsNull', httpResponse.statusCode));
            }
            tl.debug("the target link is : " + targetLink);
            return targetLink;
        });
    }
}
module.exports = WebRequestUtility;
