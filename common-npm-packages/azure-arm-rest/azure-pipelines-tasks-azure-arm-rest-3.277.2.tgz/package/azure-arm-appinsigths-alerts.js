"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AzureMonitorAlerts = void 0;
const path = require("path");
const tl = require("azure-pipelines-task-lib/task");
const AzureServiceClient_1 = require("./AzureServiceClient");
const AzureServiceClientBase_1 = require("./AzureServiceClientBase");
const constants_1 = require("./constants");
const webClient = require("./webClient");
tl.setResourcePath(path.join(__dirname, 'module.json'), true);
class AzureMonitorAlerts {
    constructor(endpoint, resourceGroupName) {
        this._client = new AzureServiceClient_1.ServiceClient(endpoint.applicationTokenCredentials, endpoint.subscriptionID, 30);
        this._endpoint = endpoint;
        this._resourceGroupName = resourceGroupName;
    }
    get(alertRuleName) {
        return __awaiter(this, void 0, void 0, function* () {
            tl.debug(`Getting AzureRm alert rule - '${alertRuleName}' in resource group '${this._resourceGroupName}'`);
            var httpRequest = new webClient.WebRequest();
            httpRequest.method = 'GET';
            httpRequest.uri = this._client.getRequestUri(`//subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/microsoft.insights/alertrules/{resourceName}`, {
                '{resourceGroupName}': this._resourceGroupName,
                '{resourceName}': alertRuleName,
            }, null, constants_1.APIVersions.azure_arm_metric_alerts);
            try {
                var response = yield this._client.beginRequest(httpRequest);
                if (response.statusCode == 200) {
                    return response.body;
                }
                throw response;
            }
            catch (error) {
                throw Error(tl.loc('FailedToGetAzureMetricAlerts', alertRuleName, this._client.getFormattedError(error)));
            }
        });
    }
    update(alertRuleName, resourceBody) {
        return __awaiter(this, void 0, void 0, function* () {
            var httpRequest = new webClient.WebRequest();
            httpRequest.method = 'PUT';
            httpRequest.body = JSON.stringify(resourceBody);
            httpRequest.uri = this._client.getRequestUri(`//subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.insights/alertrules/{resourceName}`, {
                '{resourceGroupName}': this._resourceGroupName,
                '{resourceName}': alertRuleName,
            }, null, constants_1.APIVersions.azure_arm_metric_alerts);
            try {
                var response = yield this._client.beginRequest(httpRequest);
                if (response.statusCode == 200) {
                    console.log(tl.loc("UpdatedRule", alertRuleName));
                    return response.body;
                }
                else if (response.statusCode == 201) {
                    console.log(tl.loc("CreatedRule", alertRuleName));
                    return response.body;
                }
                throw (0, AzureServiceClientBase_1.ToError)(response);
            }
            catch (error) {
                throw Error(tl.loc('FailedToUpdateAzureMetricAlerts', alertRuleName, this._client.getFormattedError(error)));
            }
        });
    }
}
exports.AzureMonitorAlerts = AzureMonitorAlerts;
