"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ResourceGroupDeployments = exports.ResourceGroup = exports.Resources = exports.ResourceManagementClient = void 0;
const path = require("path");
const tl = require("azure-pipelines-task-lib/task");
const Q = require("q");
const azureServiceClient = require("./AzureServiceClient");
const azureServiceClientBase = require("./AzureServiceClientBase");
const depolymentsBase = require("./DeploymentsBase");
const webClient = require("./webClient");
tl.setResourcePath(path.join(__dirname, 'module.json'), true);
class ResourceManagementClient extends azureServiceClient.ServiceClient {
    constructor(credentials, resourceGroupName, subscriptionId, options) {
        super(credentials, subscriptionId);
        this.apiVersion = (credentials.isAzureStackEnvironment) ? '2016-06-01' : '2021-04-01';
        this.acceptLanguage = 'en-US';
        this.generateClientRequestId = true;
        if (!!options && !!options.longRunningOperationRetryTimeout) {
            this.longRunningOperationRetryTimeout = options.longRunningOperationRetryTimeout;
        }
        this.resourceGroupName = resourceGroupName;
        this.resourceGroup = new ResourceGroup(this);
        this.deployments = new ResourceGroupDeployments(this);
    }
}
exports.ResourceManagementClient = ResourceManagementClient;
class Resources {
    constructor(endpoint) {
        this._client = new azureServiceClient.ServiceClient(endpoint.applicationTokenCredentials, endpoint.subscriptionID, 30);
    }
    getResources(resourceType, resourceName) {
        return __awaiter(this, void 0, void 0, function* () {
            var httpRequest = new webClient.WebRequest();
            httpRequest.method = 'GET';
            httpRequest.uri = this._client.getRequestUri('//subscriptions/{subscriptionId}/resources', {}, [`$filter=resourceType EQ \'${encodeURIComponent(resourceType)}\' AND name EQ \'${encodeURIComponent(resourceName)}\'`], '2016-07-01');
            var result = [];
            try {
                var response = yield this._client.beginRequest(httpRequest);
                if (response.statusCode != 200) {
                    throw azureServiceClientBase.ToError(response);
                }
                result = result.concat(response.body.value);
                if (response.body.nextLink) {
                    var nextResult = yield this._client.accumulateResultFromPagedResult(response.body.nextLink);
                    if (nextResult.error) {
                        throw Error(nextResult.error);
                    }
                    result = result.concat(nextResult.result);
                }
                return result;
            }
            catch (error) {
                throw Error(tl.loc('FailedToGetResourceID', resourceType, resourceName, this._client.getFormattedError(error)));
            }
        });
    }
    getAppDetails(resourceName) {
        return __awaiter(this, void 0, void 0, function* () {
            var filteredResources = yield this.getResources('Microsoft.Web/Sites', resourceName);
            let resourceGroupName;
            let kind;
            if (!filteredResources || filteredResources.length == 0) {
                throw new Error(tl.loc('ResourceDoesntExist', resourceName));
            }
            else if (filteredResources.length == 1) {
                resourceGroupName = filteredResources[0].id.split("/")[4];
                kind = filteredResources[0].kind;
            }
            else {
                throw new Error(tl.loc('MultipleResourceGroupFoundForAppService', resourceName));
            }
            return {
                resourceGroupName: resourceGroupName,
                kind: kind
            };
        });
    }
}
exports.Resources = Resources;
class ResourceGroup {
    constructor(armClient) {
        this.client = armClient;
    }
    checkExistence(callback) {
        if (!callback) {
            throw new Error(tl.loc("CallbackCannotBeNull"));
        }
        // Validate
        try {
            this.client.isValidResourceGroupName(this.client.resourceGroupName);
        }
        catch (error) {
            return callback(error);
        }
        // Create HTTP transport objects
        var httpRequest = new webClient.WebRequest();
        httpRequest.method = 'HEAD';
        httpRequest.uri = this.client.getRequestUri('//subscriptions/{subscriptionId}/resourcegroups/{resourceGroupName}', {
            '{resourceGroupName}': this.client.resourceGroupName
        });
        // Send Request and process response.
        this.client.beginRequest(httpRequest).then((response) => {
            var deferred = Q.defer();
            if (response.statusCode == 204 || response.statusCode == 404) {
                deferred.resolve(new azureServiceClientBase.ApiResult(null, response.statusCode == 204));
            }
            else {
                deferred.resolve(new azureServiceClientBase.ApiResult(azureServiceClientBase.ToError(response)));
            }
            return deferred.promise;
        }).then((apiResult) => callback(apiResult.error, apiResult.result), (error) => callback(error));
    }
    deleteMethod(callback) {
        var client = this.client;
        if (!callback) {
            throw new Error(tl.loc("CallbackCannotBeNull"));
        }
        // Validate
        try {
            this.client.isValidResourceGroupName(this.client.resourceGroupName);
        }
        catch (error) {
            return callback(error);
        }
        // Create HTTP transport objects
        var httpRequest = new webClient.WebRequest();
        httpRequest.method = 'DELETE';
        httpRequest.uri = this.client.getRequestUri('//subscriptions/{subscriptionId}/resourcegroups/{resourceGroupName}', {
            '{resourceGroupName}': this.client.resourceGroupName
        });
        this.client.beginRequest(httpRequest).then((response) => {
            var deferred = Q.defer();
            var statusCode = response.statusCode;
            if (statusCode !== 202 && statusCode !== 200) {
                deferred.resolve(new azureServiceClientBase.ApiResult(azureServiceClientBase.ToError(response)));
            }
            else {
                // Create Result
                this.client.getLongRunningOperationResult(response).then((response) => {
                    if (response.statusCode == 200) {
                        deferred.resolve(new azureServiceClientBase.ApiResult(null, response.body));
                    }
                    else {
                        deferred.resolve(new azureServiceClientBase.ApiResult(azureServiceClientBase.ToError(response)));
                    }
                }, (error) => deferred.reject(error));
            }
            return deferred.promise;
        }).then((apiResult) => callback(apiResult.error, apiResult.result), (error) => callback(error));
    }
    createOrUpdate(parameters, callback) {
        if (!callback) {
            throw new Error(tl.loc("CallbackCannotBeNull"));
        }
        // Validate
        try {
            this.client.isValidResourceGroupName(this.client.resourceGroupName);
            if (parameters === null || parameters === undefined) {
                throw new Error(tl.loc("ParametersCannotBeNull"));
            }
        }
        catch (error) {
            return callback(error);
        }
        // Create HTTP transport objects
        var httpRequest = new webClient.WebRequest();
        httpRequest.method = 'PUT';
        httpRequest.headers = {};
        httpRequest.uri = this.client.getRequestUri('//subscriptions/{subscriptionId}/resourcegroups/{resourceGroupName}', {
            '{resourceGroupName}': this.client.resourceGroupName,
        });
        // Serialize Request
        if (parameters !== null && parameters !== undefined) {
            httpRequest.body = JSON.stringify(parameters);
        }
        // Send Request
        this.client.beginRequest(httpRequest).then((response) => {
            var deferred = Q.defer();
            var statusCode = response.statusCode;
            if (statusCode !== 200 && statusCode !== 201) {
                deferred.resolve(new azureServiceClientBase.ApiResult(azureServiceClientBase.ToError(response)));
            }
            else {
                deferred.resolve(new azureServiceClientBase.ApiResult(null, response.body));
            }
            return deferred.promise;
        }).then((apiResult) => callback(apiResult.error, apiResult.result), (error) => callback(error));
    }
}
exports.ResourceGroup = ResourceGroup;
class ResourceGroupDeployments extends depolymentsBase.DeploymentsBase {
    constructor(client) {
        super(client);
        this.client = client;
    }
    createOrUpdate(deploymentName, deploymentParameters, callback) {
        if (!callback) {
            throw new Error(tl.loc("CallbackCannotBeNull"));
        }
        // Validate
        try {
            this.client.isValidResourceGroupName(this.client.resourceGroupName);
        }
        catch (error) {
            return callback(error);
        }
        // Create HTTP request uri
        var requestUri = this.client.getRequestUri('//subscriptions/{subscriptionId}/resourcegroups/{resourceGroupName}/providers/Microsoft.Resources/deployments/{deploymentName}', {
            '{resourceGroupName}': this.client.resourceGroupName,
            '{deploymentName}': deploymentName
        });
        super.deployTemplate(requestUri, deploymentName, deploymentParameters, callback);
    }
    validate(deploymentName, deploymentParameters, callback) {
        if (!callback) {
            throw new Error(tl.loc("CallbackCannotBeNull"));
        }
        // Validate
        try {
            this.client.isValidResourceGroupName(this.client.resourceGroupName);
        }
        catch (error) {
            return callback(error);
        }
        // Create HTTP request uri
        var requestUri = this.client.getRequestUri('//subscriptions/{subscriptionId}/resourcegroups/{resourceGroupName}/providers/Microsoft.Resources/deployments/{deploymentName}/validate', {
            '{resourceGroupName}': this.client.resourceGroupName,
            '{deploymentName}': deploymentName
        });
        super.validateTemplate(requestUri, deploymentName, deploymentParameters, callback);
    }
}
exports.ResourceGroupDeployments = ResourceGroupDeployments;
