import Q = require('q');
export declare class ApplicationTokenCredentials {
    baseUrl: string;
    authorityUrl: string;
    activeDirectoryResourceId: string;
    isAzureStackEnvironment: boolean;
    scheme: number;
    msiClientId: string;
    private connectedServiceName;
    private clientId;
    private tenantId;
    private authType;
    private secret?;
    private accessToken?;
    private certFilePath?;
    private isADFSEnabled?;
    private token_deferred;
    private useMSAL;
    private msalInstance;
    private scopes;
    private allowScopeLevelToken;
    private readonly tokenMutex;
    constructor(connectedServiceName: string, clientId: string, tenantId: string, secret: string, baseUrl: string, authorityUrl: string, activeDirectoryResourceId: string, isAzureStackEnvironment: boolean, scheme?: string, msiClientId?: string, authType?: string, certFilePath?: string, isADFSEnabled?: boolean, access_token?: string, useMSAL?: boolean, allowScopeLevelToken?: boolean, scopes?: any);
    /**
     * @deprecated ADAL related methods are deprecated and will be removed.
     * Use Use `getMSALToken(force?: boolean)` instead.
     */
    static getMSIAuthorizationToken(retyCount: number, timeToWait: number, baseUrl: string, msiClientId?: string): Q.Promise<string>;
    getTenantId(): string;
    getClientId(): string;
    getUseMSAL(): boolean;
    getToken(force?: boolean): Promise<string>;
    private static initOIDCToken;
    private static getSystemAccessToken;
    private getMSAL;
    private getProxyClient;
    private buildMSAL;
    private configureMSALWithMSI;
    private configureMSALWithSP;
    getFederatedToken(): Promise<string>;
    private configureMSALWithOIDC;
    private getMSALToken;
    acquireTokenForScope(scopeKind: string): Promise<string>;
    private buildCredentialByScheme;
    /**
     * @deprecated ADAL related methods are deprecated and will be removed.
     * Use Use `getMSALToken(force?: boolean)` instead.
     */
    private getADALToken;
    /**
     * @deprecated ADAL related methods are deprecated and will be removed.
     * Use Use `getMSALToken(force?: boolean)` instead.
     */
    private _getSPNAuthorizationToken;
    /**
     * @deprecated ADAL related methods are deprecated and will be removed.
     * Use Use `getMSALToken(force?: boolean)` instead.
     */
    private _getSPNAuthorizationTokenFromCertificate;
    /**
     * @deprecated ADAL related methods are deprecated and will be removed.
     * Use Use `getMSALToken(force?: boolean)` instead.
     */
    private _getSPNAuthorizationTokenFromKey;
    getOpenSSLPath(): string;
    /**
     * @deprecated ADAL related methods are deprecated and will be removed.
     * Use Use `getMSALToken(force?: boolean)` instead.
     */
    private _getSPNCertificateAuthorizationToken;
}
