"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AzureServiceClientBase = exports.ToError = exports.AzureError = exports.ApiResult = void 0;
const path = require("path");
const tl = require("azure-pipelines-task-lib/task");
const webClient = require("./webClient");
tl.setResourcePath(path.join(__dirname, 'module.json'), true);
const CorrelationIdInResponse = "x-ms-correlation-request-id";
class ApiResult {
    constructor(error, result, request, response) {
        this.error = error;
        this.result = result;
        this.request = request;
        this.response = response;
    }
}
exports.ApiResult = ApiResult;
class AzureError {
}
exports.AzureError = AzureError;
function ToError(response) {
    var error = new AzureError();
    error.statusCode = response.statusCode;
    error.message = response.body;
    if (response.body && response.body.error) {
        error.code = response.body.error.code;
        error.message = response.body.error.message;
        error.details = response.body.error.details;
        console.log("##vso[task.logissue type=error;code=" + error.code + ";]");
    }
    return error;
}
exports.ToError = ToError;
class AzureServiceClientBase {
    constructor(credentials, timeout) {
        this.validateCredentials(credentials);
        this.credentials = credentials;
        this.baseUri = this.credentials.baseUrl;
        this.longRunningOperationRetryTimeout = !!timeout ? timeout : 0; // In minutes
    }
    getCredentials() {
        return this.credentials;
    }
    getRequestUriForBaseUri(baseUri, uriFormat, parameters, queryParameters, apiVersion) {
        var requestUri = baseUri + uriFormat;
        for (var key in parameters) {
            requestUri = requestUri.replace(key, encodeURIComponent(parameters[key]));
        }
        // trim all duplicate forward slashes in the url
        var regex = /([^:]\/)\/+/gi;
        requestUri = requestUri.replace(regex, '$1');
        // process query paramerters
        queryParameters = queryParameters || [];
        const currentApiVersion = apiVersion || this.apiVersion;
        if (currentApiVersion) {
            queryParameters.push('api-version=' + encodeURIComponent(currentApiVersion));
        }
        if (queryParameters.length > 0) {
            requestUri += '?' + queryParameters.join('&');
        }
        return requestUri;
    }
    setCustomHeaders(options) {
        var headers = {};
        if (options) {
            for (var headerName in options['customHeaders']) {
                if (options['customHeaders'].hasOwnProperty(headerName)) {
                    headers[headerName] = options['customHeaders'][headerName];
                }
            }
        }
        return headers;
    }
    beginRequest(request) {
        return __awaiter(this, void 0, void 0, function* () {
            var token = yield this.credentials.getToken();
            request.headers = request.headers || {};
            request.headers["Authorization"] = "Bearer " + token;
            if (this.acceptLanguage) {
                request.headers['accept-language'] = this.acceptLanguage;
            }
            request.headers['Content-Type'] = 'application/json; charset=utf-8';
            var httpResponse = null;
            try {
                httpResponse = yield webClient.sendRequest(request);
                if (httpResponse.statusCode === 401 && httpResponse.body && httpResponse.body.error && httpResponse.body.error.code === "ExpiredAuthenticationToken") {
                    // The access token might have expire. Re-issue the request after refreshing the token.
                    token = yield this.credentials.getToken(true);
                    request.headers["Authorization"] = "Bearer " + token;
                    httpResponse = yield webClient.sendRequest(request);
                }
                if (!!httpResponse.headers[CorrelationIdInResponse]) {
                    tl.debug(`Correlation ID from ARM api call response : ${httpResponse.headers[CorrelationIdInResponse]}`);
                }
            }
            catch (exception) {
                let exceptionString = exception.toString();
                if (exceptionString.indexOf("Hostname/IP doesn't match certificates's altnames") != -1
                    || exceptionString.indexOf("unable to verify the first certificate") != -1
                    || exceptionString.indexOf("unable to get local issuer certificate") != -1) {
                    tl.warning(tl.loc('ASE_SSLIssueRecommendation'));
                }
                throw exception;
            }
            if (httpResponse.headers["azure-asyncoperation"] || httpResponse.headers["location"])
                tl.debug(request.uri + " ==> " + httpResponse.headers["azure-asyncoperation"] || httpResponse.headers["location"]);
            return httpResponse;
        });
    }
    getLongRunningOperationResult(response, timeoutInMinutes) {
        return __awaiter(this, void 0, void 0, function* () {
            timeoutInMinutes = timeoutInMinutes || this.longRunningOperationRetryTimeout;
            var timeout = new Date().getTime() + timeoutInMinutes * 60 * 1000;
            var waitIndefinitely = timeoutInMinutes == 0;
            var ignoreTimeoutErrorThreshold = 5;
            var request = new webClient.WebRequest();
            request.method = "GET";
            request.uri = response.headers["azure-asyncoperation"] || response.headers["location"];
            if (!request.uri) {
                throw new Error(tl.loc("InvalidResponseLongRunningOperation"));
            }
            while (true) {
                try {
                    response = yield this.beginRequest(request);
                    tl.debug(`Response status code : ${response.statusCode}`);
                    if (response.statusCode === 202 || (response.body && (response.body.status == "Accepted" || response.body.status == "Running" || response.body.status == "InProgress" || response.body.status == "DeploymentNotFound"))) {
                        if (response.body && response.body.status) {
                            tl.debug(`Response status : ${response.body.status}`);
                        }
                        // If timeout; throw;
                        if (!waitIndefinitely && timeout < new Date().getTime()) {
                            throw new Error(tl.loc("TimeoutWhileWaiting"));
                        }
                        // Retry after given interval.
                        var sleepDuration = 15;
                        if (response.headers["retry-after"]) {
                            sleepDuration = parseInt(response.headers["retry-after"]);
                        }
                        yield this.sleepFor(sleepDuration);
                    }
                    else {
                        break;
                    }
                }
                catch (error) {
                    let errorString = (!!error && error.toString()) || "";
                    if (!!errorString && errorString.toLowerCase().indexOf("request timeout") >= 0 && ignoreTimeoutErrorThreshold > 0) {
                        // Ignore Request Timeout error and continue polling operation
                        tl.debug(`Request Timeout: ${request.uri}`);
                        ignoreTimeoutErrorThreshold--;
                    }
                    else {
                        throw error;
                    }
                }
            }
            return response;
        });
    }
    beginRequestExpBackoff(request, maxAttempt) {
        return __awaiter(this, void 0, void 0, function* () {
            var sleepDuration = 1;
            for (var i = 1; true; i++) {
                var response = yield this.beginRequest(request);
                //not a server error;
                if (response.statusCode < 500) {
                    return response;
                }
                // response of last attempt
                if (i == maxAttempt) {
                    return response;
                }
                // Retry after given interval.
                sleepDuration = sleepDuration + i;
                if (response.headers["retry-after"]) {
                    sleepDuration = parseInt(response.headers["retry-after"]);
                }
                tl.debug(tl.loc("RetryingRequest", sleepDuration));
                yield this.sleepFor(sleepDuration);
            }
        });
    }
    accumulateResultFromPagedResult(nextLinkUrl) {
        return __awaiter(this, void 0, void 0, function* () {
            var result = [];
            while (nextLinkUrl) {
                var nextRequest = new webClient.WebRequest();
                nextRequest.method = 'GET';
                nextRequest.uri = nextLinkUrl;
                var response = yield this.beginRequest(nextRequest);
                if (response.statusCode == 200 && response.body) {
                    if (response.body.value) {
                        result = result.concat(response.body.value);
                    }
                    nextLinkUrl = response.body.nextLink;
                }
                else {
                    return new ApiResult(ToError(response));
                }
            }
            return new ApiResult(null, result);
        });
    }
    isNameValid(name) {
        if (name === null || name === undefined || typeof name.valueOf() !== 'string') {
            return false;
        }
        else {
            return true;
        }
    }
    getFormattedError(error) {
        if (error && error.message) {
            if (error.statusCode) {
                var errorMessage = typeof error.message.valueOf() == 'string' ? error.message
                    : (error.message.Code || error.message.code) + " - " + (error.message.Message || error.message.message);
                error.message = `${errorMessage} (CODE: ${error.statusCode})`;
            }
            return error.message;
        }
        return error;
    }
    validateCredentials(credentials) {
        if (!credentials) {
            throw new Error(tl.loc("CredentialsCannotBeNull"));
        }
    }
    getRequestUri(uriFormat, parameters, queryParameters, apiVersion) {
        return this.getRequestUriForBaseUri(this.baseUri, uriFormat, parameters, queryParameters, apiVersion);
    }
    sleepFor(sleepDurationInSeconds) {
        return new Promise((resolve, reeject) => {
            setTimeout(resolve, sleepDurationInSeconds * 1000);
        });
    }
}
exports.AzureServiceClientBase = AzureServiceClientBase;
