"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ManagementGroupDeployments = exports.ManagementGroupManagementClient = void 0;
const path = require("path");
const tl = require("azure-pipelines-task-lib/task");
const azureServiceClientBase = require("./AzureServiceClientBase");
const depolymentsBase = require("./DeploymentsBase");
tl.setResourcePath(path.join(__dirname, 'module.json'), true);
class ManagementGroupManagementClient extends azureServiceClientBase.AzureServiceClientBase {
    constructor(credentials, managementGroupId, options) {
        super(credentials);
        this.validateInputs(managementGroupId);
        this.apiVersion = (credentials.isAzureStackEnvironment) ? '2019-10-01' : '2021-04-01';
        this.acceptLanguage = 'en-US';
        this.generateClientRequestId = true;
        if (!!options && !!options.longRunningOperationRetryTimeout) {
            this.longRunningOperationRetryTimeout = options.longRunningOperationRetryTimeout;
        }
        this.deployments = new ManagementGroupDeployments(this);
        this.managementGroupId = managementGroupId;
    }
    getRequestUri(uriFormat, parameters, queryParameters, apiVersion) {
        parameters['{managementGroupId}'] = encodeURIComponent(this.managementGroupId);
        return super.getRequestUriForBaseUri(this.baseUri, uriFormat, parameters, queryParameters, apiVersion);
    }
    validateInputs(managementGroupId) {
        if (!managementGroupId) {
            throw new Error(tl.loc("ManagementGroupIdCannotBeNull"));
        }
    }
}
exports.ManagementGroupManagementClient = ManagementGroupManagementClient;
class ManagementGroupDeployments extends depolymentsBase.DeploymentsBase {
    constructor(client) {
        super(client);
        this.client = client;
    }
    createOrUpdate(deploymentName, deploymentParameters, callback) {
        // Create HTTP request uri
        var requestUri = this.client.getRequestUri('//providers/Microsoft.Management/managementGroups/{managementGroupId}/providers/Microsoft.Resources/deployments/{deploymentName}', {
            '{deploymentName}': deploymentName
        });
        super.deployTemplate(requestUri, deploymentName, deploymentParameters, callback);
    }
    validate(deploymentName, deploymentParameters, callback) {
        // Create HTTP request uri
        var requestUri = this.client.getRequestUri('//providers/Microsoft.Management/managementGroups/{managementGroupId}/providers/Microsoft.Resources/deployments/{deploymentName}/validate', {
            '{deploymentName}': deploymentName
        });
        super.validateTemplate(requestUri, deploymentName, deploymentParameters, callback);
    }
}
exports.ManagementGroupDeployments = ManagementGroupDeployments;
