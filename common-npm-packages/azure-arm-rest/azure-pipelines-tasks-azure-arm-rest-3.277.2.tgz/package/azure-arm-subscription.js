"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SubscriptionDeployments = exports.SubscriptionManagementClient = void 0;
const path = require("path");
const tl = require("azure-pipelines-task-lib/task");
const azureServiceClientBase = require("./AzureServiceClientBase");
const depolymentsBase = require("./DeploymentsBase");
tl.setResourcePath(path.join(__dirname, 'module.json'), true);
class SubscriptionManagementClient extends azureServiceClientBase.AzureServiceClientBase {
    constructor(credentials, subscriptionId, options) {
        super(credentials);
        this.validateInputs(subscriptionId);
        this.apiVersion = (credentials.isAzureStackEnvironment) ? '2019-10-01' : '2021-04-01';
        this.acceptLanguage = 'en-US';
        this.generateClientRequestId = true;
        if (!!options && !!options.longRunningOperationRetryTimeout) {
            this.longRunningOperationRetryTimeout = options.longRunningOperationRetryTimeout;
        }
        this.deployments = new SubscriptionDeployments(this);
        this.subscriptionId = subscriptionId;
    }
    getRequestUri(uriFormat, parameters, queryParameters, apiVersion) {
        parameters['{subscriptionId}'] = encodeURIComponent(this.subscriptionId);
        return super.getRequestUriForBaseUri(this.baseUri, uriFormat, parameters, queryParameters, apiVersion);
    }
    validateInputs(subscriptionId) {
        if (!subscriptionId) {
            throw new Error(tl.loc("SubscriptionIdCannotBeNull"));
        }
    }
}
exports.SubscriptionManagementClient = SubscriptionManagementClient;
class SubscriptionDeployments extends depolymentsBase.DeploymentsBase {
    constructor(client) {
        super(client);
        this.client = client;
    }
    createOrUpdate(deploymentParameters, parameters, callback) {
        // Create HTTP request uri
        var uri = this.client.getRequestUri('//subscriptions/{subscriptionId}/providers/Microsoft.Resources/deployments/{deploymentName}', {
            '{deploymentName}': deploymentParameters
        });
        super.deployTemplate(uri, deploymentParameters, parameters, callback);
    }
    validate(deploymentParameters, parameters, callback) {
        // Create HTTP request uri
        var uri = this.client.getRequestUri('//subscriptions/{subscriptionId}/providers/Microsoft.Resources/deployments/{deploymentName}/validate', {
            '{deploymentName}': deploymentParameters
        });
        super.validateTemplate(uri, deploymentParameters, parameters, callback);
    }
}
exports.SubscriptionDeployments = SubscriptionDeployments;
