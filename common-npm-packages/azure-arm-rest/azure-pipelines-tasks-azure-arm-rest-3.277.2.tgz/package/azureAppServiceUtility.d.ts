import { AzureAppService } from './azure-arm-app-service';
import { Kudu } from './azure-arm-app-service-kudu';
import { SiteContainer } from './SiteContainer';
export declare class AzureAppServiceUtility {
    private readonly _appService;
    private readonly _telemetryFeature;
    constructor(appService: AzureAppService, telemetryFeature?: string);
    getWebDeployPublishingProfile(): Promise<any>;
    getApplicationURL(virtualApplication?: string): Promise<string>;
    pingApplication(): Promise<void>;
    getPhysicalPath(virtualApplication: string): Promise<string>;
    /**
     * Gets a Kudu service client for deployments.
     * @param warmupInstanceId Optional instance ID for SPN auth to pin all requests to a single instance (ARRAffinity cookie)
     */
    getKuduService(warmupInstanceId?: string): Promise<Kudu>;
    private getKuduAuthHeader;
    updateAndMonitorAppSettings(addProperties?: any, deleteProperties?: any, formatJSON?: boolean, perSlot?: boolean): Promise<boolean>;
    enableRenameLockedFiles(): Promise<void>;
    updateStartupCommandAndRuntimeStack(runtimeStack: string, startupCommand?: string): Promise<void>;
    isSitePublishingCredentialsEnabled(): Promise<boolean>;
    isFunctionAppOnCentauri(): Promise<boolean>;
    updateSiteContainer(siteContainer: SiteContainer): Promise<void>;
    private filterProperties;
    getAppserviceInstances(): Promise<any>;
}
