"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ApplicationInsightsWebTests = void 0;
const path = require("path");
const tl = require("azure-pipelines-task-lib/task");
const AzureServiceClient_1 = require("./AzureServiceClient");
const AzureServiceClientBase_1 = require("./AzureServiceClientBase");
const webClient = require("./webClient");
tl.setResourcePath(path.join(__dirname, 'module.json'), true);
class ApplicationInsightsWebTests {
    constructor(endpoint, resourceGroup) {
        this._client = new AzureServiceClient_1.ServiceClient(endpoint.applicationTokenCredentials, endpoint.subscriptionID, 30);
        this._resourceGroupName = resourceGroup;
    }
    list() {
        return __awaiter(this, void 0, void 0, function* () {
            let httpRequest = new webClient.WebRequest();
            httpRequest.method = 'GET';
            httpRequest.uri = this._client.getRequestUri(`//subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/microsoft.insights/webtests`, {
                '{resourceGroupName}': this._resourceGroupName
            }, null, '2015-05-01');
            let result = [];
            try {
                let response = yield this._client.beginRequest(httpRequest);
                if (response.statusCode != 200) {
                    throw (0, AzureServiceClientBase_1.ToError)(response);
                }
                result = result.concat(response.body.value);
                if (response.body.nextLink) {
                    let nextResult = yield this._client.accumulateResultFromPagedResult(response.body.nextLink);
                    if (nextResult.error) {
                        throw (0, AzureServiceClientBase_1.ToError)(nextResult.error);
                    }
                    result = result.concat(nextResult.result);
                }
                tl.debug(`retrieved list of tests for ${this._resourceGroupName}.`);
                return result;
            }
            catch (error) {
                throw Error(tl.loc('FailedToGetApplicationInsightsWebTestsForResourceGroup', this._resourceGroupName, this._client.getFormattedError(error)));
            }
        });
    }
    create(webTestData) {
        return __awaiter(this, void 0, void 0, function* () {
            let httpRequest = new webClient.WebRequest();
            httpRequest.method = 'PUT';
            httpRequest.body = JSON.stringify(webTestData);
            httpRequest.uri = this._client.getRequestUri(`//subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/microsoft.insights/webtests/{webTestName}`, {
                '{resourceGroupName}': this._resourceGroupName,
                '{webTestName}': webTestData.name
            }, null, '2015-05-01');
            try {
                let response = yield this._client.beginRequest(httpRequest);
                if (response.statusCode != 200 && response.statusCode != 201) {
                    throw (0, AzureServiceClientBase_1.ToError)(response);
                }
                tl.debug(`added web test ${response.body.name}.`);
                return response.body;
            }
            catch (error) {
                throw Error(tl.loc("FailedToCreateWebTests", this._client.getFormattedError(error)));
            }
        });
    }
}
exports.ApplicationInsightsWebTests = ApplicationInsightsWebTests;
