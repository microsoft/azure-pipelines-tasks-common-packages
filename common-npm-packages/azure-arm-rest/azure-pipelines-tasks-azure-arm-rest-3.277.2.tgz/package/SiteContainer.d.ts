export declare enum AUTH_TYPE {
    ANONYMOUS = "Anonymous",
    USERCREDENTIALS = "UserCredentials",
    SYSTEM_IDENTITY = "SystemIdentity",
    USER_ASSIGNED = "UserAssigned"
}
export declare class EnvironmentVariable {
    private name;
    private value;
    constructor(name: string, value: string);
    getName(): string;
    getValue(): string;
    setName(name: string): void;
    setValue(value: string): void;
    static fromJson(item: any): EnvironmentVariable;
    static toJson(envVar: EnvironmentVariable): any;
}
export declare class VolumeMount {
    private containerMountPath;
    private volumeSubPath;
    private readOnly?;
    constructor(containerMountPath: string, volumeSubPath: string, readOnly?: boolean);
    getContainerMountPath(): string;
    getVolumeSubPath(): string;
    getReadOnly(): boolean | undefined;
    setContainerMountPath(containerMountPath: string): void;
    setVolumeSubPath(volumeSubPath: string): void;
    setReadOnly(readOnly: boolean): void;
    static fromJson(item: any): VolumeMount;
    static toJson(volumeMount: VolumeMount): any;
}
export declare class SiteContainer {
    private name;
    private image;
    private isMain;
    private targetPort?;
    private startupCommand?;
    private authType?;
    private userName?;
    private passwordSecret?;
    private userManagedIdentityClientId?;
    private environmentVariables?;
    private volumeMounts?;
    private inheritAppSettingsAndConnectionStrings?;
    constructor(name: string, image: string, isMain: boolean, targetPort?: string, startupCommand?: string, authType?: AUTH_TYPE, userName?: string, passwordSecret?: string, userManagedIdentityClientId?: string, environmentVariables?: EnvironmentVariable[], volumeMounts?: VolumeMount[], inheritAppSettingsAndConnectionStrings?: boolean);
    getName(): string;
    getImage(): string;
    getIsMain(): boolean;
    getTargetPort(): string | undefined;
    getStartupCommand(): string | undefined;
    getAuthType(): AUTH_TYPE | undefined;
    getUserName(): string | undefined;
    getPasswordSecret(): string | undefined;
    getUserManagedIdentityClientId(): string | undefined;
    getEnvironmentVariables(): EnvironmentVariable[] | undefined;
    getVolumeMounts(): VolumeMount[] | undefined;
    getInheritAppSettingsAndConnectionStrings(): boolean | undefined;
    setName(name: string): void;
    setImage(image: string): void;
    setIsMain(isMain: boolean): void;
    setTargetPort(targetPort: string): void;
    setStartupCommand(startupCommand: string): void;
    setAuthType(authType: AUTH_TYPE): void;
    setUserName(userName: string): void;
    setPasswordSecret(passwordSecret: string): void;
    setUserManagedIdentityClientId(userManagedIdentityClientId: string): void;
    setEnvironmentVariables(environmentVariables: EnvironmentVariable[]): void;
    setVolumeMounts(volumeMounts: VolumeMount[]): void;
    setInheritAppSettingsAndConnectionStrings(inheritAppSettingsAndConnectionStrings: boolean): void;
    static fromJson(item: any): SiteContainer;
}
