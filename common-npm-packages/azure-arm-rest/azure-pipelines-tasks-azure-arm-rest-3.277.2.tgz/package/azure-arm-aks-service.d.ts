import Model = require("./azureModels");
import { AzureEndpoint } from './azureModels';
import { ServiceClient } from './AzureServiceClient';
import webClient = require('./webClient');
export declare class AzureAksService {
    _client: ServiceClient;
    constructor(endpoint: AzureEndpoint);
    beginRequest(uri: string, parameters: {}, apiVersion: string, method: string): Promise<webClient.WebResponse>;
    getAccessProfile(resourceGroup: string, clusterName: string, useClusterAdmin?: boolean): Promise<Model.AKSClusterAccessProfile>;
    private createFleetParameters;
    private createManagedClusterParameters;
    getCredentials(resourceGroup: string, name: string, uri: string, parameters: any, apiVersion: string): Promise<Model.AKSCredentialResults>;
    getClusterCredential(resourceGroup: string, name: string, useClusterAdmin?: boolean, credentialName?: string): Promise<Model.AKSCredentialResult>;
    getFleetCredential(resourceGroup: string, name: string): Promise<Model.AKSCredentialResult>;
}
