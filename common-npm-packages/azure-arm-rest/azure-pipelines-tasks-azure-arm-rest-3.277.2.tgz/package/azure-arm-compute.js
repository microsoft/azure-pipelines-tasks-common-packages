"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getComputeResourceTypeString = exports.VirtualMachineScaleSets = exports.VirtualMachineExtensions = exports.VirtualMachines = exports.ComputeManagementClient = void 0;
const path = require("path");
const tl = require("azure-pipelines-task-lib/task");
const Q = require("q");
const Model = require("./azureModels");
const azureServiceClient = require("./AzureServiceClient");
const azureServiceClientBase = require("./AzureServiceClientBase");
const webClient = require("./webClient");
tl.setResourcePath(path.join(__dirname, 'module.json'), true);
class ComputeManagementClient extends azureServiceClient.ServiceClient {
    constructor(credentials, subscriptionId, baseUri, options) {
        super(credentials, subscriptionId);
        this.acceptLanguage = 'en-US';
        this.generateClientRequestId = true;
        this.apiVersion = (credentials.isAzureStackEnvironment) ? '2015-06-15' : '2016-03-30';
        if (!options)
            options = {};
        if (baseUri) {
            this.baseUri = baseUri;
        }
        if (options.acceptLanguage) {
            this.acceptLanguage = options.acceptLanguage;
        }
        if (options.longRunningOperationRetryTimeout) {
            this.longRunningOperationRetryTimeout = options.longRunningOperationRetryTimeout;
        }
        if (options.generateClientRequestId) {
            this.generateClientRequestId = options.generateClientRequestId;
        }
        this.virtualMachines = new VirtualMachines(this);
        this.virtualMachineExtensions = new VirtualMachineExtensions(this);
        this.virtualMachineScaleSets = new VirtualMachineScaleSets(this);
    }
}
exports.ComputeManagementClient = ComputeManagementClient;
class VirtualMachines {
    constructor(client) {
        this.client = client;
    }
    list(resourceGroupName, options, callback) {
        if (!callback && typeof options === 'function') {
            callback = options;
            options = null;
        }
        if (!callback) {
            throw new Error(tl.loc("CallbackCannotBeNull"));
        }
        // Validate
        try {
            this.client.isValidResourceGroupName(resourceGroupName);
        }
        catch (error) {
            return callback(error);
        }
        var httpRequest = new webClient.WebRequest();
        httpRequest.method = 'GET';
        httpRequest.headers = this.client.setCustomHeaders(options);
        httpRequest.uri = this.client.getRequestUri('//subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.Compute/virtualMachines', {
            '{resourceGroupName}': resourceGroupName
        });
        var result = [];
        this.client.beginRequest(httpRequest).then((response) => __awaiter(this, void 0, void 0, function* () {
            if (response.statusCode == 200) {
                if (response.body.value) {
                    result = result.concat(response.body.value);
                }
                if (response.body.nextLink) {
                    var nextResult = yield this.client.accumulateResultFromPagedResult(response.body.nextLink);
                    if (nextResult.error) {
                        return new azureServiceClientBase.ApiResult(nextResult.error);
                    }
                    result = result.concat(nextResult.result);
                }
                return new azureServiceClientBase.ApiResult(null, result);
            }
            else {
                return new azureServiceClientBase.ApiResult(azureServiceClientBase.ToError(response));
            }
        })).then((apiResult) => callback(apiResult.error, apiResult.result), (error) => callback(error));
    }
    get(resourceGroupName, vmName, options, callback) {
        var client = this.client;
        if (!callback && typeof options === 'function') {
            callback = options;
            options = null;
        }
        if (!callback) {
            throw new Error(tl.loc("CallbackCannotBeNull"));
        }
        var expand = (options && options.expand !== undefined) ? options.expand : undefined;
        // Validate
        try {
            this.client.isValidResourceGroupName(resourceGroupName);
            if (vmName === null || vmName === undefined || typeof vmName.valueOf() !== 'string') {
                throw new Error(tl.loc("VMNameCannotBeNull"));
            }
            if (expand) {
                var allowedValues = ['instanceView'];
                if (!allowedValues.some(function (item) { return item === expand; })) {
                    throw new Error(tl.loc("InvalidValue", expand, allowedValues));
                }
            }
        }
        catch (error) {
            return callback(error);
        }
        var httpRequest = new webClient.WebRequest();
        httpRequest.method = 'GET';
        httpRequest.uri = this.client.getRequestUri('//subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.Compute/virtualMachines/{vmName}', {
            '{resourceGroupName}': resourceGroupName,
            '{vmName}': vmName
        }, ['$expand=' + encodeURIComponent(expand)]);
        // Set Headers
        httpRequest.headers = this.client.setCustomHeaders(options);
        this.client.beginRequest(httpRequest).then((response) => {
            var deferred = Q.defer();
            if (response.statusCode == 200) {
                var result = response.body;
                deferred.resolve(new azureServiceClientBase.ApiResult(null, result));
            }
            else {
                deferred.resolve(new azureServiceClientBase.ApiResult(azureServiceClientBase.ToError(response)));
            }
            return deferred.promise;
        }).then((apiResult) => callback(apiResult.error, apiResult.result), (error) => callback(error));
    }
    restart(resourceGroupName, vmName, callback) {
        var client = this.client;
        if (!callback) {
            throw new Error(tl.loc("CallbackCannotBeNull"));
        }
        // Validate
        try {
            this.client.isValidResourceGroupName(resourceGroupName);
            if (vmName === null || vmName === undefined || typeof vmName.valueOf() !== 'string') {
                throw new Error(tl.loc("VMNameCannotBeNull"));
            }
        }
        catch (error) {
            return callback(error);
        }
        // Create object
        var httpRequest = new webClient.WebRequest();
        httpRequest.method = 'POST';
        httpRequest.uri = this.client.getRequestUri('//subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.Compute/virtualMachines/{vmName}/restart', {
            '{resourceGroupName}': resourceGroupName,
            '{vmName}': vmName
        });
        // Set Headers
        httpRequest.headers = this.client.setCustomHeaders(null);
        httpRequest.body = null;
        this.client.beginRequest(httpRequest).then((response) => {
            var deferred = Q.defer();
            if (response.statusCode != 202) {
                deferred.resolve(new azureServiceClientBase.ApiResult(azureServiceClientBase.ToError(response)));
            }
            else {
                this.client.getLongRunningOperationResult(response).then((operationResponse) => {
                    if (operationResponse.body.status == "Succeeded") {
                        deferred.resolve(new azureServiceClientBase.ApiResult(null, operationResponse.body));
                    }
                    else {
                        deferred.resolve(new azureServiceClientBase.ApiResult(azureServiceClientBase.ToError(operationResponse)));
                    }
                }, (error) => deferred.reject(error));
            }
            return deferred.promise;
        }).then((apiResult) => callback(apiResult.error, apiResult.result), (error) => callback(error));
    }
    start(resourceGroupName, vmName, callback) {
        var client = this.client;
        if (!callback) {
            throw new Error(tl.loc("CallbackCannotBeNull"));
        }
        // Validate
        try {
            this.client.isValidResourceGroupName(resourceGroupName);
            if (vmName === null || vmName === undefined || typeof vmName.valueOf() !== 'string') {
                throw new Error(tl.loc("VMNameCannotBeNull"));
            }
        }
        catch (error) {
            return callback(error);
        }
        var httpRequest = new webClient.WebRequest();
        httpRequest.method = 'POST';
        httpRequest.uri = this.client.getRequestUri('//subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.Compute/virtualMachines/{vmName}/start', {
            '{resourceGroupName}': resourceGroupName,
            '{vmName}': vmName
        });
        httpRequest.headers = this.client.setCustomHeaders(null);
        httpRequest.body = null;
        this.client.beginRequest(httpRequest).then((response) => {
            var deferred = Q.defer();
            var statusCode = response.statusCode;
            if (statusCode != 202) {
                deferred.resolve(new azureServiceClientBase.ApiResult(azureServiceClientBase.ToError(response)));
            }
            else {
                this.client.getLongRunningOperationResult(response).then((operationResponse) => {
                    if (operationResponse.body.status == "Succeeded") {
                        deferred.resolve(new azureServiceClientBase.ApiResult(null, operationResponse.body));
                    }
                    else {
                        deferred.resolve(new azureServiceClientBase.ApiResult(azureServiceClientBase.ToError(operationResponse)));
                    }
                }, (error) => deferred.reject(error));
            }
            return deferred.promise;
        }).then((apiResult) => callback(apiResult.error, apiResult.result), (error) => callback(error));
    }
    powerOff(resourceGroupName, vmName, callback) {
        var client = this.client;
        if (!callback) {
            throw new Error(tl.loc("CallbackCannotBeNull"));
        }
        // Validate
        try {
            this.client.isValidResourceGroupName(resourceGroupName);
            if (vmName === null || vmName === undefined || typeof vmName.valueOf() !== 'string') {
                throw new Error(tl.loc("VMNameCannotBeNull"));
            }
        }
        catch (error) {
            return callback(error);
        }
        var httpRequest = new webClient.WebRequest();
        httpRequest.method = 'POST';
        httpRequest.headers = this.client.setCustomHeaders(null);
        httpRequest.uri = this.client.getRequestUri('//subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.Compute/virtualMachines/{vmName}/powerOff', {
            '{resourceGroupName}': resourceGroupName,
            '{vmName}': vmName
        });
        this.client.beginRequest(httpRequest).then((response) => {
            var deferred = Q.defer();
            var statusCode = response.statusCode;
            if (statusCode != 202) {
                deferred.resolve(new azureServiceClientBase.ApiResult(azureServiceClientBase.ToError(response)));
            }
            else {
                this.client.getLongRunningOperationResult(response).then((operationResponse) => {
                    if (operationResponse.body.status == "Succeeded") {
                        deferred.resolve(new azureServiceClientBase.ApiResult(null, operationResponse.body));
                    }
                    else {
                        deferred.resolve(new azureServiceClientBase.ApiResult(azureServiceClientBase.ToError(operationResponse)));
                    }
                }, (error) => deferred.reject(error));
            }
            return deferred.promise;
        }).then((apiResult) => callback(apiResult.error, apiResult.result), (error) => callback(error));
    }
    deallocate(resourceGroupName, vmName, callback) {
        var client = this.client;
        if (!callback) {
            throw new Error(tl.loc("CallbackCannotBeNull"));
        }
        // Validate
        try {
            this.client.isValidResourceGroupName(resourceGroupName);
            if (vmName === null || vmName === undefined || typeof vmName.valueOf() !== 'string') {
                throw new Error(tl.loc("VMNameCannotBeNull"));
            }
        }
        catch (error) {
            return callback(error);
        }
        var httpRequest = new webClient.WebRequest();
        httpRequest.method = 'POST';
        httpRequest.headers = this.client.setCustomHeaders(null);
        httpRequest.uri = this.client.getRequestUri('//subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.Compute/virtualMachines/{vmName}/deallocate', {
            '{resourceGroupName}': resourceGroupName,
            '{vmName}': vmName
        });
        this.client.beginRequest(httpRequest).then((response) => {
            var deferred = Q.defer();
            var statusCode = response.statusCode;
            if (statusCode != 202) {
                deferred.resolve(new azureServiceClientBase.ApiResult(azureServiceClientBase.ToError(response)));
            }
            else {
                this.client.getLongRunningOperationResult(response).then((operationResponse) => {
                    if (operationResponse.body.status == "Succeeded") {
                        deferred.resolve(new azureServiceClientBase.ApiResult(null, operationResponse.body));
                    }
                    else {
                        deferred.resolve(new azureServiceClientBase.ApiResult(azureServiceClientBase.ToError(operationResponse)));
                    }
                }, (error) => deferred.reject(error));
            }
            return deferred.promise;
        }).then((apiResult) => callback(apiResult.error, apiResult.result), (error) => callback(error));
    }
    deleteMethod(resourceGroupName, vmName, callback) {
        var client = this.client;
        if (!callback) {
            throw new Error(tl.loc("CallbackCannotBeNull"));
        }
        // Validate
        try {
            this.client.isValidResourceGroupName(resourceGroupName);
            if (vmName === null || vmName === undefined || typeof vmName.valueOf() !== 'string') {
                throw new Error(tl.loc("VMNameCannotBeNull"));
            }
        }
        catch (error) {
            return callback(error);
        }
        // Create object
        var httpRequest = new webClient.WebRequest();
        httpRequest.method = 'DELETE';
        httpRequest.headers = this.client.setCustomHeaders(null);
        httpRequest.uri = this.client.getRequestUri('//subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.Compute/virtualMachines/{vmName}', {
            '{resourceGroupName}': resourceGroupName,
            '{vmName}': vmName
        });
        httpRequest.body = null;
        this.client.beginRequest(httpRequest).then((response) => {
            var deferred = Q.defer();
            var statusCode = response.statusCode;
            if (statusCode != 202 && statusCode != 204) {
                deferred.resolve(new azureServiceClientBase.ApiResult(azureServiceClientBase.ToError(response)));
            }
            else {
                this.client.getLongRunningOperationResult(response).then((operationResponse) => {
                    if (operationResponse.body.status === "Succeeded") {
                        // Generate Response
                        deferred.resolve(new azureServiceClientBase.ApiResult(null, operationResponse.body));
                    }
                    else {
                        deferred.resolve(new azureServiceClientBase.ApiResult(azureServiceClientBase.ToError(operationResponse)));
                    }
                }, (error) => deferred.reject(error));
            }
            return deferred.promise;
        }).then((apiResult) => callback(apiResult.error, apiResult.result), (error) => callback(error));
    }
}
exports.VirtualMachines = VirtualMachines;
class VirtualMachineExtensions {
    constructor(client) {
        this.client = client;
    }
    list(resourceGroupName, resourceName, resourceType, options, callback) {
        if (!callback && typeof options === 'function') {
            callback = options;
            options = null;
        }
        if (!callback) {
            throw new Error(tl.loc("CallbackCannotBeNull"));
        }
        // Validate
        try {
            this.client.isValidResourceGroupName(resourceGroupName);
            if (resourceName === null || resourceName === undefined || typeof resourceName.valueOf() !== 'string') {
                throw new Error(tl.loc("ResourceNameCannotBeNull"));
            }
        }
        catch (error) {
            return callback(error);
        }
        var httpRequest = new webClient.WebRequest();
        httpRequest.method = 'GET';
        httpRequest.headers = this.client.setCustomHeaders(options);
        httpRequest.uri = this.client.getRequestUri('//subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.Compute/{resourceType}/{resourceName}/extensions', {
            '{resourceGroupName}': resourceGroupName,
            '{resourceType}': getComputeResourceTypeString(resourceType),
            '{resourceName}': resourceName
        });
        var result = [];
        this.client.beginRequest(httpRequest).then((response) => __awaiter(this, void 0, void 0, function* () {
            if (response.statusCode == 200) {
                if (response.body.value) {
                    result = result.concat(response.body.value);
                }
                if (response.body.nextLink) {
                    var nextResult = yield this.client.accumulateResultFromPagedResult(response.body.nextLink);
                    if (nextResult.error) {
                        return new azureServiceClientBase.ApiResult(nextResult.error);
                    }
                    result = result.concat(nextResult.result);
                }
                return new azureServiceClientBase.ApiResult(null, result);
            }
            else {
                return new azureServiceClientBase.ApiResult(azureServiceClientBase.ToError(response), result);
            }
        })).then((apiResult) => callback(apiResult.error, apiResult.result), (error) => callback(error));
    }
    get(resourceGroupName, resourceName, resourceType, vmExtensionName, options, callback) {
        var client = this.client;
        if (!callback && typeof options === 'function') {
            callback = options;
            options = null;
        }
        if (!callback) {
            throw new Error(tl.loc("CallbackCannotBeNull"));
        }
        var expand = (options && options.expand !== undefined) ? options.expand : undefined;
        // Validate
        try {
            this.client.isValidResourceGroupName(resourceGroupName);
            if (resourceName === null || resourceName === undefined || typeof resourceName.valueOf() !== 'string') {
                throw new Error(tl.loc("ResourceNameCannotBeNull"));
            }
            if (vmExtensionName === null || vmExtensionName === undefined || typeof vmExtensionName.valueOf() !== 'string') {
                throw new Error(tl.loc("VmExtensionNameCannotBeNull"));
            }
            if (expand !== null && expand !== undefined && typeof expand.valueOf() !== 'string') {
                throw new Error(tl.loc("ExpandShouldBeOfTypeString"));
            }
        }
        catch (error) {
            return callback(error);
        }
        // Create HTTP transport objects
        var httpRequest = new webClient.WebRequest();
        httpRequest.method = 'GET';
        httpRequest.headers = this.client.setCustomHeaders(options);
        httpRequest.uri = this.client.getRequestUri('//subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.Compute/{resourceType}/{resourceName}/extensions/{vmExtensionName}', {
            '{resourceGroupName}': resourceGroupName,
            '{resourceType}': getComputeResourceTypeString(resourceType),
            '{resourceName}': resourceName,
            '{vmExtensionName}': vmExtensionName
        });
        httpRequest.body = null;
        this.client.beginRequest(httpRequest).then((response) => {
            var deferred = Q.defer();
            if (response.statusCode == 200) {
                var result = response.body;
                deferred.resolve(new azureServiceClientBase.ApiResult(null, result));
            }
            else {
                deferred.resolve(new azureServiceClientBase.ApiResult(azureServiceClientBase.ToError(response)));
            }
            return deferred.promise;
        }).then((apiResult) => callback(apiResult.error, apiResult.result), (error) => callback(error));
    }
    createOrUpdate(resourceGroupName, resourceName, resourceType, vmExtensionName, extensionParameters, callback) {
        var client = this.client;
        if (!callback) {
            throw new Error(tl.loc("CallbackCannotBeNull"));
        }
        // Validate
        try {
            this.client.isValidResourceGroupName(resourceGroupName);
            if (resourceName === null || resourceName === undefined || typeof resourceName.valueOf() !== 'string') {
                throw new Error(tl.loc("ResourceNameCannotBeNull"));
            }
            if (vmExtensionName === null || vmExtensionName === undefined || typeof vmExtensionName.valueOf() !== 'string') {
                throw new Error(tl.loc("VmExtensionNameCannotBeNull"));
            }
            if (extensionParameters === null || extensionParameters === undefined) {
                throw new Error(tl.loc("ExtensionParametersCannotBeNull"));
            }
        }
        catch (error) {
            return callback(error);
        }
        // Create HTTP transport objects
        var httpRequest = new webClient.WebRequest();
        httpRequest.method = 'PUT';
        httpRequest.headers = this.client.setCustomHeaders(null);
        httpRequest.uri = this.client.getRequestUri('//subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.Compute/{resourceType}/{resourceName}/extensions/{vmExtensionName}', {
            '{resourceGroupName}': resourceGroupName,
            '{resourceType}': getComputeResourceTypeString(resourceType),
            '{resourceName}': resourceName,
            '{vmExtensionName}': vmExtensionName
        });
        // Serialize Request
        var requestContent = null;
        var requestModel = null;
        if (extensionParameters !== null && extensionParameters !== undefined) {
            httpRequest.body = JSON.stringify(extensionParameters);
        }
        // Send request
        this.client.beginRequest(httpRequest).then((response) => {
            var deferred = Q.defer();
            if (response.statusCode != 200 && response.statusCode != 201) {
                deferred.resolve(new azureServiceClientBase.ApiResult(azureServiceClientBase.ToError(response)));
            }
            else {
                this.client.getLongRunningOperationResult(response).then((operationResponse) => {
                    if (operationResponse.body.status === "Succeeded") {
                        var result = { properties: { "provisioningState": operationResponse.body.status } };
                        deferred.resolve(new azureServiceClientBase.ApiResult(null, result));
                    }
                    else {
                        deferred.resolve(new azureServiceClientBase.ApiResult(azureServiceClientBase.ToError(operationResponse)));
                    }
                }, (error) => deferred.reject(error));
            }
            return deferred.promise;
        }).then((apiResult) => callback(apiResult.error, apiResult.result), (error) => callback(error));
    }
    deleteMethod(resourceGroupName, resourceName, resourceType, vmExtensionName, callback) {
        if (!callback) {
            throw new Error(tl.loc("CallbackCannotBeNull"));
        }
        // Validate
        try {
            this.client.isValidResourceGroupName(resourceGroupName);
            if (resourceName === null || resourceName === undefined || typeof resourceName.valueOf() !== 'string') {
                throw new Error(tl.loc("ResourceNameCannotBeNull"));
            }
            if (vmExtensionName === null || vmExtensionName === undefined || typeof vmExtensionName.valueOf() !== 'string') {
                throw new Error(tl.loc("VmExtensionNameCannotBeNull"));
            }
        }
        catch (error) {
            return callback(error);
        }
        // Create HTTP transport objects
        var httpRequest = new webClient.WebRequest();
        httpRequest.method = 'DELETE';
        httpRequest.uri = this.client.getRequestUri('//subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.Compute/{resourceType}/{resourceName}/extensions/{vmExtensionName}', {
            '{resourceGroupName}': resourceGroupName,
            '{resourceType}': getComputeResourceTypeString(resourceType),
            '{resourceName}': resourceName,
            '{vmExtensionName}': vmExtensionName
        });
        // Send request
        this.client.beginRequest(httpRequest).then((response) => {
            var deferred = Q.defer();
            if (response.statusCode !== 202 && response.statusCode !== 204) {
                deferred.resolve(new azureServiceClientBase.ApiResult(azureServiceClientBase.ToError(response)));
            }
            else {
                this.client.getLongRunningOperationResult(response).then((operationResponse) => {
                    if (operationResponse.statusCode === 200) {
                        deferred.resolve(new azureServiceClientBase.ApiResult(null));
                    }
                    else {
                        deferred.resolve(new azureServiceClientBase.ApiResult(azureServiceClientBase.ToError(operationResponse)));
                    }
                }, (error) => deferred.reject(error));
            }
            return deferred.promise;
        }).then((apiResult) => callback(apiResult.error, apiResult.result), (error) => callback(error));
    }
}
exports.VirtualMachineExtensions = VirtualMachineExtensions;
class VirtualMachineScaleSets {
    constructor(client) {
        this.client = client;
    }
    list(options, callback) {
        if (!callback && typeof options === 'function') {
            callback = options;
            options = null;
        }
        if (!callback) {
            throw new Error(tl.loc("CallbackCannotBeNull"));
        }
        var httpRequest = new webClient.WebRequest();
        httpRequest.method = 'GET';
        httpRequest.headers = this.client.setCustomHeaders(options);
        httpRequest.uri = this.client.getRequestUri('//subscriptions/{subscriptionId}/providers/Microsoft.Compute/virtualMachineScaleSets', {});
        var result = [];
        this.client.beginRequest(httpRequest).then((response) => __awaiter(this, void 0, void 0, function* () {
            if (response.statusCode == 200) {
                if (response.body.value) {
                    result = result.concat(response.body.value);
                }
                if (response.body.nextLink) {
                    var nextResult = yield this.client.accumulateResultFromPagedResult(response.body.nextLink);
                    if (nextResult.error) {
                        return new azureServiceClientBase.ApiResult(nextResult.error);
                    }
                    result = result.concat(nextResult.result);
                }
                return new azureServiceClientBase.ApiResult(null, result);
            }
            else {
                return new azureServiceClientBase.ApiResult(azureServiceClientBase.ToError(response), result);
            }
        })).then((apiResult) => callback(apiResult.error, apiResult.result), (error) => callback(error));
    }
    get(resourceGroupName, vmssName, options, callback) {
        var client = this.client;
        if (!callback && typeof options === 'function') {
            callback = options;
            options = null;
        }
        if (!callback) {
            throw new Error(tl.loc("CallbackCannotBeNull"));
        }
        var expand = (options && options.expand !== undefined) ? options.expand : undefined;
        // Validate
        try {
            this.client.isValidResourceGroupName(resourceGroupName);
            if (vmssName === null || vmssName === undefined || typeof vmssName.valueOf() !== 'string') {
                throw new Error(tl.loc("VMSSNameCannotBeNull"));
            }
            if (expand) {
                var allowedValues = ['instanceView'];
                if (!allowedValues.some(function (item) { return item === expand; })) {
                    throw new Error(tl.loc("InvalidValue", expand, allowedValues));
                }
            }
        }
        catch (error) {
            return callback(error);
        }
        var httpRequest = new webClient.WebRequest();
        httpRequest.method = 'GET';
        httpRequest.uri = this.client.getRequestUri('//subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.Compute/virtualMachineScaleSets/{vmssName}', {
            '{resourceGroupName}': resourceGroupName,
            '{vmssName}': vmssName
        }, ['$expand=' + encodeURIComponent(expand)]);
        // Set Headers
        httpRequest.headers = this.client.setCustomHeaders(options);
        this.client.beginRequest(httpRequest).then((response) => {
            var deferred = Q.defer();
            if (response.statusCode == 200) {
                var result = response.body;
                deferred.resolve(new azureServiceClientBase.ApiResult(null, result));
            }
            else {
                deferred.resolve(new azureServiceClientBase.ApiResult(azureServiceClientBase.ToError(response)));
            }
            return deferred.promise;
        }).then((apiResult) => callback(apiResult.error, apiResult.result), (error) => callback(error));
    }
    updateImage(resourceGroupName, vmssName, imageUrl, options, callback) {
        var client = this.client;
        if (!callback && typeof options === 'function') {
            callback = options;
            options = null;
        }
        if (!callback) {
            throw new Error(tl.loc("CallbackCannotBeNull"));
        }
        if (imageUrl === null || imageUrl === undefined || typeof imageUrl.valueOf() !== 'string') {
            throw new Error(tl.loc("VMSSImageUrlCannotBeNull"));
        }
        var expand = (options && options.expand !== undefined) ? options.expand : undefined;
        // Validate
        try {
            this.client.isValidResourceGroupName(resourceGroupName);
            if (vmssName === null || vmssName === undefined || typeof vmssName.valueOf() !== 'string') {
                throw new Error(tl.loc("VMSSNameCannotBeNull"));
            }
        }
        catch (error) {
            return callback(error);
        }
        // get VMSS
        this.get(resourceGroupName, vmssName, null, (error, result, request, response) => {
            if (error) {
                tl.warning(tl.loc("GetVMSSFailed", resourceGroupName, vmssName, error));
                return callback(error, null);
            }
            var vmss = result;
            var osDisk = vmss.properties.virtualMachineProfile.storageProfile.osDisk;
            if (!(osDisk && osDisk.image && osDisk.image.uri)) {
                return callback(tl.loc("VMSSDoesNotHaveCustomImage", vmssName));
            }
            if (imageUrl === osDisk.image.uri) {
                console.log(tl.loc("VMSSImageAlreadyUptoDate", vmssName));
                return callback(null, null);
            }
            // update image uri
            osDisk.image.uri = imageUrl;
            var storageProfile = { "osDisk": osDisk };
            // update VM extension
            var oldExtensionProfile = vmss.properties.virtualMachineProfile.extensionProfile;
            var virtualMachineProfile = { "storageProfile": storageProfile };
            var properties = { "virtualMachineProfile": virtualMachineProfile };
            var patchBody = {
                "id": vmss["id"],
                "name": vmss["name"],
                "properties": properties
            };
            var httpRequest = new webClient.WebRequest();
            httpRequest.method = 'PATCH';
            httpRequest.uri = this.client.getRequestUri('//subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.Compute/virtualMachineScaleSets/{vmssName}', {
                '{resourceGroupName}': resourceGroupName,
                '{vmssName}': vmssName
            });
            // Set Headers
            httpRequest.headers = this.client.setCustomHeaders(options);
            httpRequest.body = JSON.stringify(patchBody);
            // patch VMSS image
            console.log(tl.loc("NewVMSSImageUrl", imageUrl));
            console.log(tl.loc("VMSSUpdateImage", vmssName));
            this.client.beginRequest(httpRequest).then((response) => {
                var deferred = Q.defer();
                var statusCode = response.statusCode;
                if (response.statusCode == 200) {
                    // wait for image update to complete
                    this.client.getLongRunningOperationResult(response).then((operationResponse) => {
                        if (operationResponse.body.status === "Succeeded") {
                            deferred.resolve(new azureServiceClientBase.ApiResult(null, operationResponse.body));
                        }
                        else {
                            deferred.resolve(new azureServiceClientBase.ApiResult(azureServiceClientBase.ToError(operationResponse)));
                        }
                    }, (error) => deferred.reject(error));
                }
                else {
                    deferred.resolve(new azureServiceClientBase.ApiResult(azureServiceClientBase.ToError(response)));
                }
                return deferred.promise;
            }).then((apiResult) => callback(apiResult.error, apiResult.result), (error) => callback(error));
        });
    }
}
exports.VirtualMachineScaleSets = VirtualMachineScaleSets;
function getComputeResourceTypeString(resourceType) {
    switch (resourceType) {
        case Model.ComputeResourceType.VirtualMachine:
            return "virtualMachines";
        case Model.ComputeResourceType.VirtualMachineScaleSet:
            return "virtualMachineScaleSets";
    }
}
exports.getComputeResourceTypeString = getComputeResourceTypeString;
